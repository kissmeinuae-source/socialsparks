
# Control Panel — Operator Upgrade (Phase 1)

Scope you chose: **upgrade existing modules first**, with **command palette + shortcuts**, **saved views + bulk actions + inline edit**, **omnichannel inbox**, and **content ops (media + SEO)**. New big modules (Analytics, Clients/Projects, Invoices, Team/Permissions) come in Phase 2.

## What changes for the operator

- **⌘K Command Palette** anywhere in `/admin` — jump to any module, search leads/posts/services/pricing/testimonials by typing, run actions ("mark lead won", "publish post", "send test email", "log out").
- **Keyboard shortcuts** — `g l` leads, `g b` board, `g p` posts, `g m` media, `g s` SEO, `/` focus search, `j/k` row up/down, `x` select, `e` edit, `?` shortcut cheatsheet.
- **Saved views** per list (Leads, Posts, Services, Pricing, Testimonials, Automations, Media) — filter + columns + sort persisted per user, shareable via URL.
- **Bulk actions** — multi-select rows → assign owner, change status, add tag, delete, export CSV.
- **Inline edit + optimistic UI** — click a cell (status, tag, price, title, published) to edit in place; toast with Undo.
- **Activity timeline** on every record (lead, post, service, plan, testimonial, automation run) — who did what, when.
- **Omnichannel inbox on Leads** — WhatsApp deep-link composer, email reply form (uses existing email provider), site-chat messages, all pinned to the lead as one thread.
- **Media library** — `/admin/media`: upload, alt text, tags, "used on" backlinks, copy CDN URL, delete with guardrail.
- **SEO console** — `/admin/seo`: per-route meta editor (title, description, OG, canonical), redirects table, sitemap status, broken-link scanner.
- **Global polish** — top bar with breadcrumb + saved-view chip + ⌘K, sticky bulk-action toolbar, empty states with one-click "create", consistent confirm dialogs, toast system, error boundaries per module.

## Module-by-module deltas

| Module        | New capability                                                                                                                  |
|---------------|---------------------------------------------------------------------------------------------------------------------------------|
| Leads         | Saved views, bulk assign/tag/status/export, inline status & owner, omnichannel inbox tab, activity timeline, score recompute    |
| Board (Kanban)| Drag-with-keyboard, swimlanes by owner, WIP limits per column, quick-add card                                                   |
| Automations   | Inline enable/disable toggle, "run now" button per rule, last-run badge, runs drawer with filters, dry-run preview              |
| Blog          | Bulk publish/unpublish/delete, inline title/slug edit, scheduled publish, revision history, SEO panel in editor                 |
| Pricing       | Inline price & feature edit, drag-reorder, archive vs delete, "highlight" toggle, currency switch                               |
| Services      | Inline title/order edit, drag-reorder, icon picker, archive                                                                     |
| Testimonials  | Inline approve/feature toggles, bulk approve, drag-reorder featured                                                             |
| Email         | Send-test stays, add **Send log** tab (already have `email_send_log` analytics), template picker, per-status filters            |
| Settings      | Tabbed (Brand, Contact, Social, SEO defaults, Nav, Footer, Hero), autosave, validation                                          |
| Media (new)   | Upload, search, tag, alt text, used-on tracking                                                                                 |
| SEO (new)     | Per-route meta editor, redirects, sitemap status, broken-link scan                                                              |

## Technical details

- **Storage**: new `admin_views` (user_id, module, name, filters jsonb, columns jsonb, sort jsonb, is_default), `media_assets` (path, url, alt, tags, width/height, size, uploaded_by), `media_usage` (asset_id, used_on), `seo_overrides` (route, title, description, og_image, canonical, noindex), `redirects` (from_path, to_path, code), `inbox_messages` (lead_id, channel, direction, body, sent_by, meta), `activity_log` (entity_type, entity_id, actor_id, action, diff jsonb). All admin-scoped RLS via `has_role('admin')`.
- **Supabase Storage**: create `media` bucket (public) with admin-only write policies.
- **Command palette**: `cmdk` (already a shadcn primitive) wired in `__root.tsx` behind `/admin/*` route check; registry pattern so each module can `useRegisterCommand({ id, title, run })`.
- **Shortcuts**: tiny `useHotkey` hook (no new dep) reading focus state to avoid hijacking inputs.
- **Saved views**: URL search params drive the list query; `Save view` writes current params to `admin_views`; switcher in module header.
- **Bulk actions**: shared `<BulkBar>` component bound to a `useSelection` hook, dispatching to module-specific server fns.
- **Inline edit**: shared `<EditableCell>` + `useOptimisticMutation` wrapper around TanStack Query mutations; rollback on error, undo toast on success.
- **Inbox**: WhatsApp = `https://wa.me/<e164>?text=` composer + log to `inbox_messages`; email reply = existing `email.server.ts` send + log; site-chat = read from `inbox_messages` where `channel='chat'`. Future webhooks can append.
- **Activity log**: server-side helper `logActivity(ctx, entity, action, diff)` called from every mutation server fn; renders as right-rail drawer.
- **SEO console**: route registry generated from `src/routes/*` at build; loader reads `seo_overrides` and merges into `head()` via a shared helper already in `src/lib/seo.ts`.
- **Broken-link scan**: server fn crawls `sitemap.xml`, HEAD-checks each URL, writes results to `seo_scan_results`; surfaced in SEO console with "rescan" button.
- **Performance**: every list paginates server-side, columns memoized, virtualized when >200 rows (`@tanstack/react-virtual`).
- **Type safety**: regenerate Supabase types after migrations; shared `Database` types power every server fn.
- **Tests**: smoke test via Playwright over `/admin`, leads bulk action, palette open, inline edit, media upload, SEO save.

## Sequence (single pass, in order)

1. Migrations: `admin_views`, `media_assets`, `media_usage`, `seo_overrides`, `redirects`, `inbox_messages`, `activity_log`, `seo_scan_results` + `media` storage bucket + RLS/grants.
2. Shared primitives: `useHotkey`, `useSelection`, `<BulkBar>`, `<EditableCell>`, `useOptimisticMutation`, `<ActivityDrawer>`, command palette provider + registry.
3. Admin shell upgrade: top bar with breadcrumb + ⌘K + saved-view chip, shortcut cheatsheet modal, global toast/undo, per-module error boundary.
4. Module retrofits in this order: Leads → Board → Blog → Pricing → Services → Testimonials → Automations → Email → Settings (each gets saved views + bulk + inline + activity).
5. New modules: Media library, SEO console (incl. redirects + broken-link scan).
6. Inbox tab on Leads, wired to `inbox_messages` + WhatsApp/email/site-chat.
7. Playwright smoke pass + lint + typecheck.

## What is *not* in this pass

- Analytics & Reports module, Clients/Projects/Tasks, Invoices & Payments, Team & Permissions UI (roles already exist in DB) — Phase 2.
- Visual redesign of admin chrome — separate redesign turn if you want it after the function pass.

Reply **go** to ship it, or tell me what to drop/add.
