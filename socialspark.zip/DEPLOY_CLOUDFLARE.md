# Deploy Social Spark to your own Cloudflare Workers

This project is built with TanStack Start + Nitro and targets the **Cloudflare Workers** runtime out of the box. You run these commands on your own machine — Lovable can't push to your Cloudflare account.

---

## 0. One-time prerequisites

1. A Cloudflare account (free tier is fine).
2. Node 20+ and Bun installed locally.
3. Wrangler CLI:
   ```bash
   npm i -g wrangler
   wrangler login
   ```
4. Clone this project locally (GitHub → Connect from Lovable, then `git clone`).

---

## 1. Install + build

```bash
bun install
bun run build
```

Output lands in `.output/` (`.output/server/index.mjs` = Worker, `.output/public/` = static assets). `wrangler.toml` at the project root already points at both.

---

## 2. Push secrets to your Worker

Run each of these once. Wrangler will prompt for the value (paste, hit Enter):

```bash
wrangler secret put SUPABASE_PUBLISHABLE_KEY
wrangler secret put SUPABASE_SERVICE_ROLE_KEY
wrangler secret put VITE_SUPABASE_PUBLISHABLE_KEY
```

Get the values from Lovable → Cloud → Settings (or your Supabase dashboard if you have direct access).

**About `LOVABLE_API_KEY`:** it only works inside Lovable's infrastructure. On your own Worker, any feature that calls Lovable AI Gateway (chat, embeddings, image gen) will stop working. If you use those, swap to a direct provider key (e.g. `OPENAI_API_KEY`, `GEMINI_API_KEY`) and update `src/lib/ai.server.ts` accordingly — tell me and I'll do the swap before you deploy.

---

## 3. Deploy

```bash
wrangler deploy
```

First deploy gives you a URL like `https://social-spark.<your-subdomain>.workers.dev`. Open it — the full site should render with SSR.

---

## 4. Custom domain

In the Cloudflare dashboard → Workers & Pages → social-spark → Settings → Domains & Routes → **Add Custom Domain**. Point it at any domain on a Cloudflare-managed zone. SSL is automatic.

---

## 5. Repoint pg_cron webhooks

The cron jobs in Supabase currently hit `project--…lovable.app/api/public/cron/*`. After deploy, update them to your new Workers URL. Run this in the Lovable Cloud SQL editor (replace the host):

```sql
SELECT cron.unschedule(jobname) FROM cron.job WHERE command LIKE '%lovable.app%';
-- then re-create each job pointing at https://YOUR-WORKER.workers.dev/api/public/cron/...
```

Tell me when you have the final URL and I'll regenerate the exact `cron.schedule(...)` statements for you.

---

## 6. Ongoing workflow

- **Edit in Lovable** → push to GitHub → `git pull` locally → `bun run build && wrangler deploy`.
- Or wire up GitHub Actions to auto-deploy on push to `main` (I can add the workflow file if you want).

---

## What stops working on your own Worker (vs Lovable hosting)

| Feature | Status |
|---|---|
| Public site (all routes, SSR, SEO) | ✅ Works |
| Admin console + auth | ✅ Works |
| Lead forms + automations | ✅ Works |
| BYO Email (Brevo/Resend/SendGrid/etc.) | ✅ Works |
| Supabase DB + storage | ✅ Works (same project) |
| Lovable AI features (chat, embeddings) | ❌ Stops — needs direct provider key |
| Lovable "Publish" button | ❌ N/A — you deploy via wrangler |
| Lovable preview URL | ✅ Still works for editing |

---

## Troubleshooting

- **`[unenv] X is not implemented`** — a Node-only dep slipped in. Tell me the module name; we'll swap it.
- **`Unauthorized: No authorization header provided`** — secrets missing or stale. Re-run `wrangler secret put` and redeploy.
- **Cron webhooks 404** — step 5 wasn't done. Update the pg_cron URLs.
- **AI features broken** — expected; see the LOVABLE_API_KEY note in step 2.

---

## Auto-Deploy via GitHub Actions

A workflow at `.github/workflows/deploy-cloudflare.yml` builds and deploys to Cloudflare Workers on every push to `main`.

### One-time setup

In your GitHub repo → **Settings → Secrets and variables → Actions**, add:

**Cloudflare**
- `CLOUDFLARE_API_TOKEN` — create at dash.cloudflare.com → My Profile → API Tokens → "Edit Cloudflare Workers" template
- `CLOUDFLARE_ACCOUNT_ID` — Workers & Pages → right sidebar

**Build-time (Vite, public)**
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID`

**Runtime (Worker secrets, pushed by wrangler)**
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

### Trigger
Push to `main`, or run manually via Actions → "Deploy to Cloudflare Workers" → Run workflow.
