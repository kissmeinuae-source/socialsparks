
-- Revoke direct EXECUTE on trigger functions; they only need to run as triggers
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;

-- Tighten public lead submission: require type + at least one identifier, cap field lengths
DROP POLICY IF EXISTS "Anyone can submit a lead" ON public.leads;
CREATE POLICY "Public can submit a valid lead"
  ON public.leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    type IS NOT NULL
    AND status = 'new'
    AND assigned_to IS NULL
    AND notes IS NULL
    AND (
      (email IS NOT NULL AND char_length(email) BETWEEN 3 AND 320)
      OR (phone IS NOT NULL AND char_length(phone) BETWEEN 4 AND 32)
    )
    AND (name IS NULL OR char_length(name) <= 200)
    AND (business IS NULL OR char_length(business) <= 200)
    AND (message IS NULL OR char_length(message) <= 4000)
    AND (social_url IS NULL OR char_length(social_url) <= 500)
    AND (source_page IS NULL OR char_length(source_page) <= 500)
  );
