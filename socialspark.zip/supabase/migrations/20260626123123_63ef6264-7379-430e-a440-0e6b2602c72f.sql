
-- Lead enrichment columns
ALTER TABLE public.leads
  ADD COLUMN IF NOT EXISTS score smallint NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS tags text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_auto_action text,
  ADD COLUMN IF NOT EXISTS last_auto_action_at timestamptz;

CREATE INDEX IF NOT EXISTS leads_score_idx ON public.leads (score DESC);
CREATE INDEX IF NOT EXISTS leads_tags_idx ON public.leads USING gin (tags);

-- Rules table
CREATE TABLE IF NOT EXISTS public.automation_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  enabled boolean NOT NULL DEFAULT true,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  last_run_at timestamptz,
  last_run_status text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.automation_rules TO authenticated;
GRANT ALL ON public.automation_rules TO service_role;
ALTER TABLE public.automation_rules ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team can view automation rules"
  ON public.automation_rules FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'team'));

CREATE POLICY "Admins can update automation rules"
  ON public.automation_rules FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER automation_rules_updated_at
  BEFORE UPDATE ON public.automation_rules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Run log
CREATE TABLE IF NOT EXISTS public.automation_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_key text NOT NULL,
  trigger text NOT NULL,
  status text NOT NULL DEFAULT 'success',
  lead_id uuid REFERENCES public.leads(id) ON DELETE SET NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS automation_runs_rule_idx ON public.automation_runs (rule_key, created_at DESC);
CREATE INDEX IF NOT EXISTS automation_runs_created_idx ON public.automation_runs (created_at DESC);

GRANT SELECT ON public.automation_runs TO authenticated;
GRANT ALL ON public.automation_runs TO service_role;
ALTER TABLE public.automation_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Team can view automation runs"
  ON public.automation_runs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'team'));

-- Seed default rules
INSERT INTO public.automation_rules (key, name, description) VALUES
  ('lead.score', 'Auto-score new leads', 'Assigns a 0–100 priority score and tags (e.g. hot, enterprise, budget-signal) when a new lead comes in.'),
  ('lead.customer_autoreply', 'Customer auto-reply', 'Sends a branded confirmation email to the lead within seconds of submission.'),
  ('cron.stale_leads', 'Stale lead sweep', 'Every 6 hours: flags contacted leads with no activity in 72h with the needs-followup tag and logs a reminder.'),
  ('cron.daily_digest', 'Daily digest email', 'Every day at 09:00 PKT: emails admins a summary of new leads, hot leads, and pipeline movement.')
ON CONFLICT (key) DO NOTHING;
