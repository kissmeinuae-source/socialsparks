
-- 1) Restrict public read on site_settings to a safe key allowlist
DROP POLICY IF EXISTS "Public can read site settings" ON public.site_settings;

CREATE POLICY "Public can read safe site settings"
ON public.site_settings
FOR SELECT
TO anon, authenticated
USING (key IN ('brand','social','contact','seo','hero','footer','nav'));

-- 2) Lock down SECURITY DEFINER function execution from API roles.
-- These functions are used by triggers / RLS policies internally.
-- handle_new_user: auth trigger only.
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- update_updated_at_column: trigger only.
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;

-- has_role: called from RLS policies as the querying role, so authenticated
-- must keep EXECUTE. Revoke from anon + PUBLIC.
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
