CREATE TABLE public.email_config (
  id BOOLEAN PRIMARY KEY DEFAULT true CHECK (id),
  provider TEXT NOT NULL DEFAULT 'brevo' CHECK (provider IN ('brevo','resend','mailgun','sendgrid','postmark')),
  api_key TEXT,
  api_secret TEXT,
  mailgun_domain TEXT,
  from_name TEXT NOT NULL DEFAULT 'Social Spark',
  from_email TEXT NOT NULL DEFAULT '',
  reply_to TEXT,
  notify_to TEXT,
  enabled BOOLEAN NOT NULL DEFAULT false,
  last_test_at TIMESTAMPTZ,
  last_test_status TEXT,
  last_test_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by UUID
);

GRANT SELECT, INSERT, UPDATE ON public.email_config TO authenticated;
GRANT ALL ON public.email_config TO service_role;

ALTER TABLE public.email_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read email config" ON public.email_config FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins insert email config" ON public.email_config FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update email config" ON public.email_config FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE TRIGGER email_config_updated_at BEFORE UPDATE ON public.email_config FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.email_config (id) VALUES (true) ON CONFLICT DO NOTHING;