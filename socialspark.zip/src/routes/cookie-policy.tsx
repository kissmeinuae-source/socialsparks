import { createFileRoute } from "@tanstack/react-router";
import { LegalLayout } from "@/components/legal/LegalLayout";
import { absolute } from "@/lib/seo";

export const Route = createFileRoute("/cookie-policy")({
  head: () => ({
    meta: [
      { title: "Cookie Policy — Social Spark" },
      { name: "description", content: "Which cookies Social Spark uses and how to opt out." },
      { property: "og:url", content: absolute("/cookie-policy") }, { property: "og:type", content: "website" },

    ],

    links: [{ rel: "canonical", href: absolute("/cookie-policy") }],
    }),
  component: () => (
    <LegalLayout title="Cookie Policy" updated="June 26, 2026">
      <p>
        Cookies are small text files stored on your device when you visit a
        website. They help sites remember your preferences and measure how
        people use them. This page lists the cookies we use on socialspark.pk.
      </p>

      <h2>Cookies we use</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Purpose</th>
            <th>Duration</th>
            <th>Type</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>ss-lang</td><td>Remembers your language preference (EN/UR)</td><td>1 year</td><td>First-party</td></tr>
          <tr><td>ss-entered</td><td>Skips the page intro animation on repeat visits</td><td>Session</td><td>First-party</td></tr>
          <tr><td>ss-consent</td><td>Stores your cookie consent choice</td><td>6 months</td><td>First-party</td></tr>
          <tr><td>_ga, _ga_*</td><td>Anonymous analytics via Google Analytics 4</td><td>2 years</td><td>Third-party</td></tr>
          <tr><td>_fbp</td><td>Conversion tracking for Meta ads</td><td>3 months</td><td>Third-party</td></tr>
        </tbody>
      </table>

      <h2>How to opt out</h2>
      <p>
        You can decline non-essential cookies in our consent banner, or clear
        cookies any time from your browser settings. You can also opt out of
        Google Analytics with the official{" "}
        <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener noreferrer">
          browser add-on
        </a>
        . Blocking essential cookies (like ss-lang) may break basic site
        features.
      </p>

      <h2>Updates</h2>
      <p>We review this policy quarterly. Material changes will be flagged via the consent banner on your next visit.</p>
    </LegalLayout>
  ),
});
