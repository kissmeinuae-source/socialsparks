import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: typeof search.redirect === "string" ? search.redirect : "/admin",
  }),
  head: () => ({
    meta: [
      { title: "Sign in — Social Spark" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AuthPage,
});

const schema = z.object({
  email: z.string().trim().email("Enter a valid email").max(320),
  password: z.string().min(8, "Minimum 8 characters").max(200),
});

function AuthPage() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/auth" });
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const safeRedirect = (() => {
    try {
      const r = search.redirect || "/admin";
      return r.startsWith("/") ? r : "/admin";
    } catch {
      return "/admin";
    }
  })();

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Invalid input");
      return;
    }
    setLoading(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin + "/admin",
            data: { full_name: fullName || email.split("@")[0] },
          },
        });
        if (error) throw error;
      }
      navigate({ to: safeRedirect });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "48px 20px",
        background: "var(--ss-cream, #F5F3EE)",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          background: "#fff",
          border: "1px solid var(--ss-line, #E6E2D6)",
          borderRadius: 20,
          padding: 40,
          boxShadow: "0 30px 60px -30px rgba(14,27,61,0.18)",
        }}
      >
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash, #8C8472)" }}>
            Social Spark · Admin
          </div>
          <h1 style={{ margin: "10px 0 0", fontFamily: "var(--font-serif, 'Instrument Serif', serif)", fontSize: 34, fontStyle: "italic", color: "var(--ss-ink, #0E1B3D)", lineHeight: 1.1 }}>
            {mode === "signin" ? "Welcome back." : "Create your account."}
          </h1>
        </div>

        <form onSubmit={onSubmit} noValidate style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {mode === "signup" && (
            <Field label="Full name" value={fullName} onChange={setFullName} type="text" autoComplete="name" />
          )}
          <Field label="Email" value={email} onChange={setEmail} type="email" autoComplete="email" required />
          <Field
            label="Password"
            value={password}
            onChange={setPassword}
            type="password"
            autoComplete={mode === "signin" ? "current-password" : "new-password"}
            required
          />

          {error && (
            <div role="alert" style={{ marginTop: 2, fontFamily: "var(--font-sans)", fontSize: 13, color: "#B4302D" }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              marginTop: 6,
              padding: "14px 18px",
              borderRadius: 12,
              border: "none",
              background: "var(--ss-ink, #0E1B3D)",
              color: "#fff",
              fontFamily: "var(--font-sans)",
              fontWeight: 600,
              fontSize: 14,
              cursor: loading ? "wait" : "pointer",
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
          </button>
        </form>

        <div style={{ marginTop: 22, textAlign: "center", fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-slate, #5A5648)" }}>
          {mode === "signin" ? "Need an account?" : "Already have one?"}{" "}
          <button
            type="button"
            onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(null); }}
            style={{ background: "none", border: "none", padding: 0, color: "var(--ss-ink, #0E1B3D)", textDecoration: "underline", cursor: "pointer", fontWeight: 600 }}
          >
            {mode === "signin" ? "Create one" : "Sign in"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type,
  autoComplete,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type: string;
  autoComplete?: string;
  required?: boolean;
}) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash, #8C8472)" }}>
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        required={required}
        style={{
          padding: "13px 14px",
          borderRadius: 10,
          border: "1px solid var(--ss-line, #E6E2D6)",
          fontFamily: "var(--font-sans)",
          fontSize: 14,
          color: "var(--ss-ink, #0E1B3D)",
          background: "var(--ss-cream, #F5F3EE)",
          outline: "none",
        }}
      />
    </label>
  );
}
