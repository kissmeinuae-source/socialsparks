import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/cron/daily-digest")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { checkRateLimit, clientIp } = await import("@/lib/rate-limit.server");
        if (!checkRateLimit(`cron-digest:${clientIp(request)}`, 6, 60_000)) {
          return new Response("Too Many Requests", { status: 429 });
        }
        const apikey = request.headers.get("apikey") ?? request.headers.get("x-api-key");
        if (!apikey || apikey !== process.env.SUPABASE_PUBLISHABLE_KEY) {
          return new Response("Unauthorized", { status: 401 });
        }
        try {
          const { runDailyDigest } = await import("@/lib/automations.server");
          const result = await runDailyDigest();
          return Response.json({ ok: true, ...result });
        } catch (e) {
          return Response.json(
            { ok: false, error: e instanceof Error ? e.message : String(e) },
            { status: 500 },
          );
        }
      },
    },
  },
});
