import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { LanguageProvider } from "../lib/language";
import { TopProgressBar } from "../components/TopProgressBar";
import { PageEnterAnimation } from "../components/global/PageEnterAnimation";
import { TopLanguageBar } from "../components/global/TopLanguageBar";
import { NavBar } from "../components/global/NavBar";
import { Footer } from "../components/global/Footer";
import { SmoothScroll } from "../components/global/SmoothScroll";
// Defer the chat widget bundle until the browser is idle — it's never part of LCP.
const TalkToUsWidget = lazy(() =>
  import("../components/global/TalkToUsWidget").then((m) => ({ default: m.TalkToUsWidget }))
);

function DeferredWidget() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const win = window as Window & { requestIdleCallback?: (cb: () => void) => number };
    const trigger = () => setShow(true);
    if (win.requestIdleCallback) {
      win.requestIdleCallback(trigger);
    } else {
      const t = window.setTimeout(trigger, 1500);
      return () => window.clearTimeout(t);
    }
  }, []);
  if (!show) return null;
  return (
    <Suspense fallback={null}>
      <TalkToUsWidget />
    </Suspense>
  );
}

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-4">
      <div className="max-w-md text-center">
        <h1 className="display-italic text-ink" style={{ fontSize: "clamp(72px, 12vw, 140px)", lineHeight: 0.9 }}>404</h1>
        <h2 className="mt-4 text-xl font-medium text-ink">Page not found</h2>
        <p className="mt-2 text-sm text-slate">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link to="/" className="btn-primary">Go home →</Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-4">
      <div className="max-w-md text-center">
        <h1 className="display-italic text-ink" style={{ fontSize: "clamp(36px, 5vw, 48px)" }}>
          This page didn't load
        </h1>
        <p className="mt-3 text-sm text-slate">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="btn-primary"
          >
            Try again
          </button>
          <a href="/" className="btn-ghost">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#F7F5F0" },
      { name: "color-scheme", content: "light" },
      { name: "format-detection", content: "telephone=no" },
      // PWA / iOS in-app browser polish (TikTok, Instagram, Facebook webviews)
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: "Social Spark" },
      { name: "application-name", content: "Social Spark" },
      { property: "og:site_name", content: "Social Spark" },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "en_PK" },
      { property: "og:locale:alternate", content: "ur_PK" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:site", content: "@socialspark" },
      { title: "Lovable App" },
      { property: "og:title", content: "Lovable App" },
      { name: "twitter:title", content: "Lovable App" },
      { name: "description", content: "Build production-ready complex full-stack applications and SaaS platforms with TanStack Start." },
      { property: "og:description", content: "Build production-ready complex full-stack applications and SaaS platforms with TanStack Start." },
      { name: "twitter:description", content: "Build production-ready complex full-stack applications and SaaS platforms with TanStack Start." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/668676cb-4395-42a3-b804-05c90796bab4/id-preview-10bf5397--883d5d6d-868a-4741-aeec-27b8cfe6b528.lovable.app-1782752479763.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/668676cb-4395-42a3-b804-05c90796bab4/id-preview-10bf5397--883d5d6d-868a-4741-aeec-27b8cfe6b528.lovable.app-1782752479763.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", type: "image/png", href: "/icon-512.png" },
      { rel: "apple-touch-icon", href: "/icon-512.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      { rel: "dns-prefetch", href: "https://jxvnugnnwxesyjozkrhy.supabase.co" },
      {
        rel: "preload",
        as: "style",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Figtree:wght@300;400;500;600;700&family=Noto+Nastaliq+Urdu:wght@400;600;700&display=swap",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Figtree:wght@300;400;500;600;700&family=Noto+Nastaliq+Urdu:wght@400;600;700&display=swap",
      },
      // hreflang — language toggle is client-side; both variants live at the same URL.
      { rel: "alternate", hrefLang: "en-PK", href: "/" },
      { rel: "alternate", hrefLang: "ur-PK", href: "/" },
      { rel: "alternate", hrefLang: "x-default", href: "/" },
    ],

  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isApp = pathname.startsWith("/admin") || pathname.startsWith("/auth");

  if (isApp) {
    return (
      <QueryClientProvider client={queryClient}>
        <LanguageProvider>
          <Outlet />
        </LanguageProvider>
      </QueryClientProvider>
    );
  }

  return (
    <>
      <SmoothScroll />
      <PageEnterAnimation />
      <QueryClientProvider client={queryClient}>
        <LanguageProvider>
          <TopLanguageBar />
          <NavBar />
          <TopProgressBar />
          <main
            role="main"
            id="main"
            className="ss-route-fade"
            style={{ paddingTop: "var(--nav-offset)" }}
          >
            <Outlet />
          </main>
          <Footer />
          <DeferredWidget />
        </LanguageProvider>
      </QueryClientProvider>
    </>
  );
}
