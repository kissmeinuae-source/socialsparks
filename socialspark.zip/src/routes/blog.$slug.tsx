import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { getPostBySlug } from "@/lib/cms.functions";
import { useLanguage } from "@/lib/language";
import { renderMarkdown } from "@/lib/markdown";
import { absolute, articleSchema, breadcrumbSchema } from "@/lib/seo";

const postQuery = (slug: string) =>
  queryOptions({
    queryKey: ["public", "blog", "post", slug],
    queryFn: () => getPostBySlug({ data: { slug } }),
  });

export const Route = createFileRoute("/blog/$slug")({
  loader: async ({ params, context }) => {
    const post = await context.queryClient.ensureQueryData(postQuery(params.slug));
    if (!post) throw notFound();
    return post;
  },
  head: ({ params, loaderData }) => {
    const title = loaderData?.seo_title || loaderData?.title_en || "Post";
    const desc = loaderData?.seo_description || loaderData?.excerpt_en || "";
    const image = loaderData?.og_image_url || loaderData?.cover_image_url || undefined;
    const path = `/blog/${params.slug}`;
    return {
      meta: [
        { title: `${title} — Social Spark` },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:url", content: absolute(path) },
        { property: "og:type", content: "article" },
        ...(image ? [{ property: "og:image", content: absolute(image) }, { name: "twitter:image", content: absolute(image) }] : []),
      ],
      links: [{ rel: "canonical", href: absolute(path) }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify(
            articleSchema({
              headline: title,
              description: desc,
              image,
              path,
              datePublished: loaderData?.published_at ?? null,
              dateModified: loaderData?.updated_at ?? loaderData?.published_at ?? null,
            }),
          ),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify(
            breadcrumbSchema([
              { name: "Home", path: "/" },
              { name: "Blog", path: "/blog" },
              { name: title, path },
            ]),
          ),
        },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-[720px] px-6 py-32 text-center">
      <h1 className="text-navy">Post not found</h1>
      <Link to="/blog" className="mt-6 inline-block text-gold underline">
        Back to all posts
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-[720px] px-6 py-32 text-center">
      <h1 className="text-navy">Couldn't load this post</h1>
      <p style={{ color: "var(--ss-slate)" }}>{error.message}</p>
    </div>
  ),
  component: BlogPost,
});

function BlogPost() {
  const { slug } = Route.useParams();
  const { data: post } = useSuspenseQuery(postQuery(slug));
  const { lang } = useLanguage();

  if (!post) return null;

  const useUr = lang === "ur" && (post.title_ur || post.body_ur);
  const title = useUr && post.title_ur ? post.title_ur : post.title_en;
  const body = useUr && post.body_ur ? post.body_ur : post.body_en;
  const dir = useUr ? "rtl" : "ltr";
  const date = post.published_at
    ? new Date(post.published_at).toLocaleDateString(lang === "ur" ? "ur-PK" : "en-US", {
        month: "short", day: "numeric", year: "numeric",
      })
    : null;

  return (
    <article style={{ background: "var(--ss-paper)", padding: "120px 24px 144px" }}>
      <div className="mx-auto max-w-[720px]">
        <FadeSlide>
          <Link to="/blog" className="text-gold" style={{ fontSize: 13 }}>
            ← All posts
          </Link>
        </FadeSlide>

        <FadeSlide delay={80}>
          <div className="mt-10">
            <div className="t-label text-gold">{post.category}</div>
            <h1
              className="mt-3 text-navy"
              dir={dir}
              style={{ fontSize: "clamp(32px, 5vw, 52px)", lineHeight: 1.05 }}
            >
              {title}
            </h1>
            <div
              className="mt-5 flex flex-wrap items-center gap-3"
              style={{ color: "var(--ss-ash)", fontSize: 13 }}
            >
              <span>By {post.author_name}</span>
              {date && <><span>·</span><span>{date}</span></>}
              <span>·</span>
              <span>{post.read_time}</span>
            </div>
          </div>
        </FadeSlide>

        {post.cover_image_url && (
          <FadeSlide delay={120}>
            <img
              src={post.cover_image_url}
              alt=""
              loading="eager"
              style={{
                width: "100%",
                marginTop: 32,
                borderRadius: 14,
                display: "block",
                aspectRatio: "16 / 9",
                objectFit: "cover",
              }}
            />
          </FadeSlide>
        )}

        <FadeSlide delay={140}>
          <div
            className="mt-12"
            dir={dir}
            style={{ color: "var(--ss-slate)", fontSize: 17, lineHeight: 1.85 }}
          >
            {body
              ? renderMarkdown(body)
              : <p style={{ color: "var(--ss-ash)" }}>This post has no content yet.</p>}
          </div>
        </FadeSlide>

        <FadeSlide delay={200}>
          <div
            className="mt-16 text-center"
            style={{ background: "var(--ss-ink)", padding: "48px 32px", borderRadius: 14 }}
          >
            <h3 className="text-white" style={{ fontSize: 24 }}>
              {lang === "ur" ? "گفتگو کرنا چاہتے ہیں؟" : "Ready to grow your business?"}
            </h3>
            <p
              className="mx-auto mt-3 max-w-[440px]"
              style={{ color: "var(--ss-ash)", fontSize: 15 }}
            >
              {lang === "ur"
                ? "ایک مفت 30 منٹ کی کال بُک کریں۔ ہم آپ کی موجودہ موجودگی کا جائزہ لیں گے۔"
                : "Book a free 30-minute call. We'll review your current presence and show you exactly what to fix first."}
            </p>
            <Link
              to="/book"
              className="mt-6 inline-block"
              style={{
                background: "var(--ss-gold)",
                color: "var(--ss-ink)",
                padding: "14px 28px",
                borderRadius: 6,
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 14,
                textDecoration: "none",
                marginTop: 24,
              }}
            >
              {lang === "ur" ? "مفت کال بُک کریں →" : "Book a free call →"}
            </Link>
          </div>
        </FadeSlide>
      </div>
    </article>
  );
}
