import { createFileRoute } from "@tanstack/react-router";
import { Pricing } from "@/components/home/Pricing";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useState } from "react";
import { absolute, breadcrumbSchema, faqPageSchema, serviceSchema } from "@/lib/seo";

const PRICING_FAQS = [
  { q: "Are there any contracts?", a: "No. Every plan is month-to-month. Cancel anytime with 14 days' notice." },
  { q: "Is ad spend included in the price?", a: "Ad spend is separate and billed directly to your card or wallet — we never mark it up." },
  { q: "Can I switch plans later?", a: "Yes, you can move up or down at the next billing cycle. We'll pro-rate the difference." },
  { q: "What payment methods do you accept?", a: "Bank transfer, JazzCash, EasyPaisa, and major debit/credit cards." },
  { q: "Do prices include sales tax?", a: "Prices are listed exclusive of GST. Tax is added on the invoice where applicable." },
];

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Social Spark" },
      {
        name: "description",
        content:
          "Transparent monthly pricing for Pakistani SMBs and public figures. No contracts. Compare every feature side by side.",
      },
      { property: "og:title", content: "Pricing — Social Spark" },
      {
        property: "og:description",
        content:
          "Three plans, no contracts, full feature breakdown. Designed for Pakistani businesses and personalities.",
      },
      { property: "og:url", content: absolute("/pricing") },
      { property: "og:image", content: absolute("/og-default.jpg") },
      { name: "twitter:image", content: absolute("/og-default.jpg") },
    ],
    links: [{ rel: "canonical", href: absolute("/pricing") }],
    scripts: [
      { type: "application/ld+json", children: JSON.stringify(faqPageSchema(PRICING_FAQS)) },
      {
        type: "application/ld+json",
        children: JSON.stringify(
          serviceSchema({
            name: "Social Media Management & Paid Ads",
            description: "Monthly retainer covering social content, paid ads, and reporting for Pakistani businesses.",
            path: "/pricing",
            price: "From 75000",
            priceCurrency: "PKR",
          }),
        ),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify(
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Pricing", path: "/pricing" },
          ]),
        ),
      },
    ],
  }),
  component: PricingPage,
});

const features = [
  { row: "Posts per month", s: "12", g: "20", p: "30+" },
  { row: "Stories per week", s: "3", g: "Daily", p: "Daily" },
  { row: "Reels per month", s: "2", g: "6", p: "12" },
  { row: "Strategy calls", s: "Quarterly", g: "Monthly", p: "Weekly" },
  { row: "Paid ads management", s: "—", g: "✓", p: "✓" },
  { row: "WhatsApp catalogue setup", s: "—", g: "✓", p: "✓" },
  { row: "Google Business optimisation", s: "✓", g: "✓", p: "✓" },
  { row: "Monthly performance report", s: "✓", g: "✓", p: "✓" },
  { row: "Dedicated account lead", s: "—", g: "—", p: "✓" },
  { row: "Quarterly photoshoot", s: "—", g: "—", p: "✓" },
];

const faqs = [
  {
    q: "Are there any contracts?",
    a: "No. Every plan is month-to-month. Cancel anytime with 14 days' notice.",
  },
  {
    q: "Is ad spend included in the price?",
    a: "Ad spend is separate and billed directly to your card or wallet — we never mark it up.",
  },
  {
    q: "Can I switch plans later?",
    a: "Yes, you can move up or down at the next billing cycle. We'll pro-rate the difference.",
  },
  {
    q: "What payment methods do you accept?",
    a: "Bank transfer, JazzCash, EasyPaisa, and major debit/credit cards.",
  },
  {
    q: "Do prices include sales tax?",
    a: "Prices are listed exclusive of GST. Tax is added on the invoice where applicable.",
  },
];

function PricingPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <>
      <Pricing />

      {/* Comparison table */}
      <section style={{ background: "var(--ss-paper)", padding: "0 48px 112px" }}>
        <div className="mx-auto max-w-[1080px]">
          <FadeSlide>
            <h2 className="text-navy">Compare every feature.</h2>
          </FadeSlide>

          <FadeSlide delay={80}>
            <div
              className="mt-10 overflow-hidden"
              style={{
                background: "white",
                border: "1px solid var(--ss-rule)",
                borderRadius: 14,
              }}
            >
              <div
                className="grid items-center px-6 py-5"
                style={{
                  gridTemplateColumns: "1.6fr 1fr 1fr 1fr",
                  background: "var(--ss-smoke)",
                }}
              >
                <div className="t-label" style={{ color: "var(--ss-ash)" }}>
                  FEATURE
                </div>
                {["Starter", "Growth", "Premium"].map((p) => (
                  <div
                    key={p}
                    className="text-navy"
                    style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 16 }}
                  >
                    {p}
                  </div>
                ))}
              </div>
              {features.map((f, i) => (
                <div
                  key={f.row}
                  className="grid items-center px-6 py-4"
                  style={{
                    gridTemplateColumns: "1.6fr 1fr 1fr 1fr",
                    borderTop: i === 0 ? "none" : "1px solid var(--ss-rule)",
                  }}
                >
                  <div style={{ color: "var(--ss-slate)", fontSize: 14 }}>{f.row}</div>
                  {[f.s, f.g, f.p].map((v, idx) => (
                    <div
                      key={idx}
                      style={{
                        color: v === "—" ? "var(--ss-ash)" : "var(--ss-navy)",
                        fontSize: 14,
                        fontWeight: v === "✓" ? 700 : 500,
                      }}
                    >
                      {v === "✓" ? <span className="text-gold">✓</span> : v}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </FadeSlide>
        </div>
      </section>

      {/* Pricing FAQ */}
      <section style={{ background: "var(--ss-paper)", padding: "0 48px 144px" }}>
        <div className="mx-auto grid max-w-[1080px] gap-12 md:grid-cols-[40fr_60fr]">
          <FadeSlide>
            <div>
              <div className="t-label text-gold">PRICING FAQ</div>
              <h2 className="mt-4 text-navy">Common questions.</h2>
            </div>
          </FadeSlide>
          <FadeSlide delay={100}>
            <div>
              {faqs.map((f, i) => {
                const isOpen = open === i;
                return (
                  <div
                    key={f.q}
                    style={{
                      borderTop: i === 0 ? "1px solid var(--ss-rule)" : undefined,
                      borderBottom: "1px solid var(--ss-rule)",
                    }}
                  >
                    <button
                      onClick={() => setOpen(isOpen ? null : i)}
                      className="flex w-full items-center justify-between py-5 text-left"
                      style={{
                        background: "transparent",
                        border: "none",
                        cursor: "pointer",
                        fontFamily: "var(--font-display)",
                        fontWeight: 700,
                        fontSize: 16,
                        color: isOpen ? "var(--ss-gold)" : "var(--ss-navy)",
                      }}
                    >
                      {f.q}
                      <span
                        style={{
                          transition: "transform 250ms",
                          transform: isOpen ? "rotate(45deg)" : "none",
                          color: "var(--ss-gold)",
                        }}
                      >
                        +
                      </span>
                    </button>
                    <div
                      style={{
                        display: "grid",
                        gridTemplateRows: isOpen ? "1fr" : "0fr",
                        transition: "grid-template-rows 280ms ease",
                      }}
                    >
                      <div style={{ overflow: "hidden" }}>
                        <p
                          className="pb-5"
                          style={{ color: "var(--ss-slate)", fontSize: 15, lineHeight: 1.7 }}
                        >
                          {f.a}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </FadeSlide>
        </div>
      </section>
    </>
  );
}
