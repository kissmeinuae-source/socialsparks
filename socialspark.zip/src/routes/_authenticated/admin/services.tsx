import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listAllServices, upsertService, deleteService } from "@/lib/cms.functions";

export const Route = createFileRoute("/_authenticated/admin/services")({
  head: () => ({ meta: [{ title: "Services — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

type Row = Awaited<ReturnType<typeof listAllServices>>[number];
type Draft = Partial<Row> & { slug: string; title_en: string };

const empty: Draft = {
  slug: "",
  title_en: "",
  title_ur: "",
  summary_en: "",
  summary_ur: "",
  body_en: "",
  body_ur: "",
  icon: "",
  published: true,
  sort_order: 0,
};

function Page() {
  const qc = useQueryClient();
  const { data } = useSuspenseQuery({ queryKey: ["admin", "services"], queryFn: () => listAllServices() });
  const [draft, setDraft] = useState<Draft | null>(null);

  const save = useMutation({
    mutationFn: (d: Draft) =>
      upsertService({
        data: {
          id: d.id,
          slug: d.slug,
          title_en: d.title_en,
          title_ur: d.title_ur ?? null,
          summary_en: d.summary_en ?? null,
          summary_ur: d.summary_ur ?? null,
          body_en: d.body_en ?? null,
          body_ur: d.body_ur ?? null,
          icon: d.icon ?? null,
          published: d.published ?? true,
          sort_order: d.sort_order ?? 0,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "services"] });
      qc.invalidateQueries({ queryKey: ["public", "services"] });
      setDraft(null);
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteService({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "services"] });
      qc.invalidateQueries({ queryKey: ["public", "services"] });
    },
  });

  return (
    <div>
      <header style={{ marginBottom: 22, display: "flex", justifyContent: "space-between", alignItems: "end", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>CMS · Services</div>
          <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>Service offerings ({data.length})</h1>
        </div>
        <button onClick={() => setDraft({ ...empty })} style={btnPrimary}>+ New service</button>
      </header>

      <div style={card}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 14 }}>
          <thead>
            <tr style={{ textAlign: "left", color: "var(--ss-ash)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              <th style={th}>#</th>
              <th style={th}>Title</th>
              <th style={th}>Slug</th>
              <th style={th}>Summary</th>
              <th style={th}>Status</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 && (
              <tr><td colSpan={6} style={{ padding: 40, textAlign: "center", color: "var(--ss-ash)" }}>No services yet — add the first one.</td></tr>
            )}
            {data.map((row) => (
              <tr key={row.id} style={{ borderTop: "1px solid var(--ss-line)" }}>
                <td style={td}>{row.sort_order}</td>
                <td style={td}><strong>{row.title_en}</strong>{row.title_ur && <div style={{ color: "var(--ss-ash)", fontSize: 12, direction: "rtl" }}>{row.title_ur}</div>}</td>
                <td style={td}><code style={{ fontSize: 12 }}>{row.slug}</code></td>
                <td style={{ ...td, maxWidth: 320 }}>
                  <div style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={row.summary_en ?? ""}>{row.summary_en ?? "—"}</div>
                </td>
                <td style={td}><span style={pill(row.published ? "#5DBE89" : "#C8C2B0")}>{row.published ? "Published" : "Draft"}</span></td>
                <td style={td}>
                  <button onClick={() => setDraft(row as Draft)} style={btnGhost}>Edit</button>
                  <button onClick={() => confirm(`Delete "${row.title_en}"?`) && del.mutate(row.id)} style={{ ...btnGhost, color: "crimson", marginLeft: 6 }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {draft && (
        <Editor draft={draft} onChange={setDraft} onClose={() => setDraft(null)} onSave={() => save.mutate(draft)} saving={save.isPending} error={save.error ? (save.error as Error).message : null} />
      )}
    </div>
  );
}

function Editor({ draft, onChange, onClose, onSave, saving, error }: { draft: Draft; onChange: (d: Draft) => void; onClose: () => void; onSave: () => void; saving: boolean; error: string | null }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(14,27,61,0.5)", zIndex: 80, display: "flex", justifyContent: "flex-end" }}>
      <form onClick={(e) => e.stopPropagation()} onSubmit={(e) => { e.preventDefault(); onSave(); }} style={{ width: "min(620px, 100vw)", background: "#fff", height: "100vh", overflowY: "auto", display: "flex", flexDirection: "column" }}>
        <header style={{ padding: "22px 26px", borderBottom: "1px solid var(--ss-line)", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 26, color: "var(--ss-ink)" }}>{draft.id ? "Edit service" : "New service"}</h2>
          <button type="button" onClick={onClose} aria-label="Close" style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer", color: "var(--ss-ash)" }}>×</button>
        </header>

        <div style={{ padding: 26, flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
          <Row label="Slug" required>
            <input value={draft.slug} onChange={(e) => onChange({ ...draft, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-") })} required pattern="[a-z0-9-]+" style={input} />
          </Row>
          <div style={twoCol}>
            <Row label="Title (EN)" required><input value={draft.title_en} onChange={(e) => onChange({ ...draft, title_en: e.target.value })} required style={input} /></Row>
            <Row label="Title (UR)"><input dir="rtl" value={draft.title_ur ?? ""} onChange={(e) => onChange({ ...draft, title_ur: e.target.value })} style={input} /></Row>
          </div>
          <Row label="Summary (EN)"><textarea value={draft.summary_en ?? ""} onChange={(e) => onChange({ ...draft, summary_en: e.target.value })} rows={3} style={textarea} /></Row>
          <Row label="Summary (UR)"><textarea dir="rtl" value={draft.summary_ur ?? ""} onChange={(e) => onChange({ ...draft, summary_ur: e.target.value })} rows={3} style={textarea} /></Row>
          <Row label="Body (EN) — long form (optional)"><textarea value={draft.body_en ?? ""} onChange={(e) => onChange({ ...draft, body_en: e.target.value })} rows={6} style={textarea} /></Row>
          <Row label="Body (UR) — long form (optional)"><textarea dir="rtl" value={draft.body_ur ?? ""} onChange={(e) => onChange({ ...draft, body_ur: e.target.value })} rows={6} style={textarea} /></Row>
          <div style={twoCol}>
            <Row label="Icon (emoji/key, optional)"><input value={draft.icon ?? ""} onChange={(e) => onChange({ ...draft, icon: e.target.value })} style={input} /></Row>
            <Row label="Sort order"><input type="number" value={draft.sort_order ?? 0} onChange={(e) => onChange({ ...draft, sort_order: Number(e.target.value) })} style={input} /></Row>
          </div>
          <label style={checkboxRow}>
            <input type="checkbox" checked={!!draft.published} onChange={(e) => onChange({ ...draft, published: e.target.checked })} />
            Published
          </label>

          {error && <p style={{ color: "crimson", fontFamily: "var(--font-sans)", fontSize: 13, margin: 0 }}>{error}</p>}
        </div>

        <footer style={{ padding: "16px 26px", borderTop: "1px solid var(--ss-line)", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fff", position: "sticky", bottom: 0 }}>
          <button type="button" onClick={onClose} style={btnGhost}>Cancel</button>
          <button type="submit" disabled={saving} style={{ ...btnPrimary, opacity: saving ? 0.6 : 1 }}>{saving ? "Saving…" : "Save"}</button>
        </footer>
      </form>
    </div>
  );
}

function Row({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", letterSpacing: "0.04em" }}>
        {label}{required && <span style={{ color: "crimson" }}> *</span>}
      </span>
      {children}
    </label>
  );
}

const card: React.CSSProperties = { background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, overflow: "hidden" };
const th: React.CSSProperties = { padding: "14px 16px", fontWeight: 600 };
const td: React.CSSProperties = { padding: "14px 16px", verticalAlign: "top", color: "var(--ss-ink)" };
const input: React.CSSProperties = { padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14, outline: "none", background: "#fff" };
const textarea: React.CSSProperties = { ...input, resize: "vertical" };
const twoCol: React.CSSProperties = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 };
const checkboxRow: React.CSSProperties = { display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", cursor: "pointer" };
const btnPrimary: React.CSSProperties = { padding: "9px 18px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" };
const btnGhost: React.CSSProperties = { padding: "7px 12px", background: "transparent", color: "var(--ss-ink)", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13, cursor: "pointer" };
const pill = (bg: string): React.CSSProperties => ({ display: "inline-block", padding: "3px 8px", borderRadius: 999, fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", background: bg, color: "var(--ss-ink)" });
