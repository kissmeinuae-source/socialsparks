import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useEffect, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listSiteSettings, upsertSiteSetting } from "@/lib/cms.functions";

export const Route = createFileRoute("/_authenticated/admin/settings")({
  head: () => ({ meta: [{ title: "Site Settings — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

type FieldSpec = { key: string; label: string; multiline?: boolean; rtl?: boolean; placeholder?: string };
type GroupSpec = { key: string; title: string; description: string; fields: FieldSpec[] };

const GROUPS: GroupSpec[] = [
  {
    key: "brand",
    title: "Brand",
    description: "Tagline used on the homepage hero and meta descriptions.",
    fields: [
      { key: "tagline_en", label: "Tagline (English)", multiline: true },
      { key: "tagline_ur", label: "Tagline (Urdu)", multiline: true, rtl: true },
    ],
  },
  {
    key: "contact",
    title: "Contact details",
    description: "Shown in the footer, contact page, and Talk-to-Us chat widget.",
    fields: [
      { key: "email", label: "Email", placeholder: "hello@socialspark.pk" },
      { key: "phone", label: "Phone", placeholder: "+92 3XX XXXXXXX" },
      { key: "whatsapp", label: "WhatsApp", placeholder: "+92 3XX XXXXXXX" },
      { key: "address_en", label: "Address (English)" },
      { key: "address_ur", label: "Address (Urdu)", rtl: true },
    ],
  },
  {
    key: "social",
    title: "Social profiles",
    description: "Full URLs. Leave blank to hide an icon.",
    fields: [
      { key: "instagram", label: "Instagram", placeholder: "https://instagram.com/…" },
      { key: "facebook", label: "Facebook", placeholder: "https://facebook.com/…" },
      { key: "linkedin", label: "LinkedIn", placeholder: "https://linkedin.com/company/…" },
      { key: "tiktok", label: "TikTok", placeholder: "https://tiktok.com/@…" },
      { key: "youtube", label: "YouTube", placeholder: "https://youtube.com/@…" },
    ],
  },
];

function Page() {
  const { data } = useSuspenseQuery({ queryKey: ["admin", "settings"], queryFn: () => listSiteSettings() });

  return (
    <div>
      <header style={{ marginBottom: 28 }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>CMS · Site Settings</div>
        <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>Site-wide content</h1>
      </header>

      <div style={{ display: "grid", gap: 18 }}>
        {GROUPS.map((group) => (
          <Group key={group.key} spec={group} initial={(data.find((r) => r.key === group.key)?.value as Record<string, string>) ?? {}} />
        ))}
      </div>
    </div>
  );
}

function Group({ spec, initial }: { spec: GroupSpec; initial: Record<string, string> }) {
  const qc = useQueryClient();
  const [values, setValues] = useState<Record<string, string>>(initial);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  useEffect(() => setValues(initial), [initial]);

  const save = useMutation({
    mutationFn: () => upsertSiteSetting({ data: { key: spec.key, value: values, description: null } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "settings"] });
      qc.invalidateQueries({ queryKey: ["public", "site-settings"] });
      setSavedAt(Date.now());
    },
  });

  return (
    <form
      onSubmit={(e) => { e.preventDefault(); save.mutate(); }}
      style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, padding: "22px 24px" }}
    >
      <div style={{ marginBottom: 14 }}>
        <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24, color: "var(--ss-ink)" }}>{spec.title}</h2>
        <p style={{ margin: "4px 0 0", fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ash)" }}>{spec.description}</p>
      </div>

      <div style={{ display: "grid", gap: 12 }}>
        {spec.fields.map((f) => (
          <label key={f.key} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)" }}>{f.label}</span>
            {f.multiline ? (
              <textarea
                dir={f.rtl ? "rtl" : undefined}
                value={values[f.key] ?? ""}
                onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                placeholder={f.placeholder}
                rows={2}
                style={{ padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14, resize: "vertical" }}
              />
            ) : (
              <input
                dir={f.rtl ? "rtl" : undefined}
                value={values[f.key] ?? ""}
                onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                placeholder={f.placeholder}
                style={{ padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14 }}
              />
            )}
          </label>
        ))}
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 12, marginTop: 18 }}>
        {save.error && <span style={{ color: "crimson", fontFamily: "var(--font-sans)", fontSize: 12 }}>{(save.error as Error).message}</span>}
        {savedAt && !save.isPending && !save.error && <span style={{ color: "var(--ss-ash)", fontFamily: "var(--font-sans)", fontSize: 12 }}>Saved</span>}
        <button type="submit" disabled={save.isPending} style={{ padding: "9px 18px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer", opacity: save.isPending ? 0.6 : 1 }}>
          {save.isPending ? "Saving…" : "Save changes"}
        </button>
      </div>
    </form>
  );
}
