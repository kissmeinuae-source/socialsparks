import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useMemo, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listInbox, postInboxNote } from "@/lib/admin/inbox.functions";

export const Route = createFileRoute("/_authenticated/admin/inbox")({
  component: () => (
    <Suspense fallback={<div style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</div>}>
      <InboxPage />
    </Suspense>
  ),
});

const CHANNELS = ["all", "form", "email", "whatsapp", "chat", "note"] as const;

function InboxPage() {
  const [channel, setChannel] = useState<string>("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const qc = useQueryClient();

  const { data } = useSuspenseQuery({
    queryKey: ["inbox", channel],
    queryFn: () => listInbox({ data: { channel, limit: 200 } }),
  });

  const selected = useMemo(() => data.find((d) => d.id === selectedId) ?? data[0] ?? null, [data, selectedId]);

  const sendMut = useMutation({
    mutationFn: () =>
      postInboxNote({
        data: {
          leadId: selected?.lead_id ?? undefined,
          channel: "note",
          subject: selected?.subject ?? undefined,
          body: reply,
        },
      }),
    onSuccess: () => {
      setReply("");
      qc.invalidateQueries({ queryKey: ["inbox"] });
    },
  });

  return (
    <div>
      <header style={{ marginBottom: 18 }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>Operate · Inbox</div>
        <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>
          Omnichannel inbox
        </h1>
        <p style={{ marginTop: 6, fontFamily: "var(--font-sans)", color: "var(--ss-ash)", fontSize: 14, maxWidth: 540 }}>
          Every form submission, email reply, WhatsApp ping and internal note in one timeline.
        </p>
      </header>

      <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
        {CHANNELS.map((c) => (
          <button
            key={c}
            onClick={() => setChannel(c)}
            style={{
              padding: "6px 14px",
              borderRadius: 999,
              border: "1px solid var(--ss-line)",
              background: channel === c ? "var(--ss-ink)" : "#fff",
              color: channel === c ? "#fff" : "var(--ss-ink)",
              fontFamily: "var(--font-sans)",
              fontSize: 12,
              fontWeight: 600,
              cursor: "pointer",
              textTransform: "capitalize",
            }}
          >
            {c}
          </button>
        ))}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(280px, 360px) 1fr",
          gap: 18,
          background: "#fff",
          border: "1px solid var(--ss-line)",
          borderRadius: 18,
          minHeight: 480,
          overflow: "hidden",
        }}
        className="inbox-grid"
      >
        <ul style={{ listStyle: "none", margin: 0, padding: 0, borderRight: "1px solid var(--ss-line)", overflowY: "auto", maxHeight: 640 }}>
          {data.length === 0 && (
            <li style={{ padding: 28, color: "var(--ss-ash)", fontFamily: "var(--font-sans)", fontSize: 14 }}>
              Quiet here. Submissions and replies will appear in real time.
            </li>
          )}
          {data.map((m) => {
            const active = selected?.id === m.id;
            return (
              <li key={m.id}>
                <button
                  onClick={() => setSelectedId(m.id)}
                  style={{
                    width: "100%",
                    textAlign: "left",
                    padding: "14px 16px",
                    background: active ? "#FFFBEC" : "transparent",
                    border: "none",
                    borderBottom: "1px solid var(--ss-line)",
                    cursor: "pointer",
                    display: "flex",
                    flexDirection: "column",
                    gap: 4,
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: m.direction === "in" ? "var(--ss-ink)" : "var(--ss-ash)" }}>
                      {m.channel} · {m.direction}
                    </span>
                    <span style={{ fontSize: 11, color: "var(--ss-ash)" }}>{new Date(m.created_at).toLocaleString()}</span>
                  </div>
                  <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ink)", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {m.subject ?? "(no subject)"}
                  </div>
                  <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {m.body.slice(0, 100)}
                  </div>
                </button>
              </li>
            );
          })}
        </ul>

        <div style={{ display: "flex", flexDirection: "column", padding: 24, minHeight: 480 }}>
          {selected ? (
            <>
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)" }}>
                  {selected.channel} · {selected.direction}
                </div>
                <h2 style={{ margin: "4px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24, color: "var(--ss-ink)" }}>
                  {selected.subject ?? "(no subject)"}
                </h2>
                <div style={{ marginTop: 4, fontSize: 12, color: "var(--ss-ash)" }}>
                  {new Date(selected.created_at).toLocaleString()}
                </div>
              </div>
              <pre style={{ flex: 1, whiteSpace: "pre-wrap", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", margin: 0 }}>{selected.body}</pre>

              <div style={{ marginTop: 18, paddingTop: 18, borderTop: "1px solid var(--ss-line)" }}>
                <label style={{ display: "block", fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)", marginBottom: 6 }}>
                  Internal reply / note
                </label>
                <textarea
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  rows={3}
                  placeholder="Leave a note attached to this lead…"
                  style={{ width: "100%", padding: 12, border: "1px solid var(--ss-line)", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 14, outline: "none", resize: "vertical" }}
                />
                <div style={{ marginTop: 8, display: "flex", justifyContent: "flex-end" }}>
                  <button
                    onClick={() => reply.trim() && sendMut.mutate()}
                    disabled={!reply.trim() || sendMut.isPending}
                    style={{
                      padding: "9px 18px",
                      borderRadius: 10,
                      background: "var(--ss-ink)",
                      color: "#fff",
                      border: "none",
                      fontFamily: "var(--font-sans)",
                      fontSize: 13,
                      fontWeight: 600,
                      cursor: reply.trim() ? "pointer" : "not-allowed",
                      opacity: reply.trim() ? 1 : 0.5,
                    }}
                  >
                    {sendMut.isPending ? "Saving…" : "Save note"}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div style={{ margin: "auto", color: "var(--ss-ash)", fontFamily: "var(--font-sans)" }}>Select a message to open it.</div>
          )}
        </div>
      </div>

      <style>{`@media (max-width: 820px) { .inbox-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}
