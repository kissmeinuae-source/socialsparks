import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Suspense, useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { listLeads, updateLeadStatus } from "@/lib/leads.functions";
import { bulkUpdateLeadStatus, bulkDeleteLeads, updateLeadInline } from "@/lib/admin/leads-bulk.functions";
import { LeadDrawer } from "@/components/admin/LeadDrawer";
import { SavedViewsBar } from "@/components/admin/SavedViewsBar";
import { BulkBar, BulkAction } from "@/components/admin/BulkBar";
import { EditableCell } from "@/components/admin/EditableCell";
import { useSelection, useHotkey, useDebounced } from "@/lib/admin/hooks";

const searchSchema = z.object({ open: z.string().uuid().optional() });

export const Route = createFileRoute("/_authenticated/admin/leads")({
  validateSearch: searchSchema,
  component: () => (
    <Suspense fallback={<div style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</div>}>
      <LeadsPage />
    </Suspense>
  ),
});

const STATUSES = ["all", "new", "contacted", "qualified", "won", "lost"] as const;
const TYPES = ["all", "audit", "book", "contact", "chat"] as const;
type Status = Exclude<(typeof STATUSES)[number], "all">;

function LeadsPage() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const [status, setStatus] = useState<string>("all");
  const [type, setType] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const debounced = useDebounced(searchTerm, 220);
  const sel = useSelection<string>();
  const qc = useQueryClient();

  const { data } = useSuspenseQuery({
    queryKey: ["leads", status, type, debounced],
    queryFn: () => listLeads({ data: { status, type, search: debounced, limit: 200 } }),
  });

  const setStatusMut = useMutation({
    mutationFn: (vars: { leadId: string; status: Status }) => updateLeadStatus({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leads"] });
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
    },
  });

  const bulkStatusMut = useMutation({
    mutationFn: (s: Status) => bulkUpdateLeadStatus({ data: { ids: sel.list, status: s } }),
    onSuccess: () => {
      sel.clear();
      qc.invalidateQueries({ queryKey: ["leads"] });
    },
  });

  const bulkDelMut = useMutation({
    mutationFn: () => bulkDeleteLeads({ data: { ids: sel.list } }),
    onSuccess: () => {
      sel.clear();
      qc.invalidateQueries({ queryKey: ["leads"] });
    },
  });

  const inlineMut = useMutation({
    mutationFn: (vars: { id: string; patch: Record<string, string | null> }) =>
      updateLeadInline({ data: { id: vars.id, patch: vars.patch } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leads"] }),
  });

  // shortcuts
  useHotkey("shift+a", () => sel.setAll(data.map((d) => d.id), sel.count !== data.length));
  useHotkey("Escape", () => sel.clear());
  useHotkey("backspace", () => {
    if (sel.count > 0 && confirm(`Delete ${sel.count} lead(s)?`)) bulkDelMut.mutate();
  });

  // Sync ?open=… from command palette
  useEffect(() => {
    if (search.open) {
      // drawer reads from local state; lift it
    }
  }, [search.open]);

  function exportCSV() {
    const rows = sel.count > 0 ? data.filter((d) => sel.has(d.id)) : data;
    const headers = ["created_at", "type", "status", "name", "email", "phone", "business", "source_page", "message"];
    const escape = (v: unknown) => {
      const s = v == null ? "" : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const out = [headers.join(",")];
    for (const r of rows) out.push(headers.map((h) => escape((r as Record<string, unknown>)[h])).join(","));
    const blob = new Blob([out.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `leads-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const currentView = useMemo(
    () => ({ filters: { status, type, search: debounced }, columns: [], sort: {} }),
    [status, type, debounced],
  );

  const activeLead = search.open ?? null;
  const setActiveLead = (id: string | null) =>
    navigate({ search: (prev: { open?: string }) => ({ ...prev, open: id ?? undefined }), replace: true });

  return (
    <div>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "end", flexWrap: "wrap", gap: 16, marginBottom: 18 }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>
            CRM · Leads
          </div>
          <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>
            {data.length} {data.length === 1 ? "lead" : "leads"}
          </h1>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={exportCSV} style={btnSecondary}>Export {sel.count > 0 ? `${sel.count} ` : ""}CSV</button>
        </div>
      </header>

      <SavedViewsBar
        module="leads"
        current={currentView}
        onApply={(v) => {
          const f = v.filters as { status?: string; type?: string; search?: string };
          if (f.status) setStatus(f.status);
          if (f.type) setType(f.type);
          if (typeof f.search === "string") setSearchTerm(f.search);
        }}
      />

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }}>
        <Select label="Status" value={status} onChange={setStatus} options={[...STATUSES]} />
        <Select label="Type" value={type} onChange={setType} options={[...TYPES]} />
        <input
          placeholder="Search name, email, phone…   (⌘K for global)"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            flex: "1 1 240px",
            minWidth: 200,
            padding: "10px 14px",
            border: "1px solid var(--ss-line)",
            borderRadius: 10,
            background: "#fff",
            fontFamily: "var(--font-sans)",
            fontSize: 14,
            outline: "none",
          }}
        />
      </div>

      <div style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 18, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 14 }}>
            <thead>
              <tr style={{ background: "#FAF8F2", textAlign: "left" }}>
                <th style={{ ...th, width: 36 }}>
                  <input
                    type="checkbox"
                    aria-label="Select all"
                    checked={data.length > 0 && sel.count === data.length}
                    onChange={(e) => sel.setAll(data.map((d) => d.id), e.target.checked)}
                  />
                </th>
                {["When", "Type", "Name", "Business", "Email", "Phone", "Status"].map((h) => (
                  <th key={h} style={th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.length === 0 && (
                <tr><td colSpan={8} style={{ padding: 40, textAlign: "center", color: "var(--ss-ash)" }}>No leads match these filters.</td></tr>
              )}
              {data.map((lead) => {
                const selected = sel.has(lead.id);
                return (
                  <tr
                    key={lead.id}
                    style={{
                      borderTop: "1px solid var(--ss-line)",
                      cursor: "pointer",
                      background: selected ? "#FFFBEC" : "transparent",
                    }}
                    onClick={(e) => {
                      const tag = (e.target as HTMLElement).tagName.toLowerCase();
                      if (["input", "select", "button", "kbd"].includes(tag)) return;
                      setActiveLead(lead.id);
                    }}
                  >
                    <td style={td} onClick={(e) => e.stopPropagation()}>
                      <input type="checkbox" checked={selected} onChange={() => sel.toggle(lead.id)} aria-label={`Select ${lead.name ?? lead.id}`} />
                    </td>
                    <td style={td}>
                      <div style={{ whiteSpace: "nowrap" }}>{new Date(lead.created_at).toLocaleDateString()}</div>
                      <div style={{ color: "var(--ss-ash)", fontSize: 11 }}>{new Date(lead.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
                    </td>
                    <td style={td}><Pill>{lead.type}</Pill></td>
                    <td style={td} onClick={(e) => e.stopPropagation()}>
                      <EditableCell value={lead.name} placeholder="Add name" onSave={async (v) => { await inlineMut.mutateAsync({ id: lead.id, patch: { name: v || null } }); }} />
                    </td>
                    <td style={td} onClick={(e) => e.stopPropagation()}>
                      <EditableCell value={lead.business} placeholder="Add business" onSave={async (v) => { await inlineMut.mutateAsync({ id: lead.id, patch: { business: v || null } }); }} />
                    </td>
                    <td style={td} onClick={(e) => e.stopPropagation()}>
                      <EditableCell value={lead.email} type="email" placeholder="Add email" onSave={async (v) => { await inlineMut.mutateAsync({ id: lead.id, patch: { email: v || null } }); }} />
                    </td>
                    <td style={td} onClick={(e) => e.stopPropagation()}>
                      <EditableCell value={lead.phone} type="tel" placeholder="Add phone" onSave={async (v) => { await inlineMut.mutateAsync({ id: lead.id, patch: { phone: v || null } }); }} />
                    </td>
                    <td style={td} onClick={(e) => e.stopPropagation()}>
                      <select
                        value={lead.status}
                        onChange={(e) => setStatusMut.mutate({ leadId: lead.id, status: e.target.value as Status })}
                        style={{
                          padding: "6px 10px",
                          borderRadius: 8,
                          border: "1px solid var(--ss-line)",
                          background: "#fff",
                          fontFamily: "var(--font-sans)",
                          fontSize: 13,
                        }}
                      >
                        {(["new", "contacted", "qualified", "won", "lost"] as const).map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <BulkBar count={sel.count} onClear={sel.clear}>
        <BulkAction onClick={() => bulkStatusMut.mutate("contacted")}>Mark contacted</BulkAction>
        <BulkAction onClick={() => bulkStatusMut.mutate("qualified")}>Qualify</BulkAction>
        <BulkAction onClick={() => bulkStatusMut.mutate("won")}>Won</BulkAction>
        <BulkAction onClick={() => bulkStatusMut.mutate("lost")}>Lost</BulkAction>
        <BulkAction onClick={exportCSV}>Export</BulkAction>
        <BulkAction danger onClick={() => { if (confirm(`Delete ${sel.count} lead(s)?`)) bulkDelMut.mutate(); }}>Delete</BulkAction>
      </BulkBar>

      <LeadDrawer leadId={activeLead} onClose={() => setActiveLead(null)} />
    </div>
  );
}

const th: React.CSSProperties = { padding: "12px 14px", fontWeight: 600, fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ss-ash)" };
const td: React.CSSProperties = { padding: "12px 14px", verticalAlign: "middle", color: "var(--ss-ink)" };
const btnSecondary: React.CSSProperties = { padding: "10px 16px", border: "1px solid var(--ss-ink)", background: "transparent", color: "var(--ss-ink)", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" };

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span style={{ display: "inline-block", padding: "3px 9px", borderRadius: 999, background: "var(--ss-gold, #F0C24A)", color: "var(--ss-ink)", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em" }}>
      {children}
    </span>
  );
}

function Select({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)" }}>{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ padding: "9px 12px", borderRadius: 10, border: "1px solid var(--ss-line)", background: "#fff", fontFamily: "var(--font-sans)", fontSize: 13 }}
      >
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}
