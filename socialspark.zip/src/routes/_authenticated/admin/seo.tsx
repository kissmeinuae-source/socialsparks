import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  listSeoOverrides,
  upsertSeoOverride,
  deleteSeoOverride,
  listRedirects,
  upsertRedirect,
  deleteRedirect,
} from "@/lib/admin/seo.functions";

export const Route = createFileRoute("/_authenticated/admin/seo")({
  component: () => (
    <Suspense fallback={<div style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</div>}>
      <SeoPage />
    </Suspense>
  ),
});

function SeoPage() {
  const [tab, setTab] = useState<"meta" | "redirects">("meta");

  return (
    <div>
      <header style={{ marginBottom: 18 }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>Content · SEO console</div>
        <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>
          Search & discovery
        </h1>
        <p style={{ marginTop: 6, fontFamily: "var(--font-sans)", color: "var(--ss-ash)", fontSize: 14, maxWidth: 580 }}>
          Override titles & descriptions per route, manage 301/302 redirects.
        </p>
      </header>

      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        {(["meta", "redirects"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              padding: "8px 16px",
              borderRadius: 999,
              background: tab === t ? "var(--ss-ink)" : "#fff",
              color: tab === t ? "#fff" : "var(--ss-ink)",
              border: "1px solid var(--ss-line)",
              fontFamily: "var(--font-sans)",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              textTransform: "capitalize",
            }}
          >
            {t === "meta" ? "Meta overrides" : "Redirects"}
          </button>
        ))}
      </div>

      {tab === "meta" ? <MetaTab /> : <RedirectsTab />}
    </div>
  );
}

function MetaTab() {
  const qc = useQueryClient();
  const { data: rows } = useSuspenseQuery({ queryKey: ["seo-overrides"], queryFn: () => listSeoOverrides() });
  const [draft, setDraft] = useState({ route: "/", title: "", description: "", canonical: "", og_image: "", noindex: false });

  const saveMut = useMutation({
    mutationFn: (payload: typeof draft) =>
      upsertSeoOverride({
        data: {
          route: payload.route,
          title: payload.title || null,
          description: payload.description || null,
          canonical: payload.canonical || null,
          og_image: payload.og_image || null,
          noindex: payload.noindex,
        },
      }),
    onSuccess: () => {
      setDraft({ route: "/", title: "", description: "", canonical: "", og_image: "", noindex: false });
      qc.invalidateQueries({ queryKey: ["seo-overrides"] });
    },
  });

  const delMut = useMutation({
    mutationFn: (id: string) => deleteSeoOverride({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["seo-overrides"] }),
  });

  return (
    <div style={{ display: "grid", gridTemplateColumns: "minmax(320px, 380px) 1fr", gap: 18 }} className="seo-grid">
      <form
        onSubmit={(e) => { e.preventDefault(); saveMut.mutate(draft); }}
        style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, padding: 18, display: "flex", flexDirection: "column", gap: 10 }}
      >
        <h3 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 22 }}>Add / update override</h3>
        <Field label="Route" value={draft.route} onChange={(v) => setDraft({ ...draft, route: v })} placeholder="/pricing" />
        <Field label="Title" value={draft.title} onChange={(v) => setDraft({ ...draft, title: v })} placeholder="Pricing — Social Spark" />
        <Field label="Description" value={draft.description} onChange={(v) => setDraft({ ...draft, description: v })} placeholder="Up to ~160 chars" textarea />
        <Field label="Canonical" value={draft.canonical} onChange={(v) => setDraft({ ...draft, canonical: v })} placeholder="https://socialspark.pk/pricing" />
        <Field label="OG image" value={draft.og_image} onChange={(v) => setDraft({ ...draft, og_image: v })} placeholder="https://…/og.jpg" />
        <label style={{ display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontSize: 13 }}>
          <input type="checkbox" checked={draft.noindex} onChange={(e) => setDraft({ ...draft, noindex: e.target.checked })} />
          Add <code>noindex</code> on this route
        </label>
        <button type="submit" disabled={saveMut.isPending} style={primaryBtn}>{saveMut.isPending ? "Saving…" : "Save override"}</button>
      </form>

      <div style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#FAF8F2", textAlign: "left" }}>
              {["Route", "Title", "Description", "Noindex", ""].map((h) => <th key={h} style={th}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={5} style={{ padding: 28, color: "var(--ss-ash)", textAlign: "center" }}>No overrides yet — routes use their built-in defaults.</td></tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} style={{ borderTop: "1px solid var(--ss-line)" }}>
                <td style={td}><code>{r.route}</code></td>
                <td style={td}>{r.title ?? "—"}</td>
                <td style={{ ...td, maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={r.description ?? ""}>{r.description ?? "—"}</td>
                <td style={td}>{r.noindex ? "Yes" : "—"}</td>
                <td style={td}><button onClick={() => delMut.mutate(r.id)} style={{ ...primaryBtn, padding: "5px 10px", fontSize: 11, background: "transparent", color: "#b91c1c", border: "1px solid #fecaca" }}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <style>{`@media (max-width: 900px) { .seo-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}

function RedirectsTab() {
  const qc = useQueryClient();
  const { data: rows } = useSuspenseQuery({ queryKey: ["redirects"], queryFn: () => listRedirects() });
  const [draft, setDraft] = useState({ from_path: "/", to_path: "/", code: 301, enabled: true });

  const saveMut = useMutation({
    mutationFn: (payload: typeof draft) => upsertRedirect({ data: payload }),
    onSuccess: () => {
      setDraft({ from_path: "/", to_path: "/", code: 301, enabled: true });
      qc.invalidateQueries({ queryKey: ["redirects"] });
    },
  });
  const toggleMut = useMutation({
    mutationFn: (r: typeof rows[number]) => upsertRedirect({ data: { id: r.id, from_path: r.from_path, to_path: r.to_path, code: r.code, enabled: !r.enabled } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["redirects"] }),
  });
  const delMut = useMutation({
    mutationFn: (id: string) => deleteRedirect({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["redirects"] }),
  });

  return (
    <div style={{ display: "grid", gridTemplateColumns: "minmax(320px, 380px) 1fr", gap: 18 }} className="seo-grid">
      <form onSubmit={(e) => { e.preventDefault(); saveMut.mutate(draft); }} style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, padding: 18, display: "flex", flexDirection: "column", gap: 10 }}>
        <h3 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 22 }}>Add redirect</h3>
        <Field label="From" value={draft.from_path} onChange={(v) => setDraft({ ...draft, from_path: v })} placeholder="/old-pricing" />
        <Field label="To" value={draft.to_path} onChange={(v) => setDraft({ ...draft, to_path: v })} placeholder="/pricing" />
        <label style={{ display: "flex", flexDirection: "column", gap: 6, fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)" }}>
          Code
          <select value={draft.code} onChange={(e) => setDraft({ ...draft, code: Number(e.target.value) })} style={{ padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "inherit", fontSize: 13 }}>
            {[301, 302, 307, 308].map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <button type="submit" disabled={saveMut.isPending} style={primaryBtn}>{saveMut.isPending ? "Saving…" : "Save redirect"}</button>
      </form>

      <div style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#FAF8F2", textAlign: "left" }}>
              {["From", "To", "Code", "Enabled", ""].map((h) => <th key={h} style={th}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={5} style={{ padding: 28, color: "var(--ss-ash)", textAlign: "center" }}>No redirects defined.</td></tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} style={{ borderTop: "1px solid var(--ss-line)" }}>
                <td style={td}><code>{r.from_path}</code></td>
                <td style={td}><code>{r.to_path}</code></td>
                <td style={td}>{r.code}</td>
                <td style={td}>
                  <button onClick={() => toggleMut.mutate(r)} style={{ ...primaryBtn, padding: "5px 10px", fontSize: 11, background: r.enabled ? "var(--ss-gold)" : "transparent", color: "var(--ss-ink)", border: "1px solid var(--ss-line)" }}>{r.enabled ? "On" : "Off"}</button>
                </td>
                <td style={td}><button onClick={() => delMut.mutate(r.id)} style={{ ...primaryBtn, padding: "5px 10px", fontSize: 11, background: "transparent", color: "#b91c1c", border: "1px solid #fecaca" }}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, textarea }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; textarea?: boolean }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)" }}>
      {label}
      {textarea ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={3} style={inputStyle} />
      ) : (
        <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} style={inputStyle} />
      )}
    </label>
  );
}

const inputStyle: React.CSSProperties = { padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13, outline: "none", color: "var(--ss-ink)" };
const primaryBtn: React.CSSProperties = { padding: "10px 16px", borderRadius: 10, background: "var(--ss-ink)", color: "#fff", border: "none", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" };
const th: React.CSSProperties = { padding: "10px 14px", fontWeight: 600, fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ss-ash)" };
const td: React.CSSProperties = { padding: "12px 14px", color: "var(--ss-ink)" };
