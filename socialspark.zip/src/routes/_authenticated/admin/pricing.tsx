import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listAllPricingPlans, upsertPricingPlan, deletePricingPlan } from "@/lib/cms.functions";

export const Route = createFileRoute("/_authenticated/admin/pricing")({
  head: () => ({ meta: [{ title: "Pricing — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

type Feature = { en: string; ur?: string | null };
type Row = Awaited<ReturnType<typeof listAllPricingPlans>>[number];
type Draft = Omit<Partial<Row>, "features"> & {
  slug: string;
  name_en: string;
  price_pkr: number;
  features: Feature[];
};

const empty: Draft = {
  slug: "",
  name_en: "",
  name_ur: "",
  tagline_en: "",
  tagline_ur: "",
  price_pkr: 0,
  period: "mo",
  features: [{ en: "", ur: "" }],
  highlighted: false,
  published: true,
  sort_order: 0,
};

function normalizeFeatures(raw: unknown): Feature[] {
  if (!Array.isArray(raw)) return [];
  const out: Feature[] = [];
  for (const f of raw) {
    if (typeof f === "string" && f.trim()) {
      out.push({ en: f, ur: "" });
    } else if (f && typeof f === "object") {
      const o = f as Record<string, unknown>;
      const en = typeof o.en === "string" ? o.en : "";
      if (en) out.push({ en, ur: typeof o.ur === "string" ? o.ur : "" });
    }
  }
  return out;
}


function Page() {
  const qc = useQueryClient();
  const { data } = useSuspenseQuery({ queryKey: ["admin", "pricing"], queryFn: () => listAllPricingPlans() });
  const [draft, setDraft] = useState<Draft | null>(null);

  const save = useMutation({
    mutationFn: (d: Draft) =>
      upsertPricingPlan({
        data: {
          id: d.id,
          slug: d.slug,
          name_en: d.name_en,
          name_ur: d.name_ur ?? null,
          tagline_en: d.tagline_en ?? null,
          tagline_ur: d.tagline_ur ?? null,
          price_pkr: d.price_pkr,
          period: d.period ?? "mo",
          features: d.features.filter((f) => f.en.trim()),
          highlighted: !!d.highlighted,
          published: d.published ?? true,
          sort_order: d.sort_order ?? 0,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "pricing"] });
      qc.invalidateQueries({ queryKey: ["public", "pricing"] });
      setDraft(null);
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => deletePricingPlan({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "pricing"] });
      qc.invalidateQueries({ queryKey: ["public", "pricing"] });
    },
  });

  function openEdit(row: Row) {
    setDraft({ ...(row as unknown as Draft), features: normalizeFeatures(row.features) });
  }

  return (
    <div>
      <header style={{ marginBottom: 22, display: "flex", justifyContent: "space-between", alignItems: "end", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>CMS · Pricing</div>
          <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>Pricing plans ({data.length})</h1>
        </div>
        <button onClick={() => setDraft({ ...empty })} style={btnPrimary}>+ New plan</button>
      </header>

      <div style={card}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 14 }}>
          <thead>
            <tr style={{ textAlign: "left", color: "var(--ss-ash)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              <th style={th}>#</th>
              <th style={th}>Name</th>
              <th style={th}>Slug</th>
              <th style={th}>Price PKR</th>
              <th style={th}>Features</th>
              <th style={th}>Status</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 && (
              <tr><td colSpan={7} style={{ padding: 40, textAlign: "center", color: "var(--ss-ash)" }}>No plans yet — add your first one.</td></tr>
            )}
            {data.map((row) => {
              const features = normalizeFeatures(row.features);
              return (
                <tr key={row.id} style={{ borderTop: "1px solid var(--ss-line)" }}>
                  <td style={td}>{row.sort_order}</td>
                  <td style={td}><strong>{row.name_en}</strong>{row.tagline_en && <div style={{ color: "var(--ss-ash)", fontSize: 12 }}>{row.tagline_en}</div>}</td>
                  <td style={td}><code style={{ fontSize: 12 }}>{row.slug}</code></td>
                  <td style={td}>{Number(row.price_pkr).toLocaleString()}<span style={{ color: "var(--ss-ash)", fontSize: 12 }}>/{row.period}</span></td>
                  <td style={td}>{features.length}</td>
                  <td style={td}>
                    <span style={pill(row.published ? "#5DBE89" : "#C8C2B0")}>{row.published ? "Published" : "Draft"}</span>
                    {row.highlighted && <span style={{ ...pill("var(--ss-gold, #F0C24A)"), marginLeft: 6 }}>Featured</span>}
                  </td>
                  <td style={td}>
                    <button onClick={() => openEdit(row)} style={btnGhost}>Edit</button>
                    <button onClick={() => confirm(`Delete "${row.name_en}"?`) && del.mutate(row.id)} style={{ ...btnGhost, color: "crimson", marginLeft: 6 }}>Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {draft && (
        <Editor draft={draft} onChange={setDraft} onClose={() => setDraft(null)} onSave={() => save.mutate(draft)} saving={save.isPending} error={save.error ? (save.error as Error).message : null} />
      )}
    </div>
  );
}

function Editor({ draft, onChange, onClose, onSave, saving, error }: { draft: Draft; onChange: (d: Draft) => void; onClose: () => void; onSave: () => void; saving: boolean; error: string | null }) {
  function setFeature(i: number, key: "en" | "ur", val: string) {
    const next = draft.features.slice();
    next[i] = { ...next[i], [key]: val };
    onChange({ ...draft, features: next });
  }
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(14,27,61,0.5)", zIndex: 80, display: "flex", justifyContent: "flex-end" }}>
      <form onClick={(e) => e.stopPropagation()} onSubmit={(e) => { e.preventDefault(); onSave(); }} style={{ width: "min(680px, 100vw)", background: "#fff", height: "100vh", overflowY: "auto", display: "flex", flexDirection: "column" }}>
        <header style={{ padding: "22px 26px", borderBottom: "1px solid var(--ss-line)", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 26, color: "var(--ss-ink)" }}>{draft.id ? "Edit plan" : "New plan"}</h2>
          <button type="button" onClick={onClose} aria-label="Close" style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer", color: "var(--ss-ash)" }}>×</button>
        </header>

        <div style={{ padding: 26, flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
          <Row label="Slug" required>
            <input value={draft.slug} onChange={(e) => onChange({ ...draft, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-") })} required style={input} />
          </Row>
          <div style={twoCol}>
            <Row label="Name (EN)" required><input value={draft.name_en} onChange={(e) => onChange({ ...draft, name_en: e.target.value })} required style={input} /></Row>
            <Row label="Name (UR)"><input dir="rtl" value={draft.name_ur ?? ""} onChange={(e) => onChange({ ...draft, name_ur: e.target.value })} style={input} /></Row>
          </div>
          <Row label="Tagline (EN)"><input value={draft.tagline_en ?? ""} onChange={(e) => onChange({ ...draft, tagline_en: e.target.value })} style={input} /></Row>
          <Row label="Tagline (UR)"><input dir="rtl" value={draft.tagline_ur ?? ""} onChange={(e) => onChange({ ...draft, tagline_ur: e.target.value })} style={input} /></Row>

          <div style={twoCol}>
            <Row label="Price (PKR)" required><input type="number" min={0} value={draft.price_pkr} onChange={(e) => onChange({ ...draft, price_pkr: Number(e.target.value) })} required style={input} /></Row>
            <Row label="Period (e.g. mo)"><input value={draft.period ?? "mo"} onChange={(e) => onChange({ ...draft, period: e.target.value })} style={input} /></Row>
          </div>

          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", letterSpacing: "0.04em" }}>Features (bilingual)</span>
              <button type="button" onClick={() => onChange({ ...draft, features: [...draft.features, { en: "", ur: "" }] })} style={btnGhost}>+ Add feature</button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {draft.features.map((f, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 8 }}>
                  <input placeholder="English" value={f.en} onChange={(e) => setFeature(i, "en", e.target.value)} style={input} />
                  <input dir="rtl" placeholder="اردو" value={f.ur ?? ""} onChange={(e) => setFeature(i, "ur", e.target.value)} style={input} />
                  <button type="button" onClick={() => onChange({ ...draft, features: draft.features.filter((_, j) => j !== i) })} aria-label="Remove" style={{ ...btnGhost, color: "crimson" }}>×</button>
                </div>
              ))}
            </div>
          </div>

          <div style={twoCol}>
            <Row label="Sort order"><input type="number" value={draft.sort_order ?? 0} onChange={(e) => onChange({ ...draft, sort_order: Number(e.target.value) })} style={input} /></Row>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 22 }}>
              <label style={checkboxRow}><input type="checkbox" checked={!!draft.highlighted} onChange={(e) => onChange({ ...draft, highlighted: e.target.checked })} /> Highlighted (most-chosen)</label>
              <label style={checkboxRow}><input type="checkbox" checked={!!draft.published} onChange={(e) => onChange({ ...draft, published: e.target.checked })} /> Published</label>
            </div>
          </div>

          {error && <p style={{ color: "crimson", fontFamily: "var(--font-sans)", fontSize: 13, margin: 0 }}>{error}</p>}
        </div>

        <footer style={{ padding: "16px 26px", borderTop: "1px solid var(--ss-line)", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fff", position: "sticky", bottom: 0 }}>
          <button type="button" onClick={onClose} style={btnGhost}>Cancel</button>
          <button type="submit" disabled={saving} style={{ ...btnPrimary, opacity: saving ? 0.6 : 1 }}>{saving ? "Saving…" : "Save"}</button>
        </footer>
      </form>
    </div>
  );
}

function Row({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", letterSpacing: "0.04em" }}>
        {label}{required && <span style={{ color: "crimson" }}> *</span>}
      </span>
      {children}
    </label>
  );
}

const card: React.CSSProperties = { background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, overflow: "hidden" };
const th: React.CSSProperties = { padding: "14px 16px", fontWeight: 600 };
const td: React.CSSProperties = { padding: "14px 16px", verticalAlign: "top", color: "var(--ss-ink)" };
const input: React.CSSProperties = { padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14, outline: "none", background: "#fff" };
const twoCol: React.CSSProperties = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 };
const checkboxRow: React.CSSProperties = { display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", cursor: "pointer" };
const btnPrimary: React.CSSProperties = { padding: "9px 18px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" };
const btnGhost: React.CSSProperties = { padding: "7px 12px", background: "transparent", color: "var(--ss-ink)", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13, cursor: "pointer" };
const pill = (bg: string): React.CSSProperties => ({ display: "inline-block", padding: "3px 8px", borderRadius: 999, fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", background: bg, color: "var(--ss-ink)" });
