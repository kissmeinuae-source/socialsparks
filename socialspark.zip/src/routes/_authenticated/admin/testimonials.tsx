import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listAllTestimonials, upsertTestimonial, deleteTestimonial } from "@/lib/cms.functions";

export const Route = createFileRoute("/_authenticated/admin/testimonials")({
  head: () => ({ meta: [{ title: "Testimonials — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

type Row = Awaited<ReturnType<typeof listAllTestimonials>>[number];
type Draft = Partial<Row> & { name: string; quote_en: string };

const empty: Draft = {
  name: "",
  role_en: "",
  role_ur: "",
  company: "",
  quote_en: "",
  quote_ur: "",
  avatar_url: "",
  rating: 5,
  featured: false,
  published: true,
  sort_order: 0,
};

function Page() {
  const qc = useQueryClient();
  const { data } = useSuspenseQuery({ queryKey: ["admin", "testimonials"], queryFn: () => listAllTestimonials() });
  const [draft, setDraft] = useState<Draft | null>(null);

  const save = useMutation({
    mutationFn: (d: Draft) =>
      upsertTestimonial({
        data: {
          id: d.id,
          name: d.name,
          role_en: d.role_en ?? null,
          role_ur: d.role_ur ?? null,
          company: d.company ?? null,
          quote_en: d.quote_en,
          quote_ur: d.quote_ur ?? null,
          avatar_url: d.avatar_url ?? null,
          rating: d.rating ?? 5,
          featured: !!d.featured,
          published: d.published ?? true,
          sort_order: d.sort_order ?? 0,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "testimonials"] });
      qc.invalidateQueries({ queryKey: ["public", "testimonials"] });
      setDraft(null);
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteTestimonial({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "testimonials"] });
      qc.invalidateQueries({ queryKey: ["public", "testimonials"] });
    },
  });

  return (
    <div>
      <header style={{ marginBottom: 22, display: "flex", justifyContent: "space-between", alignItems: "end", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>CMS · Testimonials</div>
          <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>Client quotes ({data.length})</h1>
        </div>
        <button onClick={() => setDraft({ ...empty })} style={btnPrimary}>+ New testimonial</button>
      </header>

      <div style={card}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 14 }}>
          <thead>
            <tr style={{ textAlign: "left", color: "var(--ss-ash)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              <th style={th}>Order</th>
              <th style={th}>Name</th>
              <th style={th}>Company</th>
              <th style={th}>Quote</th>
              <th style={th}>★</th>
              <th style={th}>Status</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 && (
              <tr><td colSpan={7} style={{ padding: 40, textAlign: "center", color: "var(--ss-ash)" }}>No testimonials yet — add the first one.</td></tr>
            )}
            {data.map((row) => (
              <tr key={row.id} style={{ borderTop: "1px solid var(--ss-line)" }}>
                <td style={td}>{row.sort_order}</td>
                <td style={td}>
                  <strong>{row.name}</strong>
                  {row.role_en && <div style={{ color: "var(--ss-ash)", fontSize: 12 }}>{row.role_en}</div>}
                </td>
                <td style={td}>{row.company ?? "—"}</td>
                <td style={{ ...td, maxWidth: 320 }}>
                  <div style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={row.quote_en}>{row.quote_en}</div>
                </td>
                <td style={td}>{row.rating}</td>
                <td style={td}>
                  <span style={pill(row.published ? "#5DBE89" : "#C8C2B0")}>{row.published ? "Published" : "Draft"}</span>
                  {row.featured && <span style={{ ...pill("var(--ss-gold, #F0C24A)"), marginLeft: 6 }}>Featured</span>}
                </td>
                <td style={td}>
                  <button onClick={() => setDraft(row as Draft)} style={btnGhost}>Edit</button>
                  <button onClick={() => confirm(`Delete "${row.name}"?`) && del.mutate(row.id)} style={{ ...btnGhost, color: "crimson", marginLeft: 6 }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {draft && (
        <Editor
          draft={draft}
          onChange={setDraft}
          onClose={() => setDraft(null)}
          onSave={() => save.mutate(draft)}
          saving={save.isPending}
          error={save.error ? (save.error as Error).message : null}
        />
      )}
    </div>
  );
}

function Editor({
  draft, onChange, onClose, onSave, saving, error,
}: {
  draft: Draft;
  onChange: (d: Draft) => void;
  onClose: () => void;
  onSave: () => void;
  saving: boolean;
  error: string | null;
}) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(14,27,61,0.5)", zIndex: 80, display: "flex", justifyContent: "flex-end" }}>
      <form
        onClick={(e) => e.stopPropagation()}
        onSubmit={(e) => { e.preventDefault(); onSave(); }}
        style={{ width: "min(620px, 100vw)", background: "#fff", height: "100vh", overflowY: "auto", display: "flex", flexDirection: "column" }}
      >
        <header style={{ padding: "22px 26px", borderBottom: "1px solid var(--ss-line)", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 26, color: "var(--ss-ink)" }}>{draft.id ? "Edit testimonial" : "New testimonial"}</h2>
          <button type="button" onClick={onClose} aria-label="Close" style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer", color: "var(--ss-ash)" }}>×</button>
        </header>

        <div style={{ padding: 26, flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
          <Row label="Client name" required>
            <input value={draft.name} onChange={(e) => onChange({ ...draft, name: e.target.value })} required style={input} />
          </Row>
          <div style={twoCol}>
            <Row label="Role (EN)"><input value={draft.role_en ?? ""} onChange={(e) => onChange({ ...draft, role_en: e.target.value })} style={input} /></Row>
            <Row label="Role (UR)"><input dir="rtl" value={draft.role_ur ?? ""} onChange={(e) => onChange({ ...draft, role_ur: e.target.value })} style={input} /></Row>
          </div>
          <Row label="Company"><input value={draft.company ?? ""} onChange={(e) => onChange({ ...draft, company: e.target.value })} style={input} /></Row>
          <Row label="Quote (EN)" required>
            <textarea value={draft.quote_en} onChange={(e) => onChange({ ...draft, quote_en: e.target.value })} required rows={4} style={textarea} />
          </Row>
          <Row label="Quote (UR)">
            <textarea dir="rtl" value={draft.quote_ur ?? ""} onChange={(e) => onChange({ ...draft, quote_ur: e.target.value })} rows={4} style={textarea} />
          </Row>
          <Row label="Avatar URL (optional)">
            <input type="url" value={draft.avatar_url ?? ""} onChange={(e) => onChange({ ...draft, avatar_url: e.target.value })} placeholder="https://…" style={input} />
          </Row>
          <div style={twoCol}>
            <Row label="Rating (1–5)">
              <input type="number" min={1} max={5} value={draft.rating ?? 5} onChange={(e) => onChange({ ...draft, rating: Number(e.target.value) })} style={input} />
            </Row>
            <Row label="Sort order">
              <input type="number" value={draft.sort_order ?? 0} onChange={(e) => onChange({ ...draft, sort_order: Number(e.target.value) })} style={input} />
            </Row>
          </div>
          <div style={{ display: "flex", gap: 18, marginTop: 4 }}>
            <label style={checkboxRow}>
              <input type="checkbox" checked={!!draft.published} onChange={(e) => onChange({ ...draft, published: e.target.checked })} />
              Published
            </label>
            <label style={checkboxRow}>
              <input type="checkbox" checked={!!draft.featured} onChange={(e) => onChange({ ...draft, featured: e.target.checked })} />
              Featured
            </label>
          </div>

          {error && <p style={{ color: "crimson", fontFamily: "var(--font-sans)", fontSize: 13, margin: 0 }}>{error}</p>}
        </div>

        <footer style={{ padding: "16px 26px", borderTop: "1px solid var(--ss-line)", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fff", position: "sticky", bottom: 0 }}>
          <button type="button" onClick={onClose} style={btnGhost}>Cancel</button>
          <button type="submit" disabled={saving} style={{ ...btnPrimary, opacity: saving ? 0.6 : 1 }}>{saving ? "Saving…" : "Save"}</button>
        </footer>
      </form>
    </div>
  );
}

function Row({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", letterSpacing: "0.04em" }}>
        {label}{required && <span style={{ color: "crimson" }}> *</span>}
      </span>
      {children}
    </label>
  );
}

const card: React.CSSProperties = { background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, overflow: "hidden" };
const th: React.CSSProperties = { padding: "14px 16px", fontWeight: 600 };
const td: React.CSSProperties = { padding: "14px 16px", verticalAlign: "top", color: "var(--ss-ink)" };
const input: React.CSSProperties = { padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14, outline: "none", background: "#fff" };
const textarea: React.CSSProperties = { ...input, resize: "vertical", fontFamily: "var(--font-sans)" };
const twoCol: React.CSSProperties = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 };
const checkboxRow: React.CSSProperties = { display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", cursor: "pointer" };
const btnPrimary: React.CSSProperties = { padding: "9px 18px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" };
const btnGhost: React.CSSProperties = { padding: "7px 12px", background: "transparent", color: "var(--ss-ink)", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13, cursor: "pointer" };
const pill = (bg: string): React.CSSProperties => ({ display: "inline-block", padding: "3px 8px", borderRadius: 999, fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", background: bg, color: "var(--ss-ink)" });
