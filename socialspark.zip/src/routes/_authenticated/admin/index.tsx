import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Suspense } from "react";
import { getDashboardStats, listLeads } from "@/lib/leads.functions";
import { ActivityFeed } from "@/components/admin/ActivityFeed";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: () => (
    <Suspense fallback={<div style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</div>}>
      <Dashboard />
    </Suspense>
  ),
});

function Dashboard() {
  const { data: stats } = useSuspenseQuery({
    queryKey: ["dashboard-stats"],
    queryFn: () => getDashboardStats(),
  });
  const { data: recent } = useSuspenseQuery({
    queryKey: ["leads", "all", "all", "", "recent"],
    queryFn: () => listLeads({ data: { status: "all", type: "all", search: "", limit: 8 } }),
  });

  return (
    <div>
      <header style={{ marginBottom: 22 }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>
          Console · Overview
        </div>
        <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 46, color: "var(--ss-ink)", lineHeight: 1.05 }}>
          Good to see you back.
        </h1>
        <p style={{ marginTop: 6, fontFamily: "var(--font-sans)", color: "var(--ss-ash)", fontSize: 14, maxWidth: 600 }}>
          Everything you need to run Social Spark — leads, content, automations, search. Hit <kbd style={kbd}>⌘ K</kbd> any time to jump.
        </p>
      </header>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14, marginBottom: 22 }}>
        <Stat label="Total leads" value={stats.total} accent />
        <Stat label="Last 30 days" value={stats.last30} />
        <Stat label="New" value={stats.byStatus.new ?? 0} />
        <Stat label="Won" value={stats.byStatus.won ?? 0} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.5fr) minmax(280px, 1fr)", gap: 18 }} className="dash-split">
        <section style={card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24 }}>Pipeline</h2>
            <Link to="/admin/board" style={link}>Open board →</Link>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginBottom: 22 }}>
            {(["new", "contacted", "qualified", "won", "lost"] as const).map((s) => (
              <div key={s} style={{ background: "#FAF8F2", border: "1px solid var(--ss-line)", borderRadius: 12, padding: "14px 12px" }}>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 10, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)" }}>{s}</div>
                <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 30, color: "var(--ss-ink)", marginTop: 4 }}>
                  {stats.byStatus[s] ?? 0}
                </div>
              </div>
            ))}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "0 0 10px" }}>
            <h3 style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)" }}>Recent leads</h3>
            <Link to="/admin/leads" style={link}>View all →</Link>
          </div>
          <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
            {recent.length === 0 && <li style={{ color: "var(--ss-ash)", fontFamily: "var(--font-sans)", fontSize: 13 }}>Nothing yet.</li>}
            {recent.map((l) => (
              <li key={l.id}>
                <Link
                  to="/admin/leads"
                  search={{ open: l.id }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "10px 12px",
                    borderRadius: 10,
                    background: "#FAF8F2",
                    border: "1px solid var(--ss-line)",
                    textDecoration: "none",
                    color: "var(--ss-ink)",
                    fontFamily: "var(--font-sans)",
                    fontSize: 13,
                  }}
                >
                  <span style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
                    <strong style={{ fontWeight: 600 }}>{l.name || l.business || l.email || "(untitled)"}</strong>
                    <span style={{ color: "var(--ss-ash)", fontSize: 11 }}>{l.email ?? l.phone ?? ""} {l.business && l.name ? `· ${l.business}` : ""}</span>
                  </span>
                  <span style={{ fontSize: 11, padding: "3px 8px", borderRadius: 999, background: "var(--ss-gold)", color: "var(--ss-ink)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>{l.status}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section style={card}>
          <h2 style={{ margin: "0 0 14px", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24 }}>Activity</h2>
          <ActivityFeed limit={25} />
        </section>
      </div>

      <section style={{ ...card, marginTop: 18 }}>
        <h2 style={{ margin: "0 0 14px", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24 }}>Jump to a module</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10 }}>
          {[
            { to: "/admin/leads", label: "Leads", desc: "Inline edit, bulk, views" },
            { to: "/admin/inbox", label: "Inbox", desc: "All channels in one feed" },
            { to: "/admin/board", label: "Pipeline", desc: "Drag-to-move kanban" },
            { to: "/admin/media", label: "Media", desc: "Private bucket library" },
            { to: "/admin/seo", label: "SEO", desc: "Meta overrides + redirects" },
            { to: "/admin/blog", label: "Blog", desc: "Editor + publishing" },
            { to: "/admin/automations", label: "Automations", desc: "Rules & runs" },
            { to: "/admin/email", label: "Email", desc: "Provider & test send" },
            { to: "/admin/settings", label: "Settings", desc: "Brand, contact, social" },
          ].map((m) => (
            <Link key={m.to} to={m.to} style={moduleTile}>
              <span style={{ fontFamily: "var(--font-sans)", fontWeight: 600, fontSize: 14, color: "var(--ss-ink)" }}>{m.label}</span>
              <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)" }}>{m.desc}</span>
            </Link>
          ))}
        </div>
      </section>

      <style>{`@media (max-width: 1000px) { .dash-split { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}

const card: React.CSSProperties = { background: "#fff", border: "1px solid var(--ss-line, #E6E2D6)", borderRadius: 18, padding: 22 };
const link: React.CSSProperties = { fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ink)", textDecoration: "underline" };
const kbd: React.CSSProperties = { fontFamily: "ui-monospace, Menlo, monospace", fontSize: 11, padding: "2px 7px", borderRadius: 6, background: "#0E1B3D0A", border: "1px solid var(--ss-line)" };
const moduleTile: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: 4,
  padding: "14px 14px",
  background: "#FAF8F2",
  border: "1px solid var(--ss-line)",
  borderRadius: 12,
  textDecoration: "none",
  transition: "background 140ms ease, border-color 140ms ease",
};

function Stat({ label, value, accent }: { label: string; value: number; accent?: boolean }) {
  return (
    <div
      style={{
        background: accent ? "var(--ss-ink, #0E1B3D)" : "#fff",
        color: accent ? "#fff" : "var(--ss-ink, #0E1B3D)",
        border: accent ? "none" : "1px solid var(--ss-line, #E6E2D6)",
        borderRadius: 18,
        padding: "22px 24px",
      }}
    >
      <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", opacity: accent ? 0.7 : 0.6 }}>
        {label}
      </div>
      <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 48, lineHeight: 1, marginTop: 10 }}>
        {value}
      </div>
    </div>
  );
}
