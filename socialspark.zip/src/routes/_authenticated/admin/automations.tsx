import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  listAutomationRules,
  listAutomationRuns,
  toggleAutomationRule,
  runAutomationNow,
} from "@/lib/automations.functions";

export const Route = createFileRoute("/_authenticated/admin/automations")({
  head: () => ({
    meta: [
      { title: "Automations — Social Spark" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

const card: React.CSSProperties = {
  background: "#fff",
  border: "1px solid #ECE7DC",
  borderRadius: 16,
  padding: 20,
};
const sansLabel: React.CSSProperties = {
  fontFamily: "var(--font-sans)",
  fontSize: 11,
  fontWeight: 600,
  letterSpacing: "0.18em",
  textTransform: "uppercase",
  color: "var(--ss-ash)",
};

function Page() {
  const qc = useQueryClient();
  const rules = useSuspenseQuery({
    queryKey: ["admin", "automation-rules"],
    queryFn: () => listAutomationRules(),
  });
  const runs = useSuspenseQuery({
    queryKey: ["admin", "automation-runs"],
    queryFn: () => listAutomationRuns({ data: { limit: 30 } }),
  });

  const toggle = useMutation({
    mutationFn: (vars: { key: string; enabled: boolean }) =>
      toggleAutomationRule({ data: vars }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "automation-rules"] }),
  });

  const [busyKey, setBusyKey] = useState<string | null>(null);
  const runNow = useMutation({
    mutationFn: (key: "cron.stale_leads" | "cron.daily_digest") =>
      runAutomationNow({ data: { key } }),
    onSettled: () => {
      setBusyKey(null);
      qc.invalidateQueries({ queryKey: ["admin", "automation-runs"] });
      qc.invalidateQueries({ queryKey: ["admin", "automation-rules"] });
    },
  });

  return (
    <div>
      <header style={{ marginBottom: 28 }}>
        <div style={sansLabel}>Operations · Automations</div>
        <h1
          style={{
            fontFamily: "var(--font-serif)",
            fontStyle: "italic",
            fontSize: 40,
            color: "var(--ss-ink)",
            margin: "8px 0 0",
            lineHeight: 1,
          }}
        >
          Workflows that run on their own
        </h1>
        <p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)", marginTop: 10, maxWidth: 620 }}>
          Toggle a rule off to pause it. Cron rules can be triggered manually for a one-off run.
        </p>
      </header>

      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
        {rules.data.map((r) => {
          const isCron = r.key.startsWith("cron.");
          return (
            <div key={r.key} style={card}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                <div>
                  <div style={sansLabel}>{r.key}</div>
                  <div
                    style={{
                      fontFamily: "var(--font-serif)",
                      fontStyle: "italic",
                      fontSize: 22,
                      color: "var(--ss-ink)",
                      marginTop: 6,
                    }}
                  >
                    {r.name}
                  </div>
                </div>
                <label
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 8,
                    cursor: "pointer",
                    fontFamily: "var(--font-sans)",
                    fontSize: 12,
                    color: "var(--ss-ash)",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={r.enabled}
                    onChange={(e) => toggle.mutate({ key: r.key, enabled: e.target.checked })}
                  />
                  {r.enabled ? "On" : "Off"}
                </label>
              </div>
              <p style={{ fontFamily: "var(--font-sans)", color: "#3F4655", fontSize: 14, lineHeight: 1.55, margin: "12px 0 14px" }}>
                {r.description}
              </p>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)" }}>
                  {r.last_run_at
                    ? `Last run: ${new Date(r.last_run_at).toLocaleString()} · ${r.last_run_status ?? "—"}`
                    : "Never run"}
                </div>
                {isCron && (
                  <button
                    type="button"
                    disabled={busyKey === r.key}
                    onClick={() => {
                      setBusyKey(r.key);
                      runNow.mutate(r.key as "cron.stale_leads" | "cron.daily_digest");
                    }}
                    style={{
                      fontFamily: "var(--font-sans)",
                      fontSize: 12,
                      fontWeight: 600,
                      letterSpacing: "0.04em",
                      padding: "6px 12px",
                      borderRadius: 999,
                      border: "1px solid var(--ss-ink)",
                      background: busyKey === r.key ? "#F4EFE6" : "var(--ss-ink)",
                      color: busyKey === r.key ? "var(--ss-ink)" : "#fff",
                      cursor: busyKey === r.key ? "wait" : "pointer",
                    }}
                  >
                    {busyKey === r.key ? "Running…" : "Run now"}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </section>

      <section style={{ marginTop: 36 }}>
        <div style={sansLabel}>Recent runs</div>
        <h2
          style={{
            fontFamily: "var(--font-serif)",
            fontStyle: "italic",
            fontSize: 28,
            color: "var(--ss-ink)",
            margin: "6px 0 16px",
          }}
        >
          Activity log
        </h2>
        <div style={{ ...card, padding: 0, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 13 }}>
            <thead>
              <tr style={{ background: "#FAF7F0", color: "var(--ss-ash)", textAlign: "left" }}>
                <th style={{ padding: "10px 14px" }}>When</th>
                <th style={{ padding: "10px 14px" }}>Rule</th>
                <th style={{ padding: "10px 14px" }}>Trigger</th>
                <th style={{ padding: "10px 14px" }}>Status</th>
                <th style={{ padding: "10px 14px" }}>Detail</th>
              </tr>
            </thead>
            <tbody>
              {runs.data.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ padding: 20, textAlign: "center", color: "var(--ss-ash)" }}>
                    No runs yet — submit a lead from the site to see automations fire.
                  </td>
                </tr>
              )}
              {runs.data.map((row) => {
                const color =
                  row.status === "error"
                    ? "#B33A3A"
                    : row.status === "skipped"
                      ? "#8A8275"
                      : "#1E7A4F";
                const payloadText = row.error
                  ? row.error
                  : Object.keys((row.payload as Record<string, unknown>) ?? {}).length
                    ? JSON.stringify(row.payload)
                    : "—";
                return (
                  <tr key={row.id} style={{ borderTop: "1px solid #F0EDE5" }}>
                    <td style={{ padding: "10px 14px", color: "var(--ss-ash)" }}>
                      {new Date(row.created_at).toLocaleString()}
                    </td>
                    <td style={{ padding: "10px 14px", color: "var(--ss-ink)", fontWeight: 600 }}>{row.rule_key}</td>
                    <td style={{ padding: "10px 14px", color: "var(--ss-ash)" }}>{row.trigger}</td>
                    <td style={{ padding: "10px 14px", color, fontWeight: 600, textTransform: "capitalize" }}>
                      {row.status}
                    </td>
                    <td
                      style={{
                        padding: "10px 14px",
                        color: "var(--ss-ash)",
                        maxWidth: 320,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                      title={payloadText}
                    >
                      {payloadText}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
