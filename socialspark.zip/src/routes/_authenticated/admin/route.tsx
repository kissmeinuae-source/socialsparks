import { createFileRoute, Link, Outlet, redirect, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMyRole } from "@/lib/leads.functions";
import { CommandPalette } from "@/components/admin/CommandPalette";
import { ShortcutHints } from "@/components/admin/ShortcutHints";
import { Breadcrumbs } from "@/components/admin/Breadcrumbs";

export const Route = createFileRoute("/_authenticated/admin")({
  beforeLoad: async () => {
    try {
      const { roles } = await getMyRole();
      if (!roles.includes("admin") && !roles.includes("team")) {
        throw redirect({ to: "/auth" });
      }
      return { roles };
    } catch (e) {
      if (e && typeof e === "object" && "isRedirect" in e) throw e;
      throw redirect({ to: "/auth" });
    }
  },
  head: () => ({
    meta: [
      { title: "Console — Social Spark" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminLayout,
});

type NavItem = { to: string; label: string; group: string; end?: boolean; shortcut?: string };

const NAV: NavItem[] = [
  { to: "/admin", label: "Overview", group: "Operate", end: true, shortcut: "⌘1" },
  { to: "/admin/leads", label: "Leads", group: "Operate", shortcut: "⌘2" },
  { to: "/admin/inbox", label: "Inbox", group: "Operate", shortcut: "⌘3" },
  { to: "/admin/board", label: "Pipeline", group: "Operate", shortcut: "⌘4" },

  { to: "/admin/media", label: "Media", group: "Content", shortcut: "⌘5" },
  { to: "/admin/seo", label: "SEO", group: "Content", shortcut: "⌘6" },
  { to: "/admin/blog", label: "Blog", group: "Content", shortcut: "⌘7" },
  { to: "/admin/services", label: "Services", group: "Content" },
  { to: "/admin/pricing", label: "Pricing", group: "Content" },
  { to: "/admin/testimonials", label: "Testimonials", group: "Content" },

  { to: "/admin/automations", label: "Automations", group: "System", shortcut: "⌘8" },
  { to: "/admin/email", label: "Email Provider", group: "System" },
  { to: "/admin/settings", label: "Site Settings", group: "System", shortcut: "⌘9" },
];

function AdminLayout() {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [email, setEmail] = useState<string>("");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
  }, []);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const groups = ["Operate", "Content", "System"] as const;

  return (
    <div style={{ minHeight: "100vh", background: "#F4F1E8", display: "flex" }}>
      <aside
        style={{
          width: 260,
          flexShrink: 0,
          background: "var(--ss-ink, #0E1B3D)",
          color: "#fff",
          padding: "24px 18px",
          position: "sticky",
          top: 0,
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          overflowY: "auto",
        }}
        className={open ? "admin-aside open" : "admin-aside"}
      >
        <Link to="/admin" style={{ display: "flex", alignItems: "center", gap: 10, color: "#fff", textDecoration: "none", marginBottom: 26 }}>
          <span style={{ width: 32, height: 32, borderRadius: 9, background: "var(--ss-gold, #F0C24A)", display: "inline-flex", alignItems: "center", justifyContent: "center", color: "var(--ss-ink)", fontWeight: 800 }}>S</span>
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.05 }}>
            <span style={{ fontFamily: "var(--font-serif, 'Instrument Serif', serif)", fontStyle: "italic", fontSize: 20 }}>Social Spark</span>
            <span style={{ fontFamily: "var(--font-sans)", fontSize: 10, letterSpacing: "0.18em", color: "rgba(255,255,255,0.55)", textTransform: "uppercase" }}>Console</span>
          </div>
        </Link>

        <button
          onClick={() => {
            // dispatch a synthetic ⌘K
            window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }));
          }}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "9px 12px",
            borderRadius: 10,
            background: "rgba(255,255,255,0.06)",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "rgba(255,255,255,0.78)",
            fontFamily: "var(--font-sans)",
            fontSize: 13,
            cursor: "pointer",
            marginBottom: 18,
          }}
        >
          <span aria-hidden>⌕</span>
          <span style={{ flex: 1, textAlign: "left" }}>Search & commands</span>
          <kbd style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 10, padding: "2px 6px", borderRadius: 4, background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)" }}>⌘K</kbd>
        </button>

        <nav style={{ display: "flex", flexDirection: "column", gap: 14, flex: 1 }}>
          {groups.map((g) => (
            <div key={g}>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 10, letterSpacing: "0.16em", textTransform: "uppercase", color: "rgba(255,255,255,0.4)", padding: "0 12px 6px" }}>{g}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {NAV.filter((n) => n.group === g).map((item) => {
                  const active = item.end ? pathname === item.to : pathname.startsWith(item.to);
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setOpen(false)}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        padding: "8px 12px",
                        borderRadius: 8,
                        fontFamily: "var(--font-sans)",
                        fontSize: 13.5,
                        fontWeight: active ? 600 : 500,
                        color: active ? "var(--ss-ink, #0E1B3D)" : "rgba(255,255,255,0.78)",
                        background: active ? "var(--ss-gold, #F0C24A)" : "transparent",
                        textDecoration: "none",
                        transition: "background 140ms ease, color 140ms ease",
                      }}
                    >
                      <span>{item.label}</span>
                      {item.shortcut && (
                        <span style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 10, opacity: active ? 0.7 : 0.45 }}>
                          {item.shortcut}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div style={{ marginTop: 18, paddingTop: 16, borderTop: "1px solid rgba(255,255,255,0.1)" }}>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, color: "rgba(255,255,255,0.5)", marginBottom: 4 }}>Signed in as</div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "#fff", wordBreak: "break-all", marginBottom: 12 }}>{email || "…"}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              type="button"
              onClick={() => window.dispatchEvent(new KeyboardEvent("keydown", { key: "?" }))}
              style={{
                flex: 1,
                padding: "8px 10px",
                borderRadius: 8,
                border: "1px solid rgba(255,255,255,0.18)",
                background: "transparent",
                color: "#fff",
                fontFamily: "var(--font-sans)",
                fontSize: 12,
                cursor: "pointer",
              }}
            >
              Shortcuts
            </button>
            <button
              type="button"
              onClick={signOut}
              style={{
                flex: 1,
                padding: "8px 10px",
                borderRadius: 8,
                border: "1px solid rgba(255,255,255,0.18)",
                background: "transparent",
                color: "#fff",
                fontFamily: "var(--font-sans)",
                fontSize: 12,
                cursor: "pointer",
              }}
            >
              Sign out
            </button>
          </div>
        </div>
      </aside>

      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <header
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "14px 28px",
            background: "rgba(255,255,255,0.78)",
            backdropFilter: "saturate(140%) blur(10px)",
            WebkitBackdropFilter: "saturate(140%) blur(10px)",
            borderBottom: "1px solid var(--ss-line, #E6E2D6)",
            position: "sticky",
            top: 0,
            zIndex: 20,
          }}
          className="admin-topbar"
        >
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              aria-label="Toggle menu"
              className="admin-burger"
              style={{ display: "none", background: "none", border: "1px solid var(--ss-line)", borderRadius: 8, padding: "6px 10px", cursor: "pointer" }}
            >
              ☰
            </button>
            <Breadcrumbs />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <a
              href="/"
              target="_blank"
              rel="noopener"
              style={{
                fontFamily: "var(--font-sans)",
                fontSize: 12,
                color: "var(--ss-ink, #0E1B3D)",
                textDecoration: "none",
                padding: "6px 12px",
                borderRadius: 999,
                border: "1px solid var(--ss-line, #E6E2D6)",
              }}
            >
              View site ↗
            </a>
          </div>
        </header>
        <main style={{ flex: 1, padding: "28px 32px 60px", minWidth: 0 }} className="admin-main">
          <Outlet />
        </main>
      </div>

      <CommandPalette />
      <ShortcutHints />

      <style>{`
        @media (max-width: 960px) {
          .admin-aside {
            position: fixed !important;
            inset: 0 auto 0 0;
            transform: translateX(-100%);
            transition: transform 220ms ease;
            z-index: 60;
            box-shadow: 0 0 60px rgba(0,0,0,0.4);
          }
          .admin-aside.open { transform: translateX(0); }
          .admin-burger { display: inline-flex !important; }
          .admin-main { padding: 22px 18px 60px !important; }
        }
      `}</style>
    </div>
  );
}
