import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listAllPosts, upsertPost, deletePost } from "@/lib/cms.functions";
import { MediaPicker } from "@/components/admin/MediaPicker";

export const Route = createFileRoute("/_authenticated/admin/blog")({
  head: () => ({ meta: [{ title: "Blog — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

type Row = Awaited<ReturnType<typeof listAllPosts>>[number];
type Draft = Partial<Row> & {
  slug: string;
  title_en: string;
  category: string;
};

const empty: Draft = {
  slug: "",
  category: "GENERAL",
  title_en: "",
  title_ur: "",
  excerpt_en: "",
  excerpt_ur: "",
  body_en: "",
  body_ur: "",
  cover_image_url: "",
  author_name: "Social Spark Team",
  read_time: "5 min read",
  seo_title: "",
  seo_description: "",
  og_image_url: "",
  published: false,
  featured: false,
  sort_order: 0,
};

function slugify(s: string) {
  return s.toLowerCase().trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80);
}

function Page() {
  const qc = useQueryClient();
  const { data } = useSuspenseQuery({ queryKey: ["admin", "blog"], queryFn: () => listAllPosts() });
  const [draft, setDraft] = useState<Draft | null>(null);

  const save = useMutation({
    mutationFn: (d: Draft) =>
      upsertPost({
        data: {
          id: d.id,
          slug: d.slug,
          category: d.category,
          title_en: d.title_en,
          title_ur: d.title_ur ?? null,
          excerpt_en: d.excerpt_en ?? "",
          excerpt_ur: d.excerpt_ur ?? null,
          body_en: d.body_en ?? "",
          body_ur: d.body_ur ?? null,
          cover_image_url: d.cover_image_url ?? null,
          author_name: d.author_name ?? "Social Spark Team",
          read_time: d.read_time ?? "5 min read",
          seo_title: d.seo_title ?? null,
          seo_description: d.seo_description ?? null,
          og_image_url: d.og_image_url ?? null,
          published: !!d.published,
          published_at: d.published_at ?? null,
          featured: !!d.featured,
          sort_order: d.sort_order ?? 0,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "blog"] });
      qc.invalidateQueries({ queryKey: ["public", "blog"] });
      setDraft(null);
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => deletePost({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "blog"] });
      qc.invalidateQueries({ queryKey: ["public", "blog"] });
    },
  });

  return (
    <div>
      <header style={{ marginBottom: 22, display: "flex", justifyContent: "space-between", alignItems: "end", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>CMS · Blog</div>
          <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>Posts ({data.length})</h1>
        </div>
        <button onClick={() => setDraft({ ...empty })} style={btnPrimary}>+ New post</button>
      </header>

      <div style={card}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--font-sans)", fontSize: 14 }}>
          <thead>
            <tr style={{ textAlign: "left", color: "var(--ss-ash)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              <th style={th}>Title</th>
              <th style={th}>Category</th>
              <th style={th}>Slug</th>
              <th style={th}>Status</th>
              <th style={th}>Published</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 && (
              <tr><td colSpan={6} style={{ padding: 40, textAlign: "center", color: "var(--ss-ash)" }}>No posts yet — write your first one.</td></tr>
            )}
            {data.map((row) => (
              <tr key={row.id} style={{ borderTop: "1px solid var(--ss-line)" }}>
                <td style={td}>
                  <strong>{row.title_en}</strong>
                  {row.excerpt_en && <div style={{ color: "var(--ss-ash)", fontSize: 12, marginTop: 3, maxWidth: 380, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{row.excerpt_en}</div>}
                </td>
                <td style={td}>{row.category}</td>
                <td style={{ ...td, fontFamily: "monospace", fontSize: 12 }}>/{row.slug}</td>
                <td style={td}>
                  <span style={pill(row.published ? "#5DBE89" : "#C8C2B0")}>{row.published ? "Live" : "Draft"}</span>
                  {row.featured && <span style={{ ...pill("var(--ss-gold, #F0C24A)"), marginLeft: 6 }}>Featured</span>}
                </td>
                <td style={td}>{row.published_at ? new Date(row.published_at).toLocaleDateString() : "—"}</td>
                <td style={td}>
                  <button onClick={() => setDraft(row as Draft)} style={btnGhost}>Edit</button>
                  <button onClick={() => confirm(`Delete "${row.title_en}"?`) && del.mutate(row.id)} style={{ ...btnGhost, color: "crimson", marginLeft: 6 }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {draft && (
        <Editor
          draft={draft}
          onChange={setDraft}
          onClose={() => setDraft(null)}
          onSave={() => save.mutate(draft)}
          saving={save.isPending}
          error={save.error ? (save.error as Error).message : null}
        />
      )}
    </div>
  );
}

function Editor({
  draft, onChange, onClose, onSave, saving, error,
}: {
  draft: Draft;
  onChange: (d: Draft) => void;
  onClose: () => void;
  onSave: () => void;
  saving: boolean;
  error: string | null;
}) {
  const [pickerFor, setPickerFor] = useState<null | "cover" | "og">(null);
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(14,27,61,0.5)", zIndex: 80, display: "flex", justifyContent: "flex-end" }}>
      <form
        onClick={(e) => e.stopPropagation()}
        onSubmit={(e) => { e.preventDefault(); onSave(); }}
        style={{ width: "min(760px, 100vw)", background: "#fff", height: "100vh", overflowY: "auto", display: "flex", flexDirection: "column" }}
      >
        <header style={{ padding: "22px 26px", borderBottom: "1px solid var(--ss-line)", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 26, color: "var(--ss-ink)" }}>{draft.id ? "Edit post" : "New post"}</h2>
          <button type="button" onClick={onClose} aria-label="Close" style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer", color: "var(--ss-ash)" }}>×</button>
        </header>

        <div style={{ padding: 26, flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
          <Row label="Title (EN)" required>
            <input
              value={draft.title_en}
              onChange={(e) => {
                const v = e.target.value;
                onChange({ ...draft, title_en: v, slug: draft.id ? draft.slug : slugify(v) });
              }}
              required
              style={input}
            />
          </Row>
          <Row label="Title (UR)">
            <input dir="rtl" value={draft.title_ur ?? ""} onChange={(e) => onChange({ ...draft, title_ur: e.target.value })} style={input} />
          </Row>

          <div style={twoCol}>
            <Row label="Slug" required>
              <input value={draft.slug} onChange={(e) => onChange({ ...draft, slug: slugify(e.target.value) })} required pattern="[a-z0-9-]+" style={{ ...input, fontFamily: "monospace" }} />
            </Row>
            <Row label="Category">
              <input value={draft.category} onChange={(e) => onChange({ ...draft, category: e.target.value.toUpperCase() })} style={input} />
            </Row>
          </div>

          <Row label="Excerpt (EN)">
            <textarea value={draft.excerpt_en ?? ""} onChange={(e) => onChange({ ...draft, excerpt_en: e.target.value })} rows={2} style={textarea} />
          </Row>
          <Row label="Excerpt (UR)">
            <textarea dir="rtl" value={draft.excerpt_ur ?? ""} onChange={(e) => onChange({ ...draft, excerpt_ur: e.target.value })} rows={2} style={textarea} />
          </Row>

          <Row label="Body (EN) — Markdown supported (## headings, blank line = paragraph)">
            <textarea value={draft.body_en ?? ""} onChange={(e) => onChange({ ...draft, body_en: e.target.value })} rows={14} style={{ ...textarea, fontFamily: "monospace", fontSize: 13 }} />
          </Row>
          <Row label="Body (UR)">
            <textarea dir="rtl" value={draft.body_ur ?? ""} onChange={(e) => onChange({ ...draft, body_ur: e.target.value })} rows={10} style={{ ...textarea, fontFamily: "monospace", fontSize: 13 }} />
          </Row>

          <div style={twoCol}>
            <Row label="Author"><input value={draft.author_name ?? ""} onChange={(e) => onChange({ ...draft, author_name: e.target.value })} style={input} /></Row>
            <Row label="Read time"><input value={draft.read_time ?? ""} onChange={(e) => onChange({ ...draft, read_time: e.target.value })} placeholder="6 min read" style={input} /></Row>
          </div>

          <Row label="Cover image URL">
            <div style={{ display: "flex", gap: 8 }}>
              <input type="url" value={draft.cover_image_url ?? ""} onChange={(e) => onChange({ ...draft, cover_image_url: e.target.value })} placeholder="https://…" style={{ ...input, flex: 1 }} />
              <button type="button" onClick={() => setPickerFor("cover")} style={pickerBtn}>Pick…</button>
            </div>
            {draft.cover_image_url && (
              <img src={draft.cover_image_url} alt="" style={{ marginTop: 8, maxWidth: 220, maxHeight: 120, objectFit: "cover", borderRadius: 8, border: "1px solid var(--ss-line)" }} />
            )}
          </Row>

          <details style={{ border: "1px solid var(--ss-line)", borderRadius: 10, padding: "10px 14px" }}>
            <summary style={{ cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, color: "var(--ss-ink)" }}>SEO / Social</summary>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 12 }}>
              <Row label="SEO title (overrides title)"><input value={draft.seo_title ?? ""} onChange={(e) => onChange({ ...draft, seo_title: e.target.value })} style={input} /></Row>
              <Row label="SEO description"><textarea value={draft.seo_description ?? ""} onChange={(e) => onChange({ ...draft, seo_description: e.target.value })} rows={2} style={textarea} /></Row>
              <Row label="OG image URL">
                <div style={{ display: "flex", gap: 8 }}>
                  <input type="url" value={draft.og_image_url ?? ""} onChange={(e) => onChange({ ...draft, og_image_url: e.target.value })} style={{ ...input, flex: 1 }} />
                  <button type="button" onClick={() => setPickerFor("og")} style={pickerBtn}>Pick…</button>
                </div>
              </Row>
            </div>
          </details>

          <div style={twoCol}>
            <Row label="Sort order">
              <input type="number" value={draft.sort_order ?? 0} onChange={(e) => onChange({ ...draft, sort_order: Number(e.target.value) })} style={input} />
            </Row>
            <Row label="Publish date (optional)">
              <input
                type="datetime-local"
                value={draft.published_at ? new Date(draft.published_at).toISOString().slice(0, 16) : ""}
                onChange={(e) => onChange({ ...draft, published_at: e.target.value ? new Date(e.target.value).toISOString() : null })}
                style={input}
              />
            </Row>
          </div>

          <div style={{ display: "flex", gap: 18, marginTop: 4 }}>
            <label style={checkboxRow}>
              <input type="checkbox" checked={!!draft.published} onChange={(e) => onChange({ ...draft, published: e.target.checked })} />
              Published (live on site)
            </label>
            <label style={checkboxRow}>
              <input type="checkbox" checked={!!draft.featured} onChange={(e) => onChange({ ...draft, featured: e.target.checked })} />
              Featured
            </label>
          </div>

          {error && <p style={{ color: "crimson", fontFamily: "var(--font-sans)", fontSize: 13, margin: 0 }}>{error}</p>}
        </div>

        <footer style={{ padding: "16px 26px", borderTop: "1px solid var(--ss-line)", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fff", position: "sticky", bottom: 0 }}>
          <button type="button" onClick={onClose} style={btnGhost}>Cancel</button>
          <button type="submit" disabled={saving} style={{ ...btnPrimary, opacity: saving ? 0.6 : 1 }}>{saving ? "Saving…" : "Save"}</button>
        </footer>
      </form>
      <MediaPicker
        open={pickerFor !== null}
        onOpenChange={(v) => { if (!v) setPickerFor(null); }}
        onPick={(url) => {
          if (pickerFor === "cover") onChange({ ...draft, cover_image_url: url });
          if (pickerFor === "og") onChange({ ...draft, og_image_url: url });
        }}
      />
    </div>
  );
}

function Row({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", letterSpacing: "0.04em" }}>
        {label}{required && <span style={{ color: "crimson" }}> *</span>}
      </span>
      {children}
    </label>
  );
}

const card: React.CSSProperties = { background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, overflow: "hidden" };
const th: React.CSSProperties = { padding: "14px 16px", fontWeight: 600 };
const td: React.CSSProperties = { padding: "14px 16px", verticalAlign: "top", color: "var(--ss-ink)" };
const input: React.CSSProperties = { padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14, outline: "none", background: "#fff" };
const textarea: React.CSSProperties = { ...input, resize: "vertical", fontFamily: "var(--font-sans)" };
const twoCol: React.CSSProperties = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 };
const checkboxRow: React.CSSProperties = { display: "flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", cursor: "pointer" };
const btnPrimary: React.CSSProperties = { padding: "9px 18px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" };
const pickerBtn: React.CSSProperties = { padding: "0 14px", background: "#FAF8F2", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", cursor: "pointer" };
const btnGhost: React.CSSProperties = { padding: "7px 12px", background: "transparent", color: "var(--ss-ink)", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13, cursor: "pointer" };
const pill = (bg: string): React.CSSProperties => ({ display: "inline-block", padding: "3px 8px", borderRadius: 999, fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", background: bg, color: "var(--ss-ink)" });
