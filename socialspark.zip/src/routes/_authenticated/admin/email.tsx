import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useEffect, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getEmailConfig, saveEmailConfig, sendTestEmail, verifyEmailProvider, type EmailConfigRow, type VerifyProviderResult } from "@/lib/email.functions";

export const Route = createFileRoute("/_authenticated/admin/email")({
  head: () => ({ meta: [{ title: "Email — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<p style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</p>}>
      <Page />
    </Suspense>
  ),
});

type Provider = EmailConfigRow["provider"];

const PROVIDER_INFO: Record<Provider, { label: string; help: string; freeTier: string; signupUrl: string }> = {
  brevo:    { label: "Brevo (recommended)", help: "Free tier, no card required. Easy to start.", freeTier: "300 emails/day forever free", signupUrl: "https://www.brevo.com/" },
  resend:   { label: "Resend",              help: "Developer-friendly. Requires verified domain.",   freeTier: "3,000 emails/month free",      signupUrl: "https://resend.com/" },
  sendgrid: { label: "SendGrid",            help: "Enterprise-grade. Needs credit card on free.",     freeTier: "100 emails/day free",          signupUrl: "https://sendgrid.com/" },
  postmark: { label: "Postmark",            help: "Best deliverability for transactional.",           freeTier: "100 emails/month free trial",  signupUrl: "https://postmarkapp.com/" },
  mailgun:  { label: "Mailgun",             help: "Solid all-rounder. Requires sending domain.",      freeTier: "5,000 emails/month for 3 mo",  signupUrl: "https://www.mailgun.com/" },
};

function Page() {
  const qc = useQueryClient();
  const { data } = useSuspenseQuery({ queryKey: ["admin", "email-config"], queryFn: () => getEmailConfig() });

  const [form, setForm] = useState<EmailConfigRow>(() => ({
    provider: data?.provider ?? "brevo",
    api_key: data?.api_key ?? "",
    api_secret: data?.api_secret ?? "",
    mailgun_domain: data?.mailgun_domain ?? "",
    from_name: data?.from_name ?? "Social Spark",
    from_email: data?.from_email ?? "",
    reply_to: data?.reply_to ?? "",
    notify_to: data?.notify_to ?? "",
    enabled: data?.enabled ?? false,
    last_test_at: data?.last_test_at ?? null,
    last_test_status: data?.last_test_status ?? null,
    last_test_error: data?.last_test_error ?? null,
  }));
  useEffect(() => {
    if (data) setForm((f) => ({ ...f, ...data }));
  }, [data]);

  const [testTo, setTestTo] = useState<string>("");
  const [savedAt, setSavedAt] = useState<number | null>(null);

  const save = useMutation({
    mutationFn: () => saveEmailConfig({ data: {
      provider: form.provider,
      api_key: form.api_key,
      api_secret: form.api_secret,
      mailgun_domain: form.mailgun_domain,
      from_name: form.from_name,
      from_email: form.from_email,
      reply_to: form.reply_to,
      notify_to: form.notify_to,
      enabled: form.enabled,
    } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "email-config"] }); setSavedAt(Date.now()); },
  });

  const test = useMutation({
    mutationFn: () => sendTestEmail({ data: { to: testTo } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "email-config"] }); },
  });

  const [verifyResult, setVerifyResult] = useState<VerifyProviderResult | null>(null);
  const verify = useMutation({
    mutationFn: () => verifyEmailProvider({ data: {
      provider: form.provider,
      api_key: form.api_key ?? "",
      mailgun_domain: form.mailgun_domain,
      from_email: form.from_email,
    } }),
    onSuccess: (r) => setVerifyResult(r),
  });

  const runVerifyThenSave = async () => {
    setVerifyResult(null);
    const r = await verify.mutateAsync();
    if (r.ok) save.mutate();
  };

  const info = PROVIDER_INFO[form.provider];

  return (
    <div style={{ maxWidth: 760 }}>
      <header style={{ marginBottom: 28 }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>Operations · Email</div>
        <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>Email settings</h1>
        <p style={{ margin: "8px 0 0", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ash)", maxWidth: 560 }}>
          Connect any HTTP email provider. Used by lead auto-replies and the daily digest. API keys stay in your private database — never exposed to the website.
        </p>
      </header>

      <form onSubmit={(e) => { e.preventDefault(); runVerifyThenSave(); }} style={card}>
        <Field label="Provider">
          <select value={form.provider} onChange={(e) => setForm((f) => ({ ...f, provider: e.target.value as Provider }))} style={input}>
            {(Object.keys(PROVIDER_INFO) as Provider[]).map((p) => (
              <option key={p} value={p}>{PROVIDER_INFO[p].label}</option>
            ))}
          </select>
          <Helper>
            {info.help} · {info.freeTier} · <a href={info.signupUrl} target="_blank" rel="noopener noreferrer" style={{ color: "var(--ss-ink)" }}>Sign up →</a>
          </Helper>
        </Field>

        <Field label="API key">
          <input type="password" value={form.api_key ?? ""} onChange={(e) => setForm((f) => ({ ...f, api_key: e.target.value }))} placeholder={form.provider === "brevo" ? "xkeysib-…" : form.provider === "resend" ? "re_…" : "Your provider API key"} style={input} autoComplete="off" />
          <Helper>Paste the key from your provider dashboard. Stored encrypted at rest.</Helper>
        </Field>

        {form.provider === "mailgun" && (
          <Field label="Mailgun sending domain">
            <input value={form.mailgun_domain ?? ""} onChange={(e) => setForm((f) => ({ ...f, mailgun_domain: e.target.value }))} placeholder="mg.socialspark.pk" style={input} />
            <Helper>The verified domain shown in your Mailgun dashboard.</Helper>
          </Field>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Field label="From name">
            <input value={form.from_name} onChange={(e) => setForm((f) => ({ ...f, from_name: e.target.value }))} placeholder="Social Spark" style={input} />
          </Field>
          <Field label="From email">
            <input type="email" value={form.from_email} onChange={(e) => setForm((f) => ({ ...f, from_email: e.target.value }))} placeholder="hello@socialspark.pk" style={input} />
          </Field>
        </div>

        <Field label="Reply-to (optional)">
          <input type="email" value={form.reply_to ?? ""} onChange={(e) => setForm((f) => ({ ...f, reply_to: e.target.value }))} placeholder="growth@socialspark.pk" style={input} />
        </Field>

        <Field label="Daily digest recipients">
          <input value={form.notify_to ?? ""} onChange={(e) => setForm((f) => ({ ...f, notify_to: e.target.value }))} placeholder="you@socialspark.pk, partner@socialspark.pk" style={input} />
          <Helper>Comma-separated. Receives the 9am PKT lead digest.</Helper>
        </Field>

        <label style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 6, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", cursor: "pointer" }}>
          <input type="checkbox" checked={form.enabled} onChange={(e) => setForm((f) => ({ ...f, enabled: e.target.checked }))} />
          <span><strong>Enable email sending.</strong> Required for auto-replies & digests.</span>
        </label>

        <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 12, marginTop: 18, flexWrap: "wrap" }}>
          {save.error && <span style={{ color: "crimson", fontFamily: "var(--font-sans)", fontSize: 12 }}>{(save.error as Error).message}</span>}
          {savedAt && !save.isPending && !save.error && <span style={{ color: "var(--ss-ash)", fontFamily: "var(--font-sans)", fontSize: 12 }}>Saved</span>}
          <button type="button" onClick={() => { setVerifyResult(null); verify.mutate(); }} disabled={verify.isPending || !form.api_key} style={ghostBtn(verify.isPending || !form.api_key)}>
            {verify.isPending ? "Verifying…" : "Verify connection"}
          </button>
          <button type="submit" disabled={save.isPending || verify.isPending} style={primaryBtn(save.isPending || verify.isPending)}>
            {verify.isPending ? "Verifying…" : save.isPending ? "Saving…" : "Verify & save"}
          </button>
        </div>

        {verifyResult && (
          <div style={{ marginTop: 14, padding: 14, borderRadius: 10, background: verifyResult.ok ? "#E6F4EC" : "#FBE9E7", border: `1px solid ${verifyResult.ok ? "#9DD3B0" : "#F0B0A6"}`, fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ink)" }}>
            <div style={{ fontWeight: 600, marginBottom: 8 }}>
              {verifyResult.ok ? `✓ ${verifyResult.provider} reachable${verifyResult.account ? ` · ${verifyResult.account}` : ""}` : `✗ ${verifyResult.error}`}
            </div>
            {verifyResult.checks.length > 0 && (
              <ul style={{ margin: 0, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 4 }}>
                {verifyResult.checks.map((c, i) => (
                  <li key={i} style={{ color: c.ok ? "#1F7A4B" : "#B23A2A" }}>
                    {c.ok ? "✓" : "✗"} {c.label}{c.detail ? <span style={{ color: "var(--ss-ash)" }}> — {c.detail}</span> : null}
                  </li>
                ))}
              </ul>
            )}
            {!verifyResult.ok && (
              <div style={{ marginTop: 8, color: "var(--ss-ash)", fontSize: 12 }}>Save is blocked until verification passes.</div>
            )}
          </div>
        )}
      </form>

      <section style={{ ...card, marginTop: 20 }}>
        <h2 style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24, color: "var(--ss-ink)" }}>Send a test email</h2>
        <p style={{ margin: "4px 0 14px", fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ash)" }}>
          Save your settings first, then send yourself a test to confirm everything works end-to-end.
        </p>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <input type="email" value={testTo} onChange={(e) => setTestTo(e.target.value)} placeholder="you@example.com" style={{ ...input, flex: "1 1 240px" }} />
          <button type="button" onClick={() => test.mutate()} disabled={!testTo || test.isPending || !form.enabled} style={primaryBtn(test.isPending || !testTo || !form.enabled)}>
            {test.isPending ? "Sending…" : "Send test"}
          </button>
        </div>

        {test.data && (
          <div style={{ marginTop: 14, padding: 12, borderRadius: 10, background: test.data.ok ? "#E6F4EC" : "#FBE9E7", border: `1px solid ${test.data.ok ? "#9DD3B0" : "#F0B0A6"}`, fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ink)" }}>
            {test.data.ok ? `✓ Test email sent via ${test.data.provider}. Check your inbox (and spam).` : `✗ ${test.data.error}`}
          </div>
        )}

        {data?.last_test_at && (
          <div style={{ marginTop: 14, fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)" }}>
            Last test: <strong style={{ color: data.last_test_status === "success" ? "#1F7A4B" : "#B23A2A" }}>{data.last_test_status}</strong> · {new Date(data.last_test_at).toLocaleString()}
            {data.last_test_error && <span> · {data.last_test_error}</span>}
          </div>
        )}
      </section>
    </div>
  );
}

const card: React.CSSProperties = { background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 16, padding: "22px 24px", display: "flex", flexDirection: "column", gap: 14 };
const input: React.CSSProperties = { padding: 10, border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 14, background: "#fff", width: "100%" };
const primaryBtn = (loading: boolean): React.CSSProperties => ({ padding: "9px 18px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: loading ? "not-allowed" : "pointer", opacity: loading ? 0.5 : 1 });
const ghostBtn = (disabled: boolean): React.CSSProperties => ({ padding: "9px 16px", background: "transparent", color: "var(--ss-ink)", border: "1px solid var(--ss-line)", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1 });

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)" }}>{label}</span>
      {children}
    </label>
  );
}
function Helper({ children }: { children: React.ReactNode }) {
  return <span style={{ fontFamily: "var(--font-sans)", fontSize: 11.5, color: "var(--ss-ash)" }}>{children}</span>;
}
