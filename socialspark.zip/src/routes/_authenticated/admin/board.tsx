import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Suspense, useState } from "react";
import { listLeads, updateLeadStatus } from "@/lib/leads.functions";
import { LeadDrawer } from "@/components/admin/LeadDrawer";

export const Route = createFileRoute("/_authenticated/admin/board")({
  head: () => ({ meta: [{ title: "Pipeline — Social Spark" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: () => (
    <Suspense fallback={<div style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</div>}>
      <BoardPage />
    </Suspense>
  ),
});

type Status = "new" | "contacted" | "qualified" | "won" | "lost";
const COLUMNS: { key: Status; label: string; accent: string }[] = [
  { key: "new", label: "New", accent: "var(--ss-gold, #F0C24A)" },
  { key: "contacted", label: "Contacted", accent: "#7BA7E1" },
  { key: "qualified", label: "Qualified", accent: "#B58CF0" },
  { key: "won", label: "Won", accent: "#5DBE89" },
  { key: "lost", label: "Lost", accent: "#C8C2B0" },
];

const QK = ["leads", "all", "all", ""] as const;

function BoardPage() {
  const qc = useQueryClient();
  const [active, setActive] = useState<string | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [hoverCol, setHoverCol] = useState<Status | null>(null);

  const { data } = useSuspenseQuery({
    queryKey: QK,
    queryFn: () => listLeads({ data: { status: "all", type: "all", search: "", limit: 500 } }),
  });

  const move = useMutation({
    mutationFn: (vars: { leadId: string; status: Status }) => updateLeadStatus({ data: vars }),
    onMutate: async (vars) => {
      await qc.cancelQueries({ queryKey: ["leads"] });
      const previous = qc.getQueryData<typeof data>(QK);
      qc.setQueryData<typeof data>(QK, (old) =>
        (old ?? []).map((l) => (l.id === vars.leadId ? { ...l, status: vars.status } : l)),
      );
      return { previous };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.previous) qc.setQueryData(QK, ctx.previous);
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: ["leads"] });
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
    },
  });

  function handleDrop(col: Status) {
    if (!dragId) return;
    const lead = data.find((l) => l.id === dragId);
    if (lead && lead.status !== col) move.mutate({ leadId: dragId, status: col });
    setDragId(null);
    setHoverCol(null);
  }

  return (
    <div>
      <header style={{ marginBottom: 18 }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>
          Operate · Pipeline
        </div>
        <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>
          Drag to move ({data.length})
        </h1>
        <p style={{ marginTop: 6, fontFamily: "var(--font-sans)", color: "var(--ss-ash)", fontSize: 13 }}>
          Grab a card and drop it on the column you want. Changes save instantly.
        </p>
      </header>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(5, minmax(220px, 1fr))", gap: 14, overflowX: "auto", paddingBottom: 12 }} className="kanban-grid">
        {COLUMNS.map((col) => {
          const items = data.filter((l) => l.status === col.key);
          const isHover = hoverCol === col.key;
          return (
            <section
              key={col.key}
              onDragOver={(e) => { e.preventDefault(); setHoverCol(col.key); }}
              onDragLeave={() => setHoverCol((h) => (h === col.key ? null : h))}
              onDrop={(e) => { e.preventDefault(); handleDrop(col.key); }}
              style={{
                background: isHover ? "#FFFBEC" : "#fff",
                border: `1px ${isHover ? "dashed" : "solid"} ${isHover ? "var(--ss-gold, #F0C24A)" : "var(--ss-line)"}`,
                borderRadius: 16,
                padding: 14,
                minHeight: 360,
                display: "flex",
                flexDirection: "column",
                transition: "background 120ms ease, border-color 120ms ease",
              }}
            >
              <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, paddingBottom: 10, borderBottom: `2px solid ${col.accent}` }}>
                <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ss-ink)" }}>{col.label}</span>
                <span style={{ fontSize: 12, color: "var(--ss-ash)", fontFamily: "var(--font-sans)" }}>{items.length}</span>
              </header>
              <div style={{ display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
                {items.length === 0 && (
                  <p style={{ margin: 0, color: "var(--ss-ash)", fontSize: 12, fontFamily: "var(--font-sans)", textAlign: "center", padding: "20px 0" }}>—</p>
                )}
                {items.map((l) => {
                  const dragging = dragId === l.id;
                  return (
                    <article
                      key={l.id}
                      draggable
                      onDragStart={(e) => { setDragId(l.id); e.dataTransfer.effectAllowed = "move"; }}
                      onDragEnd={() => { setDragId(null); setHoverCol(null); }}
                      onClick={() => setActive(l.id)}
                      style={{
                        background: dragging ? "#FFFBEC" : "#FAF8F2",
                        border: `1px solid ${dragging ? "var(--ss-gold, #F0C24A)" : "var(--ss-line)"}`,
                        borderRadius: 12,
                        padding: 12,
                        cursor: "grab",
                        opacity: dragging ? 0.6 : 1,
                        transition: "transform 120ms ease, box-shadow 120ms ease",
                        userSelect: "none",
                      }}
                      onMouseEnter={(e) => { if (!dragging) { e.currentTarget.style.transform = "translateY(-1px)"; e.currentTarget.style.boxShadow = "0 6px 16px rgba(0,0,0,0.06)"; } }}
                      onMouseLeave={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                        <strong style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)" }}>{l.name || l.business || l.email || "—"}</strong>
                        <span style={{ fontSize: 10, padding: "2px 6px", borderRadius: 999, background: col.accent, color: "var(--ss-ink)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>{l.type}</span>
                      </div>
                      {(l.email || l.phone) && (
                        <div style={{ marginTop: 6, fontSize: 12, color: "var(--ss-ash)", fontFamily: "var(--font-sans)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {l.email || l.phone}
                        </div>
                      )}
                      {l.message && (
                        <p style={{ margin: "8px 0 0", fontSize: 12, color: "var(--ss-ink)", lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                          {l.message}
                        </p>
                      )}
                      <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid var(--ss-line)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontSize: 10, color: "var(--ss-ash)", fontFamily: "var(--font-sans)" }}>{new Date(l.created_at).toLocaleDateString()}</span>
                        <span aria-hidden style={{ fontSize: 11, color: "var(--ss-ash)", fontFamily: "var(--font-sans)" }}>⠿ drag</span>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      <LeadDrawer leadId={active} onClose={() => setActive(null)} />

      <style>{`
        @media (max-width: 1100px) {
          .kanban-grid { grid-template-columns: repeat(5, minmax(240px, 1fr)) !important; }
        }
      `}</style>
    </div>
  );
}
