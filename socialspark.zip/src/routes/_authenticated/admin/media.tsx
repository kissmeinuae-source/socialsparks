import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { listMedia, registerMedia, deleteMedia, updateMedia } from "@/lib/admin/media.functions";
import { useDebounced } from "@/lib/admin/hooks";

type MediaType = "all" | "image" | "video" | "pdf" | "other";
type SizeBucket = "any" | "lt100k" | "100k-1m" | "1m-5m" | "gt5m";
type RangeBucket = "any" | "today" | "7d" | "30d" | "90d";
type PageSize = 24 | 48 | 96;

type MediaSearch = {
  q: string;
  type: MediaType;
  size: SizeBucket;
  range: RangeBucket;
  page: number;
  pageSize: PageSize;
};

const TYPES: MediaType[] = ["all", "image", "video", "pdf", "other"];
const SIZES: SizeBucket[] = ["any", "lt100k", "100k-1m", "1m-5m", "gt5m"];
const RANGES: RangeBucket[] = ["any", "today", "7d", "30d", "90d"];

function validateSearch(raw: Record<string, unknown>): MediaSearch {
  const oneOf = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T =>
    (typeof v === "string" && (allowed as readonly string[]).includes(v) ? (v as T) : fallback);
  const pageRaw = Number(raw.page);
  const sizeRaw = Number(raw.pageSize);
  const pageSize: PageSize = sizeRaw === 24 || sizeRaw === 96 ? sizeRaw : 48;
  return {
    q: typeof raw.q === "string" ? raw.q : "",
    type: oneOf(raw.type, TYPES, "all"),
    size: oneOf(raw.size, SIZES, "any"),
    range: oneOf(raw.range, RANGES, "any"),
    page: Number.isFinite(pageRaw) && pageRaw >= 1 ? Math.floor(pageRaw) : 1,
    pageSize,
  };
}


const SIZE_BUCKETS: Record<string, { min?: number; max?: number }> = {
  any: {},
  lt100k: { max: 100 * 1024 },
  "100k-1m": { min: 100 * 1024, max: 1024 * 1024 },
  "1m-5m": { min: 1024 * 1024, max: 5 * 1024 * 1024 },
  gt5m: { min: 5 * 1024 * 1024 },
};

function rangeToIso(range: string): { from?: string; to?: string } {
  if (range === "any") return {};
  const now = new Date();
  const start = new Date(now);
  if (range === "today") start.setHours(0, 0, 0, 0);
  else if (range === "7d") start.setDate(now.getDate() - 7);
  else if (range === "30d") start.setDate(now.getDate() - 30);
  else if (range === "90d") start.setDate(now.getDate() - 90);
  return { from: start.toISOString(), to: now.toISOString() };
}

function fmtBytes(n: number | null | undefined) {
  if (!n) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export const Route = createFileRoute("/_authenticated/admin/media")({
  validateSearch: (s: Record<string, unknown>): MediaSearch => validateSearch(s),
  component: () => (
    <Suspense fallback={<div style={{ fontFamily: "var(--font-sans)", color: "var(--ss-ash)" }}>Loading…</div>}>
      <MediaPage />
    </Suspense>
  ),
});

function MediaPage() {
  const qc = useQueryClient();
  const navigate = useNavigate({ from: "/_authenticated/admin/media" });
  const { q, type, size, range, page, pageSize } = Route.useSearch();

  // Local search input for snappy typing; debounced into the URL.
  const [localQ, setLocalQ] = useState(q);
  useEffect(() => { setLocalQ(q); }, [q]);
  const debouncedQ = useDebounced(localQ, 250);
  useEffect(() => {
    if (debouncedQ !== q) {
      navigate({ search: (prev: MediaSearch) => ({ ...prev, q: debouncedQ, page: 1 }), replace: true });
    }
  }, [debouncedQ, q, navigate]);

  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({});

  const { from, to } = useMemo(() => rangeToIso(range), [range]);
  const { min, max } = useMemo(() => {
    const b = SIZE_BUCKETS[size] ?? {};
    return { min: b.min, max: b.max };
  }, [size]);

  const { data: result } = useSuspenseQuery({
    queryKey: ["media", { q, type, size, range, page, pageSize }] as const,
    queryFn: () =>
      listMedia({
        data: {
          search: q,
          type,
          minSize: min,
          maxSize: max,
          from,
          to,
          page,
          pageSize,
        },
      }),
  });

  const assets = result.rows;
  const total = result.total;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  // Generate signed URLs for current page
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const out: Record<string, string> = {};
      await Promise.all(
        assets.map(async (a) => {
          const { data } = await supabase.storage.from("media").createSignedUrl(a.storage_path, 3600);
          if (data?.signedUrl) out[a.id] = data.signedUrl;
        }),
      );
      if (!cancelled) setPreviewUrls(out);
    })();
    return () => { cancelled = true; };
  }, [assets]);

  const delMut = useMutation({
    mutationFn: (id: string) => deleteMedia({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["media"] }),
  });

  const altMut = useMutation({
    mutationFn: (vars: { id: string; alt: string }) => updateMedia({ data: { id: vars.id, alt: vars.alt } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["media"] }),
  });

  async function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    setUploading(true);
    try {
      for (const file of files) {
        const safe = file.name.toLowerCase().replace(/[^a-z0-9.\-_]/g, "-").replace(/-+/g, "-");
        const path = `${new Date().toISOString().slice(0, 7)}/${Date.now()}-${safe}`;
        const { error } = await supabase.storage.from("media").upload(path, file, {
          contentType: file.type || undefined,
          upsert: false,
        });
        if (error) throw error;
        await registerMedia({
          data: {
            storage_path: path,
            filename: file.name,
            mime_type: file.type || undefined,
            size_bytes: file.size,
            tags: [],
          },
        });
      }
      qc.invalidateQueries({ queryKey: ["media"] });
    } catch (err) {
      alert(`Upload failed: ${(err as Error).message}`);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function copyUrl(id: string) {
    const url = previewUrls[id];
    if (!url) return;
    await navigator.clipboard.writeText(url);
    alert("Signed URL copied (valid 1 hour).");
  }

  function setFilter<K extends "type" | "size" | "range" | "pageSize">(key: K, value: unknown) {
    navigate({ search: (prev: MediaSearch) => ({ ...prev, [key]: value, page: 1 } as never), replace: true });
  }
  function gotoPage(p: number) {
    navigate({ search: (prev: MediaSearch) => ({ ...prev, page: p } as never) });
  }
  function resetFilters() {
    navigate({ search: () => ({ q: "", type: "all", size: "any", range: "any", page: 1, pageSize } as never), replace: true });
  }

  const activeFilterCount =
    (q ? 1 : 0) + (type !== "all" ? 1 : 0) + (size !== "any" ? 1 : 0) + (range !== "any" ? 1 : 0);

  const showingFrom = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const showingTo = Math.min(page * pageSize, total);

  return (
    <div>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "end", flexWrap: "wrap", gap: 16, marginBottom: 18 }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ash)" }}>Content · Media</div>
          <h1 style={{ margin: "6px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 42, color: "var(--ss-ink)", lineHeight: 1.05 }}>
            Media library ({total.toLocaleString()})
          </h1>
          <p style={{ marginTop: 6, fontFamily: "var(--font-sans)", color: "var(--ss-ash)", fontSize: 14, maxWidth: 580 }}>
            Private bucket. Files are served via 1-hour signed URLs — paste them into blog posts, OG images and CMS records.
          </p>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <input
            placeholder="Search filename…"
            value={localQ}
            onChange={(e) => setLocalQ(e.target.value)}
            style={{ padding: "10px 14px", border: "1px solid var(--ss-line)", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, minWidth: 220 }}
          />
          <input ref={fileRef} type="file" multiple accept="image/*,video/*,application/pdf" onChange={onPick} style={{ display: "none" }} />
          <button
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            style={{ padding: "10px 18px", borderRadius: 10, background: "var(--ss-gold)", color: "var(--ss-ink)", border: "none", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 700, cursor: uploading ? "wait" : "pointer" }}
          >
            {uploading ? "Uploading…" : "Upload"}
          </button>
        </div>
      </header>

      {/* Filter bar */}
      <div style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 12, padding: "10px 14px", display: "flex", flexWrap: "wrap", gap: 14, alignItems: "center", marginBottom: 14 }}>
        <Group label="Type">
          <select value={type} onChange={(e) => setFilter("type", e.target.value)} style={select}>
            <option value="all">All</option>
            <option value="image">Images</option>
            <option value="video">Video</option>
            <option value="pdf">PDF</option>
            <option value="other">Other</option>
          </select>
        </Group>
        <Group label="Size">
          <select value={size} onChange={(e) => setFilter("size", e.target.value)} style={select}>
            <option value="any">Any</option>
            <option value="lt100k">&lt; 100 KB</option>
            <option value="100k-1m">100 KB – 1 MB</option>
            <option value="1m-5m">1 MB – 5 MB</option>
            <option value="gt5m">&gt; 5 MB</option>
          </select>
        </Group>
        <Group label="Date">
          <select value={range} onChange={(e) => setFilter("range", e.target.value)} style={select}>
            <option value="any">All time</option>
            <option value="today">Today</option>
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
        </Group>
        <Group label="Per page">
          <select value={pageSize} onChange={(e) => setFilter("pageSize", Number(e.target.value))} style={select}>
            <option value={24}>24</option>
            <option value={48}>48</option>
            <option value={96}>96</option>
          </select>
        </Group>
        {activeFilterCount > 0 && (
          <button onClick={resetFilters} style={{ ...smallBtn, marginLeft: "auto", flex: "none", padding: "6px 12px" }}>
            Clear filters ({activeFilterCount})
          </button>
        )}
      </div>

      {assets.length === 0 ? (
        <div style={{ background: "#fff", border: "1px dashed var(--ss-line)", borderRadius: 18, padding: 60, textAlign: "center", color: "var(--ss-ash)", fontFamily: "var(--font-sans)" }}>
          {total === 0 && activeFilterCount === 0
            ? <>Nothing yet. Drop your first image or PDF using <strong>Upload</strong>.</>
            : <>No files match these filters. <button onClick={resetFilters} style={{ ...smallBtn, display: "inline-block", marginLeft: 8 }}>Clear</button></>}
        </div>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 14 }}>
            {assets.map((a) => {
              const isImg = (a.mime_type ?? "").startsWith("image/");
              const url = previewUrls[a.id];
              return (
                <div key={a.id} style={{ background: "#fff", border: "1px solid var(--ss-line)", borderRadius: 14, overflow: "hidden", display: "flex", flexDirection: "column" }}>
                  <div style={{ aspectRatio: "4 / 3", background: "#FAF8F2", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
                    {isImg && url ? (
                      <img src={url} alt={a.alt ?? a.filename} style={{ width: "100%", height: "100%", objectFit: "cover" }} loading="lazy" />
                    ) : (
                      <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash)", textTransform: "uppercase", letterSpacing: "0.14em" }}>{(a.mime_type ?? "file").split("/").pop()}</span>
                    )}
                  </div>
                  <div style={{ padding: 12, display: "flex", flexDirection: "column", gap: 6 }}>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={a.filename}>{a.filename}</div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, color: "var(--ss-ash)", display: "flex", justifyContent: "space-between" }}>
                      <span>{fmtBytes(a.size_bytes)}</span>
                      <span>{new Date(a.created_at).toLocaleDateString()}</span>
                    </div>
                    <input
                      placeholder="Alt text for SEO/a11y…"
                      defaultValue={a.alt ?? ""}
                      onBlur={(e) => {
                        const v = e.target.value.trim();
                        if (v !== (a.alt ?? "")) altMut.mutate({ id: a.id, alt: v });
                      }}
                      style={{ padding: "6px 8px", fontFamily: "var(--font-sans)", fontSize: 12, border: "1px solid var(--ss-line)", borderRadius: 6, outline: "none" }}
                    />
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={() => copyUrl(a.id)} style={smallBtn}>Copy URL</button>
                      <button onClick={() => { if (confirm("Delete this file?")) delMut.mutate(a.id); }} style={{ ...smallBtn, color: "#b91c1c", borderColor: "#fecaca" }}>Delete</button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pagination */}
          <nav aria-label="Pagination" style={{ marginTop: 18, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10, fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ash)" }}>
            <span>Showing <strong style={{ color: "var(--ss-ink)" }}>{showingFrom.toLocaleString()}–{showingTo.toLocaleString()}</strong> of {total.toLocaleString()}</span>
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <button onClick={() => gotoPage(1)} disabled={page <= 1} style={pageBtn(page <= 1)}>« First</button>
              <button onClick={() => gotoPage(page - 1)} disabled={page <= 1} style={pageBtn(page <= 1)}>‹ Prev</button>
              <span style={{ padding: "0 10px", color: "var(--ss-ink)", fontWeight: 600 }}>Page {page} / {totalPages}</span>
              <button onClick={() => gotoPage(page + 1)} disabled={page >= totalPages} style={pageBtn(page >= totalPages)}>Next ›</button>
              <button onClick={() => gotoPage(totalPages)} disabled={page >= totalPages} style={pageBtn(page >= totalPages)}>Last »</button>
            </div>
          </nav>
        </>
      )}
    </div>
  );
}

function Group({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "var(--ss-ash)" }}>{label}</span>
      {children}
    </label>
  );
}

const select: React.CSSProperties = {
  padding: "6px 10px",
  border: "1px solid var(--ss-line)",
  borderRadius: 8,
  background: "#fff",
  fontFamily: "var(--font-sans)",
  fontSize: 13,
  color: "var(--ss-ink)",
  cursor: "pointer",
};

const smallBtn: React.CSSProperties = {
  flex: 1,
  padding: "6px 8px",
  borderRadius: 6,
  background: "#fff",
  border: "1px solid var(--ss-line)",
  fontFamily: "var(--font-sans)",
  fontSize: 11,
  fontWeight: 600,
  cursor: "pointer",
  color: "var(--ss-ink)",
};

const pageBtn = (disabled: boolean): React.CSSProperties => ({
  padding: "6px 12px",
  borderRadius: 8,
  background: disabled ? "#FAF8F2" : "#fff",
  border: "1px solid var(--ss-line)",
  fontFamily: "var(--font-sans)",
  fontSize: 12,
  fontWeight: 600,
  color: disabled ? "var(--ss-ash)" : "var(--ss-ink)",
  cursor: disabled ? "not-allowed" : "pointer",
});
