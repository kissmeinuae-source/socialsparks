import { lazy } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/home/Hero";
import { MarqueeTicker } from "@/components/home/MarqueeTicker";
import { LazySection } from "@/components/LazySection";
import { absolute, faqPageSchema, organizationSchema } from "@/lib/seo";

// Below-the-fold sections are code-split to keep the initial JS budget tight
// (improves LCP/INP). The Hero + MarqueeTicker render eagerly because they are
// part of the LCP region.
const TrustStrip = lazy(() => import("@/components/home/TrustStrip").then((m) => ({ default: m.TrustStrip })));
const Services = lazy(() => import("@/components/home/Services").then((m) => ({ default: m.Services })));
const Statistics = lazy(() => import("@/components/home/Statistics").then((m) => ({ default: m.Statistics })));
const Process = lazy(() => import("@/components/home/Process").then((m) => ({ default: m.Process })));
const FreeAudit = lazy(() => import("@/components/home/FreeAudit").then((m) => ({ default: m.FreeAudit })));
const Pricing = lazy(() => import("@/components/home/Pricing").then((m) => ({ default: m.Pricing })));
const Testimonials = lazy(() => import("@/components/home/Testimonials").then((m) => ({ default: m.Testimonials })));
const FAQ = lazy(() => import("@/components/home/FAQ").then((m) => ({ default: m.FAQ })));
const About = lazy(() => import("@/components/home/About").then((m) => ({ default: m.About })));
const BookACall = lazy(() => import("@/components/home/BookACall").then((m) => ({ default: m.BookACall })));
const Contact = lazy(() => import("@/components/home/Contact").then((m) => ({ default: m.Contact })));

const HOME_FAQS = [
  { q: "Where is Social Spark based?", a: "We're based in Lahore, Pakistan, and work with brands and public figures across the country." },
  { q: "Do you work with non-Pakistani businesses?", a: "Yes — we serve Pakistani-owned businesses globally, including the UK, UAE, and US diaspora markets." },
  { q: "What's included in the free audit?", a: "A 30-minute strategy call plus a written 7-page audit of your social, ads, and website covering quick wins and a 90-day plan." },
  { q: "How quickly can we start?", a: "Most engagements kick off within 7 working days of contract signature." },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Social Spark — Digital Marketing Agency | Lahore, Pakistan" },
      {
        name: "description",
        content:
          "Social Spark is Pakistan's premium digital marketing agency. Social media, paid ads, website design for SMBs and public figures. Based in Lahore. Book a free call.",
      },
      {
        property: "og:title",
        content: "Social Spark — Digital Marketing Agency | Lahore, Pakistan",
      },
      {
        property: "og:description",
        content:
          "Premium digital marketing for Pakistan's most recognisable brands and personalities. No vanity metrics — measurable growth.",
      },
      { property: "og:url", content: absolute("/") },
      { property: "og:image", content: absolute("/og-default.jpg") },
      { name: "twitter:image", content: absolute("/og-default.jpg") },
      { property: "og:type", content: "website" },
      {
        name: "twitter:title",
        content: "Social Spark — Digital Marketing Agency | Lahore, Pakistan",
      },
      {
        name: "twitter:description",
        content:
          "Premium digital marketing for Pakistan's most recognisable brands and personalities.",
      },
    ],
    links: [{ rel: "canonical", href: absolute("/") }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          "@id": absolute("/#business"),
          name: "Social Spark",
          url: absolute("/"),
          image: absolute("/og-default.jpg"),
          logo: absolute("/logo.png"),
          description:
            "Premium digital marketing agency in Lahore, Pakistan. Social media, paid ads, website design for SMBs and public figures.",
          telephone: "+92-300-0000000",
          address: {
            "@type": "PostalAddress",
            addressLocality: "Lahore",
            addressRegion: "Punjab",
            addressCountry: "PK",
          },
          areaServed: "PK",
          priceRange: "$$",
          sameAs: [
            "https://instagram.com/socialspark",
            "https://facebook.com/socialspark",
            "https://linkedin.com/company/socialspark",
          ],
        }),
      },
      { type: "application/ld+json", children: JSON.stringify(organizationSchema()) },
      { type: "application/ld+json", children: JSON.stringify(faqPageSchema(HOME_FAQS)) },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <MarqueeTicker />
      <LazySection minHeight={320}><TrustStrip /></LazySection>
      <LazySection minHeight={600}><Services /></LazySection>
      <LazySection minHeight={500}><Statistics /></LazySection>
      <LazySection minHeight={600}><Process /></LazySection>
      <LazySection minHeight={500}><FreeAudit /></LazySection>
      <LazySection minHeight={700}><Pricing /></LazySection>
      <LazySection minHeight={500}><Testimonials /></LazySection>
      <LazySection minHeight={500}><FAQ /></LazySection>
      <LazySection minHeight={600}><About /></LazySection>
      <LazySection minHeight={500}><BookACall /></LazySection>
      <LazySection minHeight={500}><Contact /></LazySection>
    </>
  );
}
