import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { listPublishedPosts } from "@/lib/cms.functions";
import { useLanguage } from "@/lib/language";
import { absolute, breadcrumbSchema } from "@/lib/seo";

const postsQueryOptions = queryOptions({
  queryKey: ["public", "blog", "list"],
  queryFn: () => listPublishedPosts(),
});

export const Route = createFileRoute("/blog/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(postsQueryOptions),
  head: () => ({
    meta: [
      { title: "Insights — Social Spark Blog" },
      {
        name: "description",
        content:
          "Practical writing on social media, paid ads, and digital growth for Pakistani businesses.",
      },
      { property: "og:title", content: "Insights — Social Spark Blog" },
      {
        property: "og:description",
        content:
          "Field notes from a Lahore-based agency working with restaurants, clinics, salons and public figures.",
      },
      { property: "og:url", content: absolute("/blog") },
      { property: "og:image", content: absolute("/og-default.jpg") },
      { name: "twitter:image", content: absolute("/og-default.jpg") },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: absolute("/blog") }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Blog", path: "/blog" },
          ]),
        ),
      },
    ],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  const { data: posts } = useSuspenseQuery(postsQueryOptions);
  const { lang } = useLanguage();

  return (
    <section style={{ background: "var(--ss-paper)", padding: "120px 48px 144px" }}>
      <div className="mx-auto max-w-[1160px]">
        <FadeSlide>
          <div className="flex items-center gap-3">
            <span className="h-px w-6 bg-gold" />
            <span className="t-label text-gold">JOURNAL</span>
          </div>
        </FadeSlide>
        <FadeSlide delay={80}>
          <h1 className="mt-5 text-navy">{lang === "ur" ? "بصیرتیں." : "Insights."}</h1>
        </FadeSlide>
        <FadeSlide delay={140}>
          <p
            className="mt-5 max-w-[640px]"
            style={{ color: "var(--ss-slate)", fontSize: 17, lineHeight: 1.75 }}
            dir={lang === "ur" ? "rtl" : "ltr"}
          >
            {lang === "ur"
              ? "لاہور کی ایک چھوٹی ایجنسی کے میدانی نوٹس۔ کوئی فلر نہیں — صرف وہی جو پاکستانی برانڈز کے لیے کارگر ہے۔"
              : "Field notes from a small Lahore agency. No fluff, no listicles — just what we've actually seen work for Pakistani brands."}
          </p>
        </FadeSlide>

        {posts.length === 0 ? (
          <FadeSlide delay={160}>
            <div
              className="mt-16"
              style={{
                background: "white",
                border: "1px dashed var(--ss-rule)",
                borderRadius: 14,
                padding: "56px 24px",
                textAlign: "center",
                color: "var(--ss-ash)",
              }}
            >
              New articles coming soon — check back shortly.
            </div>
          </FadeSlide>
        ) : (
          <div className="mt-16 grid gap-8 md:grid-cols-3">
            {posts.map((p, i) => {
              const title = (lang === "ur" && p.title_ur) || p.title_en;
              const excerpt = (lang === "ur" && p.excerpt_ur) || p.excerpt_en;
              const date = p.published_at
                ? new Date(p.published_at).toLocaleDateString(lang === "ur" ? "ur-PK" : "en-US", {
                    month: "short", day: "numeric", year: "numeric",
                  })
                : null;
              return (
                <FadeSlide key={p.id} delay={i * 80}>
                  <Link
                    to="/blog/$slug"
                    params={{ slug: p.slug }}
                    className="group block h-full transition-transform hover:-translate-y-1"
                    style={{
                      background: "white",
                      border: "1px solid var(--ss-rule)",
                      borderRadius: 14,
                      padding: 28,
                      textDecoration: "none",
                      height: "100%",
                      display: "flex",
                      flexDirection: "column",
                    }}
                  >
                    {p.cover_image_url && (
                      <img
                        src={p.cover_image_url}
                        alt=""
                        loading="lazy"
                        style={{
                          width: "calc(100% + 56px)",
                          margin: "-28px -28px 20px",
                          height: 180,
                          objectFit: "cover",
                          borderRadius: "14px 14px 0 0",
                          display: "block",
                        }}
                      />
                    )}
                    <div className="t-label text-gold">{p.category}</div>
                    <h2
                      className="mt-3 text-navy"
                      dir={lang === "ur" && p.title_ur ? "rtl" : "ltr"}
                      style={{
                        fontFamily: "var(--font-serif, var(--font-display))",
                        fontStyle: "italic",
                        fontWeight: 500,
                        fontSize: 24,
                        lineHeight: 1.2,
                      }}
                    >
                      {title}
                    </h2>
                    {excerpt && (
                      <p
                        className="mt-4 flex-1"
                        dir={lang === "ur" && p.excerpt_ur ? "rtl" : "ltr"}
                        style={{
                          color: "var(--ss-slate)",
                          fontSize: 14,
                          lineHeight: 1.7,
                          display: "-webkit-box",
                          WebkitLineClamp: 3,
                          WebkitBoxOrient: "vertical",
                          overflow: "hidden",
                        }}
                      >
                        {excerpt}
                      </p>
                    )}
                    <div
                      className="mt-6 flex items-center gap-3"
                      style={{ color: "var(--ss-ash)", fontSize: 13 }}
                    >
                      {date && <span>{date}</span>}
                      {date && <span>·</span>}
                      <span>{p.read_time}</span>
                    </div>
                  </Link>
                </FadeSlide>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
