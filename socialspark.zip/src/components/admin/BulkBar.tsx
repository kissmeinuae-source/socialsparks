import { motion, AnimatePresence } from "framer-motion";
import type { ReactNode } from "react";

export function BulkBar({
  count,
  onClear,
  children,
}: {
  count: number;
  onClear: () => void;
  children: ReactNode;
}) {
  return (
    <AnimatePresence>
      {count > 0 && (
        <motion.div
          initial={{ y: 24, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 24, opacity: 0 }}
          transition={{ duration: 0.18, ease: "easeOut" }}
          style={{
            position: "fixed",
            left: "50%",
            transform: "translateX(-50%)",
            bottom: 24,
            zIndex: 50,
            display: "flex",
            alignItems: "center",
            gap: 14,
            padding: "10px 14px 10px 18px",
            borderRadius: 999,
            background: "var(--ss-ink, #0E1B3D)",
            color: "#fff",
            boxShadow: "0 10px 30px rgba(14,27,61,0.25)",
            fontFamily: "var(--font-sans)",
            fontSize: 13,
          }}
        >
          <span style={{ fontWeight: 600 }}>{count} selected</span>
          <span style={{ width: 1, height: 18, background: "rgba(255,255,255,0.18)" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>{children}</div>
          <button
            onClick={onClear}
            style={{
              padding: "6px 12px",
              borderRadius: 999,
              background: "rgba(255,255,255,0.1)",
              color: "#fff",
              border: "none",
              fontFamily: "inherit",
              fontSize: 12,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Clear
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function BulkAction({ children, onClick, danger }: { children: ReactNode; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "6px 12px",
        borderRadius: 999,
        background: danger ? "rgba(239,68,68,0.18)" : "transparent",
        color: danger ? "#fecaca" : "#fff",
        border: "1px solid rgba(255,255,255,0.18)",
        fontFamily: "inherit",
        fontSize: 12,
        fontWeight: 600,
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}
