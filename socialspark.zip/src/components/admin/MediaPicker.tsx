import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { listMedia } from "@/lib/admin/media.functions";

/**
 * MediaPicker — opens a modal that lets the operator pick from the private
 * media library or paste any URL. Returns a string URL via `onPick`.
 *
 * For library files we hand back a 7-day signed URL so the value stays valid
 * inside saved CMS records.
 */
export function MediaPicker({
  open,
  onOpenChange,
  onPick,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onPick: (url: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [manualUrl, setManualUrl] = useState("");
  const [thumbs, setThumbs] = useState<Record<string, string>>({});

  const { data: result } = useQuery({
    queryKey: ["media-picker", search],
    queryFn: () => listMedia({ data: { search, pageSize: 60 } }),
    enabled: open,
  });
  const data = result?.rows ?? [];

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    (async () => {
      const out: Record<string, string> = {};
      await Promise.all(
        data.map(async (a) => {
          const { data: s } = await supabase.storage.from("media").createSignedUrl(a.storage_path, 600);
          if (s?.signedUrl) out[a.id] = s.signedUrl;
        }),
      );
      if (!cancelled) setThumbs(out);
    })();
    return () => {
      cancelled = true;
    };
  }, [data, open]);

  async function pickFromLibrary(storagePath: string) {
    const { data: s, error } = await supabase.storage.from("media").createSignedUrl(storagePath, 60 * 60 * 24 * 7);
    if (error || !s?.signedUrl) {
      alert(`Could not sign URL: ${error?.message ?? "unknown"}`);
      return;
    }
    onPick(s.signedUrl);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 26 }}>Pick an image</DialogTitle>
        </DialogHeader>

        <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
          <input
            placeholder="Search library by filename…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ flex: 1, padding: "8px 12px", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13 }}
          />
        </div>

        <div style={{ maxHeight: 360, overflowY: "auto", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 10 }}>
          {data.length === 0 && (
            <div style={{ gridColumn: "1 / -1", color: "var(--ss-ash)", fontFamily: "var(--font-sans)", fontSize: 13, padding: 20, textAlign: "center" }}>
              No matching files in the library.
            </div>
          )}
          {data.map((a) => {
            const isImg = (a.mime_type ?? "").startsWith("image/");
            const url = thumbs[a.id];
            return (
              <button
                key={a.id}
                onClick={() => pickFromLibrary(a.storage_path)}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  border: "1px solid var(--ss-line)",
                  borderRadius: 10,
                  background: "#fff",
                  cursor: "pointer",
                  overflow: "hidden",
                  padding: 0,
                  textAlign: "left",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--ss-gold)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "var(--ss-line)")}
              >
                <div style={{ aspectRatio: "4 / 3", background: "#FAF8F2", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {isImg && url ? (
                    <img src={url} alt={a.alt ?? a.filename} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  ) : (
                    <span style={{ fontSize: 11, color: "var(--ss-ash)", fontFamily: "var(--font-sans)", textTransform: "uppercase", letterSpacing: "0.12em" }}>{(a.mime_type ?? "file").split("/").pop()}</span>
                  )}
                </div>
                <div style={{ padding: "6px 8px", fontFamily: "var(--font-sans)", fontSize: 11, color: "var(--ss-ink)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={a.filename}>
                  {a.filename}
                </div>
              </button>
            );
          })}
        </div>

        <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--ss-line)", display: "flex", gap: 8 }}>
          <input
            value={manualUrl}
            onChange={(e) => setManualUrl(e.target.value)}
            placeholder="…or paste any image URL"
            style={{ flex: 1, padding: "8px 12px", border: "1px solid var(--ss-line)", borderRadius: 8, fontFamily: "var(--font-sans)", fontSize: 13 }}
          />
          <button
            onClick={() => {
              if (!manualUrl.trim()) return;
              onPick(manualUrl.trim());
              setManualUrl("");
              onOpenChange(false);
            }}
            style={{ padding: "8px 16px", borderRadius: 8, background: "var(--ss-ink)", color: "#fff", border: "none", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer" }}
          >
            Use URL
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
