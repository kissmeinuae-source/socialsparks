import { Link, useRouterState } from "@tanstack/react-router";

const LABELS: Record<string, string> = {
  admin: "Console",
  leads: "Leads",
  board: "Pipeline",
  inbox: "Inbox",
  media: "Media",
  seo: "SEO",
  blog: "Blog",
  services: "Services",
  pricing: "Pricing",
  testimonials: "Testimonials",
  automations: "Automations",
  email: "Email",
  settings: "Settings",
};

export function Breadcrumbs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const parts = pathname.split("/").filter(Boolean);
  const crumbs = parts.map((p, i) => ({
    label: LABELS[p] ?? p.replace(/-/g, " "),
    to: "/" + parts.slice(0, i + 1).join("/"),
  }));
  return (
    <nav aria-label="Breadcrumb" style={{ display: "flex", alignItems: "center", gap: 6, fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-ash, #6B7280)" }}>
      {crumbs.map((c, i) => {
        const last = i === crumbs.length - 1;
        return (
          <span key={c.to} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            {i > 0 && <span aria-hidden style={{ opacity: 0.4 }}>/</span>}
            {last ? (
              <span style={{ color: "var(--ss-ink, #0E1B3D)", fontWeight: 600, textTransform: "capitalize" }}>{c.label}</span>
            ) : (
              <Link to={c.to} style={{ color: "inherit", textDecoration: "none", textTransform: "capitalize" }}>
                {c.label}
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
