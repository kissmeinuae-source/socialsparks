import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { listViews, saveView, deleteView } from "@/lib/admin/views.functions";
import { useState } from "react";

type ViewPayload = {
  filters: Record<string, unknown>;
  sort?: Record<string, unknown>;
  columns?: string[];
};

export function SavedViewsBar({
  module,
  current,
  onApply,
}: {
  module: string;
  current: ViewPayload;
  onApply: (v: ViewPayload) => void;
}) {
  const qc = useQueryClient();
  const [savingName, setSavingName] = useState("");
  const { data: views = [] } = useQuery({
    queryKey: ["admin-views", module],
    queryFn: () => listViews({ data: { module } }),
  });

  const saveMut = useMutation({
    mutationFn: (name: string) =>
      saveView({
        data: {
          name,
          module,
          filters: current.filters,
          sort: current.sort ?? {},
          columns: current.columns ?? [],
          is_default: false,
        },
      }),
    onSuccess: () => {
      setSavingName("");
      qc.invalidateQueries({ queryKey: ["admin-views", module] });
    },
  });

  const delMut = useMutation({
    mutationFn: (id: string) => deleteView({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-views", module] }),
  });

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        flexWrap: "wrap",
        padding: "10px 14px",
        background: "#fff",
        border: "1px solid var(--ss-line, #E6E2D6)",
        borderRadius: 12,
        marginBottom: 14,
      }}
    >
      <span
        style={{
          fontFamily: "var(--font-sans)",
          fontSize: 11,
          fontWeight: 600,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "var(--ss-ash, #6B7280)",
          marginRight: 4,
        }}
      >
        Views
      </span>
      {views.length === 0 && (
        <span style={{ fontSize: 12, color: "var(--ss-ash, #9AA0A6)", fontFamily: "var(--font-sans)" }}>
          None saved — name and save the current filter set.
        </span>
      )}
      {views.map((v) => (
        <span key={v.id} style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          <button
            onClick={() =>
              onApply({
                filters: (v.filters as Record<string, unknown>) ?? {},
                sort: (v.sort as Record<string, unknown>) ?? {},
                columns: (v.columns as string[]) ?? [],
              })
            }
            style={chipStyle}
          >
            {v.name}
          </button>
          <button
            aria-label={`Delete view ${v.name}`}
            onClick={() => delMut.mutate(v.id)}
            style={{
              border: "none",
              background: "transparent",
              cursor: "pointer",
              color: "var(--ss-ash, #9AA0A6)",
              fontSize: 14,
              padding: "0 4px",
            }}
          >
            ×
          </button>
        </span>
      ))}
      <span style={{ flex: 1 }} />
      <input
        placeholder="Save current as…"
        value={savingName}
        onChange={(e) => setSavingName(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && savingName.trim()) saveMut.mutate(savingName.trim());
        }}
        style={{
          padding: "6px 10px",
          borderRadius: 8,
          border: "1px solid var(--ss-line, #E6E2D6)",
          fontFamily: "var(--font-sans)",
          fontSize: 13,
          minWidth: 180,
        }}
      />
      <button
        onClick={() => savingName.trim() && saveMut.mutate(savingName.trim())}
        disabled={!savingName.trim() || saveMut.isPending}
        style={{
          padding: "7px 14px",
          borderRadius: 8,
          background: "var(--ss-ink, #0E1B3D)",
          color: "#fff",
          border: "none",
          fontFamily: "var(--font-sans)",
          fontSize: 13,
          fontWeight: 600,
          cursor: savingName.trim() ? "pointer" : "not-allowed",
          opacity: savingName.trim() ? 1 : 0.5,
        }}
      >
        Save
      </button>
    </div>
  );
}

const chipStyle: React.CSSProperties = {
  padding: "5px 12px",
  borderRadius: 999,
  border: "1px solid var(--ss-line, #E6E2D6)",
  background: "#FAF8F2",
  color: "var(--ss-ink, #0E1B3D)",
  fontFamily: "var(--font-sans)",
  fontSize: 12,
  fontWeight: 600,
  cursor: "pointer",
};
