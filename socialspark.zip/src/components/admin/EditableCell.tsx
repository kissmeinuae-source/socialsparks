import { useEffect, useRef, useState } from "react";

export function EditableCell({
  value,
  onSave,
  placeholder,
  type = "text",
}: {
  value: string | number | null | undefined;
  onSave: (next: string) => void | Promise<void>;
  placeholder?: string;
  type?: "text" | "email" | "tel" | "number";
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value == null ? "" : String(value));
  const ref = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (editing) {
      ref.current?.focus();
      ref.current?.select();
    } else {
      setDraft(value == null ? "" : String(value));
    }
  }, [editing, value]);

  async function commit() {
    const next = draft.trim();
    if (next === String(value ?? "").trim()) {
      setEditing(false);
      return;
    }
    await onSave(next);
    setEditing(false);
  }

  if (!editing) {
    return (
      <button
        type="button"
        onClick={() => setEditing(true)}
        style={{
          textAlign: "left",
          background: "transparent",
          border: "1px dashed transparent",
          padding: "4px 6px",
          borderRadius: 6,
          fontFamily: "var(--font-sans)",
          fontSize: 14,
          color: value == null || value === "" ? "var(--ss-ash, #9AA0A6)" : "var(--ss-ink, #0E1B3D)",
          cursor: "text",
          width: "100%",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--ss-line, #E6E2D6)")}
        onMouseLeave={(e) => (e.currentTarget.style.borderColor = "transparent")}
      >
        {value == null || value === "" ? placeholder ?? "—" : String(value)}
      </button>
    );
  }

  return (
    <input
      ref={ref}
      type={type}
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") commit();
        if (e.key === "Escape") setEditing(false);
      }}
      style={{
        width: "100%",
        padding: "4px 6px",
        borderRadius: 6,
        border: "1px solid var(--ss-gold, #F0C24A)",
        outline: "none",
        fontFamily: "var(--font-sans)",
        fontSize: 14,
        background: "#FFFBEC",
      }}
    />
  );
}
