import { useQuery } from "@tanstack/react-query";
import { listActivity } from "@/lib/admin/activity.functions";

export function ActivityFeed({ entityType, entityId, limit = 50 }: { entityType?: string; entityId?: string; limit?: number }) {
  const { data = [], isLoading } = useQuery({
    queryKey: ["activity", entityType, entityId, limit],
    queryFn: () => listActivity({ data: { entity_type: entityType, entity_id: entityId, limit } }),
  });

  if (isLoading) {
    return <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ash)" }}>Loading activity…</div>;
  }
  if (data.length === 0) {
    return <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ash)" }}>No activity yet.</div>;
  }

  return (
    <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 12 }}>
      {data.map((a) => (
        <li key={a.id} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
          <span
            aria-hidden
            style={{
              width: 8,
              height: 8,
              marginTop: 6,
              borderRadius: "50%",
              background: "var(--ss-gold, #F0C24A)",
              flexShrink: 0,
            }}
          />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--ss-ink, #0E1B3D)" }}>
              <strong style={{ fontWeight: 600 }}>{a.action}</strong>
              {a.diff && Object.keys(a.diff as object).length > 0 && (
                <span style={{ color: "var(--ss-ash, #6B7280)" }}>
                  {" — "}
                  {Object.entries(a.diff as Record<string, unknown>)
                    .slice(0, 3)
                    .map(([k, v]) => `${k}: ${String(v)}`)
                    .join(", ")}
                </span>
              )}
            </div>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, color: "var(--ss-ash, #9AA0A6)" }}>
              {a.entity_type} · {new Date(a.created_at).toLocaleString()}
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
