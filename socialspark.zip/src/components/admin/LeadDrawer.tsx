import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { addLeadNote, getLead, updateLeadStatus } from "@/lib/leads.functions";

type Status = "new" | "contacted" | "qualified" | "won" | "lost";
const STATUSES: Status[] = ["new", "contacted", "qualified", "won", "lost"];

export function LeadDrawer({ leadId, onClose }: { leadId: string | null; onClose: () => void }) {
  const qc = useQueryClient();
  const [note, setNote] = useState("");
  const open = !!leadId;

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  const { data, isLoading, error } = useQuery({
    queryKey: ["lead", leadId],
    queryFn: () => getLead({ data: { leadId: leadId! } }),
    enabled: open,
  });

  const statusMut = useMutation({
    mutationFn: (status: Status) => updateLeadStatus({ data: { leadId: leadId!, status } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lead", leadId] });
      qc.invalidateQueries({ queryKey: ["leads"] });
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
    },
  });

  const noteMut = useMutation({
    mutationFn: (content: string) => addLeadNote({ data: { leadId: leadId!, note: content } }),
    onSuccess: () => {
      setNote("");
      qc.invalidateQueries({ queryKey: ["lead", leadId] });
    },
  });

  if (!open) return null;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, background: "rgba(14,27,61,0.45)", zIndex: 80,
        display: "flex", justifyContent: "flex-end",
      }}
    >
      <aside
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(560px, 100vw)", background: "#fff", height: "100vh",
          overflowY: "auto", boxShadow: "-12px 0 40px rgba(0,0,0,0.15)",
          display: "flex", flexDirection: "column",
        }}
      >
        <header style={{ padding: "22px 26px", borderBottom: "1px solid var(--ss-line)", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <div>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)" }}>Lead detail</div>
            <h2 style={{ margin: "4px 0 0", fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 28, color: "var(--ss-ink)" }}>
              {data?.lead.name || data?.lead.business || "Untitled lead"}
            </h2>
          </div>
          <button onClick={onClose} aria-label="Close" style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer", color: "var(--ss-ash)" }}>×</button>
        </header>

        <div style={{ padding: 26, flex: 1 }}>
          {isLoading && <p style={muted}>Loading…</p>}
          {error && <p style={{ color: "crimson" }}>{(error as Error).message}</p>}
          {data && (
            <>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 22 }}>
                {STATUSES.map((s) => (
                  <button
                    key={s}
                    onClick={() => statusMut.mutate(s)}
                    disabled={statusMut.isPending}
                    style={{
                      padding: "6px 12px", borderRadius: 999, fontSize: 12, fontWeight: 600,
                      textTransform: "uppercase", letterSpacing: "0.08em", cursor: "pointer",
                      border: "1px solid " + (data.lead.status === s ? "var(--ss-ink)" : "var(--ss-line)"),
                      background: data.lead.status === s ? "var(--ss-ink)" : "transparent",
                      color: data.lead.status === s ? "#fff" : "var(--ss-ink)",
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <dl style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: "10px 16px", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)", margin: 0 }}>
                <Field k="Type" v={data.lead.type} />
                <Field k="Name" v={data.lead.name} />
                <Field k="Email" v={data.lead.email} link={data.lead.email ? `mailto:${data.lead.email}` : undefined} />
                <Field k="Phone" v={data.lead.phone} link={data.lead.phone ? `tel:${data.lead.phone}` : undefined} />
                <Field k="Business" v={data.lead.business} />
                <Field k="Social URL" v={data.lead.social_url} link={data.lead.social_url ?? undefined} />
                <Field k="Source page" v={data.lead.source_page} />
                <Field k="Received" v={new Date(data.lead.created_at).toLocaleString()} />
              </dl>

              {data.lead.message && (
                <div style={{ marginTop: 22, padding: 16, background: "#FAF8F2", borderRadius: 12, fontSize: 14, lineHeight: 1.6, whiteSpace: "pre-wrap", color: "var(--ss-ink)" }}>
                  {data.lead.message}
                </div>
              )}

              <section style={{ marginTop: 30 }}>
                <h3 style={sectionH}>Add a note</h3>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={3}
                  placeholder="Internal note (not sent to the lead)…"
                  style={{ width: "100%", padding: 12, border: "1px solid var(--ss-line)", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 14, outline: "none", resize: "vertical" }}
                />
                <button
                  onClick={() => note.trim() && noteMut.mutate(note.trim())}
                  disabled={!note.trim() || noteMut.isPending}
                  style={{ marginTop: 8, padding: "8px 16px", background: "var(--ss-ink)", color: "#fff", border: "none", borderRadius: 10, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, cursor: "pointer", opacity: !note.trim() ? 0.4 : 1 }}
                >
                  {noteMut.isPending ? "Saving…" : "Save note"}
                </button>
              </section>

              <section style={{ marginTop: 30 }}>
                <h3 style={sectionH}>Activity</h3>
                {data.activity.length === 0 ? (
                  <p style={muted}>No activity yet.</p>
                ) : (
                  <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10 }}>
                    {data.activity.map((a) => (
                      <li key={a.id} style={{ padding: 12, background: "#FAF8F2", borderRadius: 10, fontSize: 13, color: "var(--ss-ink)" }}>
                        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ss-ash)", marginBottom: 4 }}>
                          {a.kind} · {new Date(a.created_at).toLocaleString()}
                        </div>
                        <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.5 }}>{a.content}</div>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </>
          )}
        </div>
      </aside>
    </div>
  );
}

const sectionH: React.CSSProperties = { margin: "0 0 12px", fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)" };
const muted: React.CSSProperties = { fontFamily: "var(--font-sans)", color: "var(--ss-ash)", fontSize: 14 };

function Field({ k, v, link }: { k: string; v?: string | null; link?: string }) {
  return (
    <>
      <dt style={{ color: "var(--ss-ash)", fontSize: 12 }}>{k}</dt>
      <dd style={{ margin: 0, wordBreak: "break-word" }}>
        {v ? (link ? <a href={link} target="_blank" rel="noreferrer" style={{ color: "var(--ss-ink)" }}>{v}</a> : v) : <span style={{ color: "var(--ss-ash)" }}>—</span>}
      </dd>
    </>
  );
}
