import { useState } from "react";
import { useHotkey } from "@/lib/admin/hooks";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const ROWS: Array<[string, string]> = [
  ["⌘ K", "Open command palette"],
  ["⌘ 1 – 9", "Jump to module"],
  ["⌘ /", "Search anywhere"],
  ["?", "Show shortcuts"],
  ["G then L", "Go to Leads"],
  ["G then I", "Go to Inbox"],
  ["E", "Edit focused row"],
  ["X", "Toggle row selection"],
  ["⇧ A", "Select all"],
  ["⌫", "Delete selected"],
  ["Esc", "Close drawer / clear selection"],
];

export function ShortcutHints() {
  const [open, setOpen] = useState(false);
  useHotkey("?", () => setOpen((v) => !v));
  useHotkey("shift+/", () => setOpen((v) => !v));
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 24 }}>Keyboard shortcuts</DialogTitle>
        </DialogHeader>
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", rowGap: 10, columnGap: 18, fontFamily: "var(--font-sans)", fontSize: 13 }}>
          {ROWS.map(([k, v]) => (
            <>
              <kbd key={k + "k"} style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 11, padding: "4px 8px", borderRadius: 6, background: "#0E1B3D0A", border: "1px solid var(--ss-line, #E6E2D6)", color: "var(--ss-ink)", whiteSpace: "nowrap" }}>{k}</kbd>
              <span key={k + "v"} style={{ color: "var(--ss-ink)" }}>{v}</span>
            </>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
