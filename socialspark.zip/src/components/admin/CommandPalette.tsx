import { useEffect, useMemo, useState } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command";
import { useHotkey } from "@/lib/admin/hooks";
import { supabase } from "@/integrations/supabase/client";
import { listLeads } from "@/lib/leads.functions";

type Cmd = {
  id: string;
  label: string;
  hint?: string;
  group: string;
  shortcut?: string;
  perform: () => void | Promise<void>;
};

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [leadHits, setLeadHits] = useState<Array<{ id: string; name: string | null; email: string | null; business: string | null }>>([]);
  const nav = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useHotkey("mod+k", () => setOpen((o) => !o));
  useHotkey("mod+/", () => setOpen(true));

  // ⌘1..9 quick-jump
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase();
      if (tag === "input" || tag === "textarea") return;
      if (!(e.metaKey || e.ctrlKey)) return;
      const map: Record<string, string> = {
        "1": "/admin",
        "2": "/admin/leads",
        "3": "/admin/inbox",
        "4": "/admin/board",
        "5": "/admin/media",
        "6": "/admin/seo",
        "7": "/admin/blog",
        "8": "/admin/automations",
        "9": "/admin/settings",
      };
      const to = map[e.key];
      if (to) {
        e.preventDefault();
        nav({ to });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [nav]);

  // Fuzzy lead search when typing
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(async () => {
      if (query.trim().length < 2) {
        setLeadHits([]);
        return;
      }
      try {
        const rows = await listLeads({ data: { search: query, limit: 8 } });
        setLeadHits(
          rows.map((r) => ({ id: r.id, name: r.name, email: r.email, business: r.business })),
        );
      } catch {
        setLeadHits([]);
      }
    }, 180);
    return () => clearTimeout(t);
  }, [query, open]);

  const cmds: Cmd[] = useMemo(
    () => [
      { id: "go-dash", label: "Go to Dashboard", group: "Navigate", shortcut: "⌘1", perform: () => nav({ to: "/admin" }) },
      { id: "go-leads", label: "Go to Leads", group: "Navigate", shortcut: "⌘2", perform: () => nav({ to: "/admin/leads" }) },
      { id: "go-inbox", label: "Go to Inbox", group: "Navigate", shortcut: "⌘3", perform: () => nav({ to: "/admin/inbox" }) },
      { id: "go-board", label: "Go to Pipeline", group: "Navigate", shortcut: "⌘4", perform: () => nav({ to: "/admin/board" }) },
      { id: "go-media", label: "Go to Media Library", group: "Navigate", shortcut: "⌘5", perform: () => nav({ to: "/admin/media" }) },
      { id: "go-seo", label: "Go to SEO Console", group: "Navigate", shortcut: "⌘6", perform: () => nav({ to: "/admin/seo" }) },
      { id: "go-blog", label: "Go to Blog", group: "Navigate", shortcut: "⌘7", perform: () => nav({ to: "/admin/blog" }) },
      { id: "go-auto", label: "Go to Automations", group: "Navigate", shortcut: "⌘8", perform: () => nav({ to: "/admin/automations" }) },
      { id: "go-set", label: "Go to Site Settings", group: "Navigate", shortcut: "⌘9", perform: () => nav({ to: "/admin/settings" }) },
      { id: "go-email", label: "Email Provider", group: "Navigate", perform: () => nav({ to: "/admin/email" }) },
      { id: "go-site", label: "Open Public Site", group: "Navigate", perform: () => { window.open("/", "_blank"); } },
      { id: "copy-path", label: `Copy current path: ${pathname}`, group: "Utilities", perform: () => navigator.clipboard.writeText(pathname) },
      { id: "reload", label: "Hard reload", group: "Utilities", shortcut: "⇧R", perform: () => window.location.reload() },
      { id: "signout", label: "Sign out", group: "Account", perform: async () => { await supabase.auth.signOut(); nav({ to: "/auth", replace: true }); } },
    ],
    [nav, pathname],
  );

  function run(c: Cmd) {
    setOpen(false);
    setQuery("");
    void c.perform();
  }

  const grouped = cmds.reduce<Record<string, Cmd[]>>((acc, c) => {
    (acc[c.group] ??= []).push(c);
    return acc;
  }, {});

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput value={query} onValueChange={setQuery} placeholder="Search commands, leads, pages…" />
      <CommandList>
        <CommandEmpty>No results.</CommandEmpty>

        {leadHits.length > 0 && (
          <>
            <CommandGroup heading="Leads">
              {leadHits.map((l) => (
                <CommandItem
                  key={l.id}
                  value={`lead-${l.id}-${l.name ?? ""}-${l.email ?? ""}`}
                  onSelect={() => {
                    setOpen(false);
                    nav({ to: "/admin/leads", search: { open: l.id } as never });
                  }}
                >
                  <div style={{ display: "flex", flexDirection: "column" }}>
                    <span style={{ fontWeight: 600 }}>{l.name || l.email || l.business || "Untitled lead"}</span>
                    <span style={{ fontSize: 12, color: "var(--ss-ash, #888)" }}>{l.email ?? ""} {l.business ? `· ${l.business}` : ""}</span>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {Object.entries(grouped).map(([group, items], i) => (
          <div key={group}>
            {i > 0 && <CommandSeparator />}
            <CommandGroup heading={group}>
              {items.map((c) => (
                <CommandItem key={c.id} value={`${c.group}-${c.label}`} onSelect={() => run(c)}>
                  <span>{c.label}</span>
                  {c.shortcut && <CommandShortcut>{c.shortcut}</CommandShortcut>}
                </CommandItem>
              ))}
            </CommandGroup>
          </div>
        ))}
      </CommandList>
    </CommandDialog>
  );
}
