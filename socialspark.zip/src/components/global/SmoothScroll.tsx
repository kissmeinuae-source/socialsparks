import { useEffect } from "react";
import Lenis from "lenis";

/**
 * SmoothScroll — Lenis-powered momentum scroll.
 * Disabled on admin/auth, on reduced-motion preference, and on touch-primary devices
 * (mobile in-app browsers handle momentum natively and Lenis can fight them).
 */
export function SmoothScroll() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    const path = window.location.pathname;
    if (path.startsWith("/admin") || path.startsWith("/auth")) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    if (window.matchMedia?.("(hover: none) and (pointer: coarse)").matches) return;

    const lenis = new Lenis({
      duration: 1.05,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });

    let rafId = 0;
    const raf = (time: number) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };
    rafId = requestAnimationFrame(raf);

    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);

  return null;
}
