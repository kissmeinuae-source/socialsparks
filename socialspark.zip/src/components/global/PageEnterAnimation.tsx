import { useEffect, useRef, useState } from "react";

/**
 * Editorial enter sequence — cream curtain rises, navy serif wordmark settles in,
 * yellow dot lands, full overlay clears. Plays once per session.
 */
export function PageEnterAnimation() {
  const [show, setShow] = useState(false);
  const overlayRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    if (sessionStorage.getItem("ss-entered") === "1") return;
    setShow(true);
    const t = setTimeout(() => {
      sessionStorage.setItem("ss-entered", "1");
      setShow(false);
    }, 1500);
    return () => clearTimeout(t);
  }, []);

  if (!show) return null;

  return (
    <div
      ref={overlayRef}
      aria-hidden
      className="fixed inset-0 z-[200] flex items-center justify-center"
      style={{
        background: "var(--ss-cream)",
        animation: "ss-enter-clear 400ms ease-out 1100ms forwards",
        pointerEvents: "none",
      }}
    >
      <div className="flex flex-col items-center" style={{ animation: "ss-enter-rise 600ms cubic-bezier(0.22,1,0.36,1)" }}>
        <span
          className="display-italic"
          style={{
            fontStyle: "italic",
            fontFamily: "var(--font-display)",
            fontSize: "clamp(2.5rem, 5vw, 4.5rem)",
            color: "var(--ss-ink)",
            letterSpacing: "-0.03em",
            lineHeight: 1,
          }}
        >
          Social Spark
        </span>
        <span
          style={{
            display: "block",
            width: 0,
            height: 2,
            background: "var(--ss-gold)",
            marginTop: 12,
            animation: "ss-enter-line 500ms cubic-bezier(0.22,1,0.36,1) 350ms forwards",
          }}
        />
      </div>
      <style>{`
        @keyframes ss-enter-rise {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes ss-enter-line {
          from { width: 0; }
          to   { width: 96px; }
        }
        @keyframes ss-enter-clear {
          to { opacity: 0; }
        }
      `}</style>
    </div>
  );
}
