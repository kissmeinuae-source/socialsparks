import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useLanguage } from "@/lib/language";

const links: { label: { en: string; ur: string }; to: string }[] = [
  { label: { en: "Services", ur: "خدمات" }, to: "/#services" },
  { label: { en: "Results",  ur: "نتائج" }, to: "/results" },
  { label: { en: "Pricing",  ur: "قیمتیں" }, to: "/pricing" },
  { label: { en: "About",    ur: "ہمارے بارے میں" }, to: "/about" },
  { label: { en: "Blog",     ur: "بلاگ" }, to: "/blog" },
  { label: { en: "Contact",  ur: "رابطہ" }, to: "/contact" },
];

export function MobileMenu() {
  const { lang, t } = useLanguage();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <button
        type="button"
        aria-label={open ? "Close menu" : "Open menu"}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className=""
        style={{
          width: 44, height: 44,
          borderRadius: 9999,
          border: "1px solid var(--ss-line)",
          background: "#fff",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          color: "var(--ss-ink)",
        }}
      >
        {open ? <X size={18} /> : <Menu size={18} />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[70] md:hidden"
            style={{ background: "var(--ss-cream)", paddingTop: "var(--nav-offset)" }}
          >
            <nav
              aria-label="Mobile"
              className="px-6 pb-10"
              style={{ height: "100%", overflowY: "auto" }}
            >
              <ul className="flex flex-col" style={{ borderTop: "1px solid var(--ss-line)" }}>
                {links.map((l, i) => (
                  <motion.li
                    key={l.to + i}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.35, delay: 0.05 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                    style={{ borderBottom: "1px solid var(--ss-line)" }}
                  >
                    <Link
                      to={l.to}
                      onClick={() => setOpen(false)}
                      className={lang === "ur" ? "urdu" : "display-italic"}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "22px 4px",
                        fontStyle: lang === "en" ? "italic" : "normal",
                        fontFamily: "var(--font-display)",
                        fontSize: 36,
                        lineHeight: 1,
                        color: "var(--ss-ink)",
                        letterSpacing: "-0.02em",
                      }}
                    >
                      <span>{lang === "en" ? l.label.en : l.label.ur}</span>
                      <span aria-hidden style={{ color: "var(--ss-gold-dim)", fontSize: 20 }}>→</span>
                    </Link>
                  </motion.li>
                ))}
              </ul>

              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: 0.45 }}
                className="mt-8 flex flex-col gap-3"
              >
                <Link to="/book" className="btn-yellow" onClick={() => setOpen(false)}>
                  {t("Start a Project", "پروجیکٹ شروع کریں")} <span aria-hidden>→</span>
                </Link>
                <Link to="/contact" className="btn-ghost" onClick={() => setOpen(false)}>
                  {t("Contact", "رابطہ")}
                </Link>
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
