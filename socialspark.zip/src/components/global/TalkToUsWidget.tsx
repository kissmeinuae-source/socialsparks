import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useLanguage } from "@/lib/language";
import { submitLead } from "@/lib/leads.functions";

export function TalkToUsWidget() {
  const { t } = useLanguage();
  const submit = useServerFn(submitLead);
  const [open, setOpen] = useState(false);
  const [opened, setOpened] = useState(false); // stops pulse after first open
  const [mode, setMode] = useState<"choice" | "chat" | "sent">("choice");
  const [sending, setSending] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (localStorage.getItem("ss-talk-opened") === "1") setOpened(true);
  }, []);

  useEffect(() => {
    if (open) {
      setOpened(true);
      try { localStorage.setItem("ss-talk-opened", "1"); } catch {}
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    const onClick = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    setTimeout(() => window.addEventListener("mousedown", onClick), 100);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("mousedown", onClick);
    };
  }, [open]);

  return (
    <div
      ref={panelRef}
      className="fixed left-1/2 -translate-x-1/2 z-[80]"
      style={{ bottom: 28 }}
    >
      {/* Panel */}
      {open && (
        <div
          role="dialog"
          aria-label="Talk to us"
          className="tile tile-elevated mb-3"
          style={{
            width: 340,
            padding: 18,
            background: "#fff",
            border: "1px solid var(--ss-line)",
            animation: "ss-tile-in 360ms cubic-bezier(0.22,1,0.36,1) both",
          }}
        >
          {mode === "choice" ? (
            <>
              <p className="t-eyebrow" style={{ marginBottom: 12 }}>
                {t("Reach us", "ہم سے رابطہ")}
              </p>
              <h3
                className="display-italic"
                style={{ fontStyle: "italic", fontSize: 22, lineHeight: 1.05, marginBottom: 14, color: "var(--ss-ink)" }}
              >
                {t("How should we talk?", "ہم کیسے بات کریں؟")}
              </h3>
              <div className="grid gap-2">
                <a
                  href="https://wa.me/923000000000"
                  target="_blank"
                  rel="noreferrer"
                  className="tile"
                  style={{
                    padding: "14px 16px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    background: "var(--ss-cream)",
                  }}
                >
                  <span style={{ fontWeight: 500, color: "var(--ss-ink)" }}>WhatsApp</span>
                  <span aria-hidden style={{ color: "var(--ss-gold-dim)" }}>→</span>
                </a>
                <button
                  onClick={() => setMode("chat")}
                  className="tile"
                  style={{
                    padding: "14px 16px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    background: "var(--ss-ink)",
                    color: "#fff",
                    cursor: "pointer",
                  }}
                >
                  <span style={{ fontWeight: 500 }}>{t("Quick chat", "فوری چیٹ")}</span>
                  <span aria-hidden style={{ color: "var(--ss-gold)" }}>→</span>
                </button>
              </div>
            </>
          ) : mode === "sent" ? (
            <div className="text-center py-6">
              <div aria-hidden style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--ss-gold)", color: "var(--ss-ink)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 22, margin: "0 auto 14px" }}>✓</div>
              <p style={{ fontSize: 14, color: "var(--ss-ink)", margin: 0 }}>
                {t("Got it — we'll reply within 2 hours.", "موصول — ہم 2 گھنٹوں میں جواب دیں گے۔")}
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-3">
                <button
                  onClick={() => setMode("choice")}
                  style={{ fontSize: 12, color: "var(--ss-ash)", cursor: "pointer" }}
                  aria-label="Back"
                >
                  ← {t("Back", "واپس")}
                </button>
                <span className="t-eyebrow">{t("Live", "لائیو")}</span>
              </div>
              <div
                style={{
                  background: "var(--ss-cream)",
                  borderRadius: 14,
                  padding: 14,
                  marginBottom: 10,
                  fontSize: 14,
                  color: "var(--ss-ink)",
                  lineHeight: 1.55,
                }}
              >
                {t(
                  "Hey 👋 — drop your contact + a note. We reply within 2 hours.",
                  "ہمیں اپنا رابطہ اور پیغام بھیجیں۔",
                )}
              </div>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const fd = new FormData(e.currentTarget);
                  const contact = String(fd.get("contact") ?? "").trim();
                  const note = String(fd.get("note") ?? "").trim();
                  if (!contact || !note) {
                    setChatError(t("Both fields are required.", "دونوں خانے ضروری ہیں۔"));
                    return;
                  }
                  const isEmail = contact.includes("@");
                  setChatError(null);
                  setSending(true);
                  try {
                    await submit({
                      data: {
                        type: "chat",
                        email: isEmail ? contact : null,
                        phone: isEmail ? null : contact,
                        message: note,
                        source_page: typeof window !== "undefined" ? window.location.pathname : null,
                      },
                    });
                    setMode("sent");
                  } catch (err) {
                    setChatError(err instanceof Error ? err.message : "Failed to send.");
                  } finally {
                    setSending(false);
                  }
                }}
                className="flex flex-col gap-2"
              >
                <input
                  name="contact"
                  type="text"
                  required
                  placeholder={t("Email or WhatsApp", "ای میل یا واٹس ایپ")}
                  style={{ border: "1px solid var(--ss-line)", borderRadius: 9999, padding: "10px 14px", fontSize: 14, outline: "none" }}
                />
                <div className="flex gap-2">
                  <input
                    name="note"
                    type="text"
                    required
                    placeholder={t("Your message…", "آپ کا پیغام")}
                    className="flex-1"
                    style={{ border: "1px solid var(--ss-line)", borderRadius: 9999, padding: "10px 14px", fontSize: 14, outline: "none" }}
                  />
                  <button type="submit" disabled={sending} className="btn-primary" style={{ padding: "10px 16px", opacity: sending ? 0.6 : 1 }}>
                    {sending ? "…" : "↑"}
                  </button>
                </div>
                {chatError && <p style={{ color: "var(--ss-gold-dim)", fontSize: 12, margin: 0 }}>{chatError}</p>}
              </form>
            </>
          )}
        </div>
      )}

      {/* Trigger pill */}
      <button
        type="button"
        aria-label={t("Talk to us", "ہم سے بات کریں")}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="btn-primary shadow-tile"
        style={{
          background: "var(--ss-ink)",
          color: "#fff",
          padding: "12px 22px",
          fontSize: 14,
          gap: 12,
        }}
      >
        <span
          aria-hidden
          style={{
            width: 22, height: 22, borderRadius: 9999,
            background: "var(--ss-gold)",
            color: "var(--ss-ink)",
            display: "inline-flex",
            alignItems: "center", justifyContent: "center",
            fontWeight: 700, fontSize: 13,
          }}
        >
          ⚡
        </span>
        <span style={{ fontWeight: 500 }}>{t("Talk to Us", "بات کریں")}</span>
        {!opened && (
          <span
            aria-hidden
            style={{
              width: 8, height: 8, borderRadius: 9999,
              background: "var(--ss-gold)",
              animation: "ss-pulse 1.6s ease-in-out infinite",
            }}
          />
        )}
      </button>
      <style>{`
        @keyframes ss-pulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.4); opacity: 0.55; }
        }
        @media (prefers-reduced-motion: reduce) {
          [aria-label="Talk to us"] span { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
