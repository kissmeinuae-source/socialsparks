import { useLanguage } from "../../lib/language";

/**
 * Slim top utility bar above NavBar. Cream canvas, navy text,
 * tiny EN / UR pill toggle on the right. 36px tall.
 */
export function TopLanguageBar() {
  const { lang, setLang } = useLanguage();

  return (
    <div
      role="region"
      aria-label="Site locale and tagline"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 101,
        height: 36,
        background: "var(--ss-gold)",
        borderBottom: "1px solid rgba(10,10,10,0.12)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 clamp(16px, 5vw, 40px)",
        fontFamily: "var(--font-sans)",
        fontWeight: 600,
        fontSize: 11,
        letterSpacing: "0.14em",
        textTransform: "uppercase",
        color: "var(--ss-ink)",
      }}
    >
      <span style={{ fontWeight: 900 }}>
        {lang === "ur" ? (
          <span className="urdu" style={{ fontSize: 14, letterSpacing: "normal" }}>
            لاہور سے دنیا تک
          </span>
        ) : (
          <>Lahore <span style={{ opacity: 0.5, margin: "0 6px" }}>◆</span> Digital Studio Est. 2022</>
        )}
      </span>

      <div
        role="group"
        aria-label="Language"
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 0,
          padding: 0,
          border: "2px solid var(--ss-ink)",
          borderRadius: 0,
          background: "var(--ss-cream)",
        }}
      >
        {(["en", "ur"] as const).map((code) => {
          const active = lang === code;
          return (
            <button
              key={code}
              type="button"
              onClick={() => setLang(code)}
              aria-pressed={active}
              aria-label={code === "en" ? "Switch to English" : "اردو پر سوئچ کریں"}
              style={{
              border: 0,
              cursor: "pointer",
              padding: "5px 12px",
              borderRadius: 0,
              fontFamily: "var(--font-display)",
              fontWeight: 900,
              fontSize: 10,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              background: active ? "var(--ss-ink)" : "transparent",
              color: active ? "var(--ss-gold)" : "var(--ss-ink)",
              transition: "background 180ms ease, color 180ms ease",
              lineHeight: 1,
            }}
            >
              {code === "en" ? "EN" : "UR"}
            </button>
          );
        })}
      </div>
    </div>
  );
}
