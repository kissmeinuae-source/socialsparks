import { Link } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { Logo } from "@/components/global/Logo";
import { useLanguage } from "@/lib/language";
import { useSiteSettings, pickSetting, str } from "@/lib/site-settings";

export function Footer() {
  const { t } = useLanguage();
  const { data: settings } = useSiteSettings();
  const brand = pickSetting(settings, "brand");
  const contact = pickSetting(settings, "contact");
  const social = pickSetting(settings, "social");
  const flagRef = useRef<HTMLSpanElement | null>(null);


  // wave the flag once when footer enters viewport
  useEffect(() => {
    const el = flagRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            el.classList.remove("ss-flag-wave");
            void el.offsetWidth;
            el.classList.add("ss-flag-wave");
            obs.disconnect();
          }
        }
      },
      { threshold: 0.4 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const cols: { heading: string; links: { label: string; to: string }[] }[] = [
    {
      heading: t("Services", "خدمات"),
      links: [
        { label: t("Social Management", "سوشل منیجمنٹ"), to: "/#services" },
        { label: t("Performance Ads", "اشتہارات"), to: "/#services" },
        { label: t("Brand Identity", "برانڈ شناخت"), to: "/#services" },
        { label: t("Website Design", "ویب ڈیزائن"), to: "/#services" },
      ],
    },
    {
      heading: t("Company", "کمپنی"),
      links: [
        { label: t("About", "ہمارے بارے میں"), to: "/about" },
        { label: t("Results", "نتائج"), to: "/results" },
        { label: t("Pricing", "قیمتیں"), to: "/pricing" },
        { label: t("Blog", "بلاگ"), to: "/blog" },
      ],
    },
    {
      heading: t("Legal", "قانونی"),
      links: [
        { label: t("Privacy", "پرائیویسی"), to: "/privacy-policy" },
        { label: t("Cookies", "کوکیز"), to: "/cookie-policy" },
        { label: t("Terms", "شرائط"), to: "/terms-of-service" },
        { label: t("Refunds", "رقم کی واپسی"), to: "/refund-policy" },
      ],
    },
  ];

  return (
    <footer
      className="bg-cream"
      style={{
        borderTop: "1px solid var(--ss-line)",
        paddingBlock: "72px 32px",
      }}
    >
      <div className="mx-auto max-w-[1280px] px-6 md:px-10">
        {/* Editorial sign-off tile */}
        <div
          className="tile tile-elevated mb-14"
          style={{
            padding: "clamp(40px, 6vw, 72px)",
            background: "var(--ss-ink)",
            color: "#fff",
            border: "1px solid var(--ss-ink)",
          }}
        >
          <p
            style={{
              fontFamily: "var(--font-sans)",
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "var(--ss-gold)",
              marginBottom: 22,
            }}
          >
            {t("Ready when you are", "جب آپ تیار ہوں")}
          </p>
          <h2
            className="display-italic"
            style={{
              fontStyle: "italic",
              fontSize: "clamp(2.25rem, 1.6rem + 3.5vw, 4.5rem)",
              lineHeight: 0.95,
              color: "#fff",
              letterSpacing: "-0.03em",
              maxWidth: 880,
            }}
          >
            {t(
              "Let's make your brand impossible to ignore.",
              "آئیے آپ کے برانڈ کو نظرانداز کرنا ناممکن بنائیں۔",
            )}
          </h2>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/book" className="btn-yellow">
              {t("Book a Free Call", "مفت کال بک کریں")} <span aria-hidden>→</span>
            </Link>
            <Link
              to="/results"
              className="btn-ghost"
              style={{ borderColor: "rgba(255,255,255,0.4)", color: "#fff" }}
            >
              {t("See our work", "ہمارا کام دیکھیں")}
            </Link>
          </div>
        </div>

        {/* Footer grid */}
        <div className="grid gap-10 md:grid-cols-[2fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p
              style={{
                marginTop: 18,
                maxWidth: 320,
                color: "var(--ss-slate)",
                fontSize: 14,
                lineHeight: 1.6,
              }}
            >
              {t(
                str(brand, "tagline_en", "A Lahore digital studio building lasting brands for SMBs and Pakistan's most recognisable personalities."),
                str(brand, "tagline_ur", "لاہور سے ایک ڈیجیٹل اسٹوڈیو۔"),
              )}
            </p>
            {(str(contact, "email") || str(contact, "whatsapp") || str(social, "instagram") || str(social, "linkedin")) && (
              <div style={{ marginTop: 16, display: "flex", flexWrap: "wrap", gap: 14, fontSize: 13, color: "var(--ss-ash)" }}>
                {str(contact, "email") && <a href={`mailto:${str(contact, "email")}`} style={{ color: "var(--ss-ink)" }}>{str(contact, "email")}</a>}
                {str(contact, "whatsapp") && <a href={`https://wa.me/${str(contact, "whatsapp").replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer" style={{ color: "var(--ss-ink)" }}>WhatsApp</a>}
                {str(social, "instagram") && <a href={str(social, "instagram")} target="_blank" rel="noreferrer" style={{ color: "var(--ss-ink)" }}>Instagram</a>}
                {str(social, "linkedin") && <a href={str(social, "linkedin")} target="_blank" rel="noreferrer" style={{ color: "var(--ss-ink)" }}>LinkedIn</a>}
              </div>
            )}
          </div>

          {cols.map((col) => (
            <div key={col.heading}>
              <h4
                style={{
                  fontFamily: "var(--font-sans)",
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: "0.2em",
                  textTransform: "uppercase",
                  color: "var(--ss-ash)",
                  marginBottom: 18,
                }}
              >
                {col.heading}
              </h4>
              <ul className="flex flex-col gap-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      to={l.to}
                      style={{
                        fontFamily: "var(--font-sans)",
                        fontSize: 14,
                        color: "var(--ss-ink)",
                        transition: "color 200ms ease",
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.color = "var(--ss-gold-dim)")}
                      onMouseLeave={(e) => (e.currentTarget.style.color = "var(--ss-ink)")}
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div
          className="mt-14 pt-6 flex flex-col md:flex-row justify-between gap-3"
          style={{ borderTop: "1px solid var(--ss-line)" }}
        >
          <p style={{ fontSize: 12.5, color: "var(--ss-ash)" }}>
            © {new Date().getFullYear()} Social Spark. Lahore,{" "}
            <span ref={flagRef} aria-hidden style={{ display: "inline-block" }}>
              🇵🇰
            </span>{" "}
            Pakistan.
          </p>
          <p style={{ fontSize: 12.5, color: "var(--ss-ash)" }}>
            {t("Crafted in Gulberg.", "گلبرگ میں تیار کردہ۔")}
          </p>
        </div>
      </div>
    </footer>
  );
}
