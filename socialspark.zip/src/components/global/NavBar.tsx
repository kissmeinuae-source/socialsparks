import { useCallback } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { NAV_LINKS } from "./nav-links";
import { useScrollY } from "../../hooks/use-scroll-y";
import { useActiveSection } from "../../hooks/use-active-section";
import { useLanguage } from "../../lib/language";
import { MobileMenu } from "./MobileMenu";

/**
 * Editorial light nav. Paper background with hairline border; subtle blur on scroll.
 * Ink logo + ink links; a single dark pill CTA.
 */
export function NavBar() {
  const scrollY = useScrollY();
  const scrolled = scrollY > 60;
  const active = useActiveSection(NAV_LINKS.map((l) => l.id));
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { t } = useLanguage();

  const goToSection = useCallback(
    (id: string) => {
      if (pathname === "/") {
        const el = document.getElementById(id);
        if (el) {
          el.scrollIntoView({ behavior: "smooth", block: "start" });
          return;
        }
      }
      navigate({ to: "/", hash: id });
    },
    [pathname, navigate],
  );

  return (
    <header
      style={{
        position: "fixed",
        top: 36,
        left: 0,
        right: 0,
        zIndex: 100,
        height: 68,
        background: scrolled ? "rgba(247,245,240,0.82)" : "var(--ss-paper)",
        backdropFilter: scrolled ? "blur(18px) saturate(160%)" : "none",
        borderBottom: scrolled
          ? "1px solid rgba(10,10,10,0.08)"
          : "1px solid transparent",
        boxShadow: scrolled ? "0 1px 0 rgba(10,10,10,0.04)" : "none",
        transition: "background 240ms ease, border-color 240ms ease, box-shadow 240ms ease",
        padding: "0 clamp(20px, 5vw, 48px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <Logo size={20} tone="navy" />

      <nav
        role="navigation"
        aria-label="Primary"
        className="ss-nav-links"
        style={{ display: "flex", alignItems: "center", gap: 32 }}
      >
        {NAV_LINKS.map((link) => {
          const isActive = active === link.id;
          return (
            <button
              key={link.id}
              type="button"
              onClick={() => goToSection(link.id)}
              style={{
                position: "relative",
                background: "transparent",
                border: 0,
                padding: "8px 0",
                cursor: "pointer",
                fontFamily: "var(--font-sans)",
                fontWeight: 500,
                fontSize: 14,
                color: isActive ? "var(--ss-ink)" : "rgba(10,10,10,0.62)",
                transition: "color 180ms ease",
                lineHeight: 1,
              }}
              onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.color = "var(--ss-ink)"; }}
              onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.color = "rgba(10,10,10,0.62)"; }}
            >
              {t(link.label, link.labelUr)}
              <span
                aria-hidden
                style={{
                  position: "absolute",
                  left: 0, right: 0, bottom: -2,
                  height: 2,
                  background: "var(--ss-gold)",
                  transform: isActive ? "scaleX(1)" : "scaleX(0)",
                  transformOrigin: "left",
                  transition: "transform 240ms cubic-bezier(0.22,1,0.36,1)",
                  borderRadius: 2,
                }}
              />
            </button>
          );
        })}
      </nav>

      <button
        type="button"
        onClick={() => goToSection("book")}
        className="ss-nav-cta btn-primary"
        style={{ padding: "10px 18px", fontSize: 13 }}
      >
        {t("Start Project", "پروجیکٹ شروع کریں")}
        <span aria-hidden style={{ fontSize: 14 }}>→</span>
      </button>

      <div className="ss-hamburger" style={{ display: "none" }}>
        <MobileMenu />
      </div>

      <style>{`
        @media (max-width: 959px) {
          .ss-nav-links { display: none !important; }
          .ss-nav-cta { display: none !important; }
          .ss-hamburger { display: flex !important; }
        }
      `}</style>
    </header>
  );
}
