import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

interface Step {
  num: string;
  title: [string, string];
  desc: [string, string];
  tile: "white" | "navy" | "yellow" | "cream";
}

const STEPS: Step[] = [
  {
    num: "01",
    tile: "white",
    title: ["Free strategy call", "مفت حکمت عملی کال"],
    desc: [
      "A 30-minute call to understand your business, your audience and your real competitors. No deck, no upsell — just a working conversation in Urdu or English.",
      "30 منٹ کی کال — آپ کا کاروبار، سامعین اور اصل حریف سمجھنے کے لیے۔ نہ کوئی پیشکش، نہ دباؤ — صرف کام کی بات۔",
    ],
  },
  {
    num: "02",
    tile: "navy",
    title: ["Custom plan, in 48 hours", "آپ کا منصوبہ، 48 گھنٹے میں"],
    desc: [
      "A written strategy in plain language — platforms, content pillars, ad structure, monthly KPIs and the team you'll be working with. Yours to keep, even if we never work together.",
      "سادہ زبان میں تحریری حکمت عملی — پلیٹ فارمز، کنٹینٹ کے ستون، اشتہاری ڈھانچہ، ماہانہ KPIs اور آپ کی ٹیم۔ آپ کی، چاہے ہم کام کریں یا نہ کریں۔",
    ],
  },
  {
    num: "03",
    tile: "yellow",
    title: ["We go live in 7 days", "ہفتے میں لائیو"],
    desc: [
      "Onboarding, brand voice, content calendar, ad accounts and tracking — all wired up by our in-house team. You approve once, then we ship daily.",
      "آن بورڈنگ، برانڈ وائس، کنٹینٹ کیلنڈر، ایڈ اکاؤنٹس اور ٹریکنگ — ہماری اِن ہاؤس ٹیم سب کچھ سنبھالتی ہے۔ آپ ایک بار منظوری دیں، پھر روزانہ ڈلیوری۔",
    ],
  },
  {
    num: "04",
    tile: "cream",
    title: ["Measure, refine, compound", "ناپیں، بہتر بنائیں، بڑھائیں"],
    desc: [
      "Weekly check-ins, monthly reports written for owners — not marketing managers. Every rupee of ad spend, every reel, every lead traced to a number that matters.",
      "ہفتہ وار جائزے، مالک کے لیے لکھی گئی ماہانہ رپورٹس۔ ہر روپیہ، ہر ریل، ہر لیڈ — ایک ایسے نمبر سے جڑا جو واقعی اہم ہے۔",
    ],
  },
];

function tileClass(t: Step["tile"]) {
  if (t === "navy") return "tile tile-navy";
  if (t === "yellow") return "tile tile-yellow";
  if (t === "cream") return "tile tile-cream";
  return "tile";
}

export function Process() {
  const { t } = useLanguage();
  return (
    <section id="how" style={{ backgroundColor: "var(--ss-paper)", padding: "112px 24px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <FadeSlide>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <span aria-hidden style={{ width: 28, height: 1, backgroundColor: "var(--ss-ink)", opacity: 0.4 }} />
            <span className="t-eyebrow">{t("The process", "ہمارا طریقہ کار")}</span>
          </div>
        </FadeSlide>
        <FadeSlide delay={80}>
          <h2 style={{ margin: 0, maxWidth: 880 }}>
            {t("From ", "گفتگو سے ")}
            <span style={{ fontStyle: "italic" }}>{t("conversation", "مہم")}</span>
            {t(" to campaign", " تک")}
            <br />
            {t("in four ", "صرف چار ")}
            <span style={{ fontStyle: "italic" }}>{t("considered", "سوچے سمجھے")}</span>
            {t(" moves.", " مراحل میں۔")}
          </h2>
        </FadeSlide>

        <div className="ss-process-bento">
          {STEPS.map((s, i) => {
            const isNavy = s.tile === "navy";
            const isYellow = s.tile === "yellow";
            const numColor = isNavy ? "var(--ss-gold)" : "var(--ss-ink)";
            const textColor = isNavy ? "rgba(245,243,238,0.78)" : "var(--ss-slate)";
            const titleColor = isNavy ? "var(--ss-cream)" : "var(--ss-ink)";
            const eyebrowColor = isNavy ? "rgba(245,243,238,0.55)" : isYellow ? "rgba(14,27,61,0.6)" : "var(--ss-ash)";
            return (
              <FadeSlide key={s.num} delay={160 + i * 100}>
                <div className={tileClass(s.tile)} style={{ padding: 36, height: "100%", display: "flex", flexDirection: "column", gap: 24, minHeight: 280 }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                    <span style={{ fontFamily: "var(--font-sans)", fontWeight: 600, fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: eyebrowColor }}>
                      {t(`Step ${s.num}`, `مرحلہ ${s.num}`)}
                    </span>
                    <span aria-hidden style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: 48, lineHeight: 1, color: numColor, opacity: isYellow ? 0.85 : 1 }}>
                      {s.num}
                    </span>
                  </div>
                  <div style={{ marginTop: "auto" }}>
                    <h3 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 2.4vw, 2rem)", lineHeight: 1.05, margin: "0 0 12px", color: titleColor, fontStyle: "italic" }}>
                      {t(s.title[0], s.title[1])}
                    </h3>
                    <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: 14.5, lineHeight: 1.65, color: textColor }}>
                      {t(s.desc[0], s.desc[1])}
                    </p>
                  </div>
                </div>
              </FadeSlide>
            );
          })}
        </div>

        {/* After-process CTA bar */}
        <FadeSlide delay={560}>
          <div
            className="ss-process-cta"
            style={{
              marginTop: 56,
              padding: "28px 32px",
              border: "1px solid var(--ss-rule)",
              borderRadius: 18,
              background: "var(--ss-cream)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 24,
              flexWrap: "wrap",
            }}
          >
            <div>
              <div className="t-eyebrow" style={{ marginBottom: 8 }}>
                {t("What it costs you to start", "شروع کرنے کی قیمت")}
              </div>
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontStyle: "italic",
                  fontSize: "clamp(1.5rem, 2.4vw, 2rem)",
                  color: "var(--ss-ink)",
                  lineHeight: 1.15,
                }}
              >
                {t("Thirty minutes. No card. No commitment.", "تیس منٹ۔ نہ کارڈ، نہ پابندی۔")}
              </div>
            </div>
            <a href="#book" className="btn-primary">
              {t("Book the strategy call", "حکمت عملی کال بک کریں")}
              <span aria-hidden style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: 18 }}>→</span>
            </a>
          </div>
        </FadeSlide>
      </div>

      <style>{`
        .ss-process-bento {
          margin-top: 64px;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
        }
        @media (max-width: 1040px) {
          .ss-process-bento { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 560px) {
          .ss-process-bento { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  );
}
