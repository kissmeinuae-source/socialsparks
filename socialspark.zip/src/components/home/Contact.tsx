import { useEffect, useState, type FormEvent } from "react";
import { z } from "zod";
import { Mail, MessageCircle, MapPin } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";
import { submitLead } from "@/lib/leads.functions";
import { useSiteSettings, pickSetting, str } from "@/lib/site-settings";
import { HONEYPOT_FIELD, honeypotInputProps, honeypotStyle } from "@/lib/honeypot";


const schema = z.object({
  name: z.string().trim().min(2).max(80),
  contact: z.string().trim().min(3).max(160),
  message: z.string().trim().min(4).max(1000),
});

export function Contact() {
  const { t } = useLanguage();
  const submit = useServerFn(submitLead);
  const { data: settings } = useSiteSettings();
  const contact = pickSetting(settings, "contact");
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);


  const inputStyle: React.CSSProperties = {
    background: "white",
    border: "1px solid var(--ss-rule)",
    borderRadius: 8,
    padding: "12px 16px",
    color: "var(--ss-ink)",
    fontFamily: "var(--font-sans)",
    fontSize: 14,
    width: "100%",
    outline: "none",
  };

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const parsed = schema.safeParse(Object.fromEntries(fd.entries()));
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Please complete all fields.");
      return;
    }
    const isEmail = parsed.data.contact.includes("@");
    setError(null);
    setSubmitting(true);
    try {
      await submit({
        data: {
          type: "contact",
          name: parsed.data.name,
          email: isEmail ? parsed.data.contact : null,
          phone: isEmail ? null : parsed.data.contact,
          message: parsed.data.message,
          source_page: typeof window !== "undefined" ? window.location.pathname : null,
          website_url: (fd.get(HONEYPOT_FIELD) as string | null) ?? null,
        },
      });
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  const rows = [
    { Icon: Mail, label: t("EMAIL", "ای میل"), value: mounted ? str(contact, "email", "hello@socialspark.pk") : "hello@socialspark.pk" },
    { Icon: MessageCircle, label: t("WHATSAPP", "واٹس ایپ"), value: mounted ? str(contact, "whatsapp", "+92 300 0000000") : "+92 300 0000000" },
    { Icon: MapPin, label: t("LOCATION", "مقام"), value: mounted ? str(contact, "address", "Lahore, Pakistan") : "Lahore, Pakistan" },
  ];


  return (
    <section
      id="contact"
      style={{ background: "var(--ss-paper)", padding: "112px 48px" }}
    >
      <div className="mx-auto grid max-w-[1280px] gap-16 lg:grid-cols-[40fr_60fr]">
        {/* LEFT */}
        <div>
          <FadeSlide>
            <div className="flex items-center gap-3">
              <span className="inline-block h-px w-6 bg-gold" />
              <span className="t-label text-gold">{t("CONTACT", "رابطہ")}</span>
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h2 className="mt-6 text-navy" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>
              {t("Always Reachable.", "ہمیشہ دستیاب۔")}
            </h2>
          </FadeSlide>
          <FadeSlide delay={140}>
            <p className="mt-5" style={{ color: "var(--ss-slate)", fontSize: 16, lineHeight: 1.75 }}>
              {t(
                "Email, WhatsApp, or the form — whichever you prefer. A real person on our team replies, usually within 2–3 hours during business days (Mon–Sat, 10am–7pm PKT).",
                "ای میل، واٹس ایپ، یا فارم — جو بھی آسان لگے۔ ہماری ٹیم کا ایک حقیقی فرد جواب دیتا ہے، عام طور پر کاروباری دنوں میں 2–3 گھنٹوں کے اندر (پیر تا ہفتہ، صبح 10 سے شام 7 بجے)۔",
              )}
            </p>
          </FadeSlide>

          <div className="mt-10 flex flex-col gap-6">
            {rows.map(({ Icon, label, value }, i) => (
              <FadeSlide key={label} delay={180 + i * 60}>
                <div className="flex items-center gap-4">
                  <span
                    className="grid place-items-center"
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 12,
                      background: "oklch(from var(--ss-gold) l c h / 0.10)",
                      color: "var(--ss-gold)",
                    }}
                  >
                    <Icon size={20} />
                  </span>
                  <div>
                    <div className="t-label" style={{ color: "var(--ss-ash)" }}>{label}</div>
                    <div className="text-navy" style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 16 }}>
                      {value}
                    </div>
                  </div>
                </div>
              </FadeSlide>
            ))}
          </div>

          <FadeSlide delay={400}>
            <div className="mt-10 flex flex-wrap gap-6">
              {["Instagram", "Facebook", "LinkedIn"].map((label) => (
                <a
                  key={label}
                  href="#"
                  className="underline underline-offset-4 transition-colors"
                  style={{ color: "var(--ss-ash)", fontSize: 14 }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = "var(--ss-gold)")}
                  onMouseLeave={(e) => (e.currentTarget.style.color = "var(--ss-ash)")}
                >
                  {label}
                </a>
              ))}
            </div>
          </FadeSlide>
        </div>

        {/* RIGHT */}
        <FadeSlide delay={150}>
          <div
            style={{
              background: "white",
              border: "1px solid var(--ss-rule)",
              borderRadius: 16,
              padding: 40,
            }}
          >
            {done ? (
              <div className="grid min-h-[360px] place-items-center text-center">
                <div>
                  <div style={{ color: "var(--ss-gold)", fontSize: 36 }}>✓</div>
                  <h3 className="mt-3 text-navy" style={{ fontFamily: "var(--font-display)" }}>
                    {t("Message sent.", "پیغام بھیج دیا گیا۔")}
                  </h3>
                  <p className="mt-2" style={{ color: "var(--ss-slate)", fontSize: 14 }}>
                    {t("We'll get back shortly.", "ہم جلد جواب دیں گے۔")}
                  </p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
                <input {...honeypotInputProps} style={honeypotStyle} defaultValue="" />
                <input name="name" required style={inputStyle} placeholder={t("Your name", "آپ کا نام")} />
                <input name="contact" required style={inputStyle} placeholder={t("Email or WhatsApp", "ای میل یا واٹس ایپ")} />
                <textarea
                  name="message"
                  required
                  style={{ ...inputStyle, minHeight: 140, resize: "vertical" }}
                  placeholder={t("How can we help?", "ہم کیسے مدد کر سکتے ہیں؟")}
                />
                {error && (
                  <p style={{ color: "var(--ss-gold-dim)", fontSize: 13 }}>{error}</p>
                )}
                <button
                  type="submit"
                  disabled={submitting}
                  className="transition-colors"
                  style={{
                    background: "var(--ss-navy)",
                    color: "white",
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 14,
                    borderRadius: 6,
                    padding: "14px",
                    width: "100%",
                    border: "none",
                    cursor: submitting ? "wait" : "pointer",
                    opacity: submitting ? 0.7 : 1,
                  }}
                >
                  {submitting ? t("Sending…", "بھیج رہا ہے…") : t("Send message", "پیغام بھیجیں")}
                </button>
              </form>
            )}
          </div>
        </FadeSlide>
      </div>
    </section>
  );
}
