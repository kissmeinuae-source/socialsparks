import { useEffect, useState } from "react";
import { useLanguage } from "@/lib/language";

/**
 * Hero — Editorial Bento (light)
 * Big white hero card on paper canvas, yellow stat tile, marquee strip,
 * services peek, bilingual EN/UR. Outfit headlines, Figtree body.
 */
export function Hero() {
  const { t, lang } = useLanguage();

  // Render clock client-side only to avoid SSR hydration mismatch.
  const [tick, setTick] = useState<string>("");
  useEffect(() => {
    const update = () => setTick(formatTime());
    update();
    const id = window.setInterval(update, 30_000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <section
      id="hero"
      aria-labelledby="hero-headline"
      className="bg-paper text-ink"
      style={{
        padding: "clamp(16px, 3vw, 32px) clamp(16px, 4vw, 40px) clamp(32px, 5vw, 56px)",
      }}
    >
      <div
        className="mx-auto grid w-full max-w-[1320px] grid-cols-12 gap-3 md:gap-4"
        style={{ gridAutoRows: "minmax(0, auto)" }}
      >
        {/* MAIN HERO CARD */}
        <div
          className="col-span-12 lg:col-span-8 tile ss-tile-in"
          style={{
            padding: "clamp(28px, 4vw, 64px)",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            gap: 48,
            minHeight: 480,
          }}
        >
          <div className="flex flex-col gap-6">
            <span className="chip chip-gold" style={{ alignSelf: "flex-start" }}>
              <span
                aria-hidden
                style={{
                  width: 6, height: 6, borderRadius: 9999,
                  background: "var(--ss-ink)",
                  animation: "ss-pulse 1.8s ease-in-out infinite",
                }}
              />
              {t("Premium Digital Agency · Lahore", "پریمیم ڈیجیٹل ایجنسی · لاہور")}
            </span>

            <h1
              id="hero-headline"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2.75rem, 1.4rem + 6.5vw, 6.5rem)",
                fontWeight: 800,
                lineHeight: 1.02,
                letterSpacing: "-0.04em",
                margin: 0,
                color: "var(--ss-ink)",
              }}
            >
              {lang === "ur" ? (
                <span className="urdu" style={{ display: "block" }}>
                  وہ چنگاری جس نے<br />لاہور کو جگایا
                </span>
              ) : (
                <>
                  The spark that<br />
                  ignited <span style={{ color: "rgba(10,10,10,0.28)" }}>Lahore.</span>
                </>
              )}
            </h1>

            <p
              style={{
                margin: 0,
                maxWidth: 540,
                fontFamily: "var(--font-sans)",
                fontWeight: 400,
                fontSize: "clamp(1rem, 0.95rem + 0.3vw, 1.18rem)",
                lineHeight: 1.55,
                color: "var(--ss-slate)",
              }}
            >
              {t(
                "A premium digital marketing agency elevating Pakistani brands to global standards through editorial strategy, performance media, and ruthless creative.",
                "ایک پریمیم ڈیجیٹل مارکیٹنگ ایجنسی جو پاکستانی برانڈز کو عالمی معیار تک پہنچاتی ہے۔",
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a href="#audit" className="btn-primary">
              {t("Book a Free Audit", "مفت آڈٹ بک کریں")}
              <span aria-hidden>→</span>
            </a>
            <a href="#results" className="btn-ghost">
              {t("View Case Studies", "کیس اسٹڈیز دیکھیں")}
            </a>
          </div>
        </div>

        {/* YELLOW STAT CARD */}
        <div
          className="col-span-12 sm:col-span-6 lg:col-span-4 tile tile-yellow ss-tile-in relative overflow-hidden"
          style={{
            padding: "clamp(24px, 2.5vw, 36px)",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            gap: 28,
            minHeight: 320,
            animationDelay: "80ms",
          }}
        >
          <div style={{ position: "relative", zIndex: 1 }}>
            <p
              style={{
                margin: 0,
                fontSize: 11,
                fontWeight: 600,
                letterSpacing: "0.22em",
                textTransform: "uppercase",
                color: "rgba(10,10,10,0.7)",
              }}
            >
              {t("Market Impact", "مارکیٹ اثر")}
            </p>
            <div
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 800,
                fontSize: "clamp(3.5rem, 5vw, 5rem)",
                letterSpacing: "-0.05em",
                lineHeight: 1,
                marginTop: 8,
                color: "var(--ss-ink)",
              }}
            >
              4.5×
            </div>
            <p
              style={{
                margin: "8px 0 0",
                fontSize: 14,
                fontWeight: 500,
                color: "var(--ss-ink)",
              }}
            >
              {t("Average ROI on managed paid media", "منظم پیڈ میڈیا پر اوسط ROI")}
            </p>
          </div>

          <span
            aria-hidden
            style={{
              position: "absolute",
              right: -28, bottom: -52,
              fontFamily: "var(--font-display)",
              fontWeight: 800,
              fontSize: 220,
              lineHeight: 1,
              color: "rgba(10,10,10,0.08)",
              userSelect: "none",
              letterSpacing: "-0.05em",
            }}
          >
            PK
          </span>

          <div style={{ position: "relative", zIndex: 1 }}>
            <div style={{ display: "flex", marginLeft: 0 }}>
              {["#D9D6CF", "#B8B3A8", "#8C857A", "#0A0A0A"].map((bg, i) => (
                <div
                  key={i}
                  style={{
                    width: 34, height: 34, borderRadius: 9999,
                    border: "2px solid var(--ss-gold)",
                    marginLeft: i === 0 ? 0 : -10,
                    background: bg,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "#FFD400", fontSize: 10, fontWeight: 700,
                    fontFamily: "var(--font-sans)",
                  }}
                >
                  {i === 3 ? "+50" : ""}
                </div>
              ))}
            </div>
            <p style={{ margin: "10px 0 0", fontSize: 12, fontWeight: 600, color: "var(--ss-ink)" }}>
              {t("Trusted by 50+ regional brands", "50+ علاقائی برانڈز کا اعتماد")}
            </p>
          </div>
        </div>

        {/* SERVICES MINI CARD */}
        <div
          className="col-span-12 sm:col-span-6 lg:col-span-4 tile ss-tile-in"
          style={{
            padding: "clamp(20px, 2vw, 28px)",
            display: "flex",
            flexDirection: "column",
            gap: 16,
            animationDelay: "160ms",
          }}
        >
          <div className="flex items-center justify-between">
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 700 }}>
              {t("Services", "خدمات")}
            </h3>
            <a
              href="#services"
              aria-label="View all services"
              style={{
                width: 32, height: 32, borderRadius: 9999,
                border: "1px solid var(--ss-line)",
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                color: "var(--ss-ink)", textDecoration: "none",
              }}
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                <path d="M5 12h14m-7-7 7 7-7 7" />
              </svg>
            </a>
          </div>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              { en: "Performance Ads", ur: "پرفارمنس ایڈز", on: true },
              { en: "Social Media Growth", ur: "سوشل میڈیا گروتھ", on: true },
              { en: "Brand Identity", ur: "برانڈ شناخت", on: false },
              { en: "Website Design", ur: "ویب سائٹ ڈیزائن", on: false },
            ].map((s) => (
              <li key={s.en} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span
                  aria-hidden
                  style={{
                    width: 8, height: 8, borderRadius: 9999,
                    background: s.on ? "var(--ss-gold)" : "rgba(10,10,10,0.1)",
                  }}
                />
                <span style={{ fontSize: 14, fontWeight: 500, color: s.on ? "var(--ss-ink)" : "var(--ss-ash)" }}>
                  {t(s.en, s.ur)}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* DARK MARQUEE STRIP */}
        <div
          className="col-span-12 lg:col-span-5 tile tile-navy ss-tile-in overflow-hidden flex items-center"
          style={{ padding: "20px 0", animationDelay: "200ms" }}
        >
          <div className="ss-marquee" style={{ display: "inline-flex", whiteSpace: "nowrap" }}>
            {[0, 1].map((run) => (
              <div key={run} style={{ display: "inline-flex", paddingRight: 0 }}>
                {[
                  "Global Reach",
                  "•",
                  "Local Precision",
                  "•",
                  "Bilingual EN × UR",
                  "•",
                  "Editorial Craft",
                  "•",
                ].map((label, i) => (
                  <span
                    key={`${run}-${i}`}
                    style={{
                      fontFamily: "var(--font-display)",
                      fontWeight: 600,
                      fontSize: 18,
                      letterSpacing: "0.04em",
                      textTransform: "uppercase",
                      color: label === "•" ? "var(--ss-gold)" : "#F7F5F0",
                      padding: "0 20px",
                    }}
                  >
                    {label}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* BILINGUAL CARD */}
        <div
          className="col-span-6 lg:col-span-2 tile ss-tile-in flex flex-col items-center justify-center text-center"
          style={{ padding: 20, animationDelay: "240ms" }}
        >
          <p className="t-eyebrow" style={{ margin: 0 }}>{t("Bilingual", "دو لسانی")}</p>
          <p style={{ margin: "6px 0 0", fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 700, letterSpacing: "-0.02em" }}>
            EN × UR
          </p>
        </div>

        {/* LOCATION + CLOCK CARD */}
        <div
          className="col-span-6 lg:col-span-5 tile ss-tile-in flex items-center justify-between gap-3"
          style={{ padding: "18px 22px", animationDelay: "280ms" }}
        >
          <div className="flex min-w-0 items-center gap-3">
            <div
              className="shrink-0"
              style={{
                width: 40, height: 40, borderRadius: 12,
                background: "var(--ss-paper)",
                display: "grid", placeItems: "center",
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 21s-8-4.5-8-11.8A8 8 0 0 1 12 2a8 8 0 0 1 8 7.2c0 7.3-8 11.8-8 11.8z" />
                <circle cx="12" cy="10" r="3" />
              </svg>
            </div>
            <div className="min-w-0">
              <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: "var(--ss-ink)" }} className="truncate">
                {t("Gulberg III, Lahore", "گلبرگ III، لاہور")}
              </p>
              <p style={{ margin: 0, fontSize: 11, color: "var(--ss-ash)" }}>
                {t("HQ / Pakistan", "ہیڈ کوارٹر / پاکستان")}
              </p>
            </div>
          </div>
          <span
            className="shrink-0"
            suppressHydrationWarning
            style={{
              padding: "6px 10px",
              background: "var(--ss-ink)",
              color: "#F7F5F0",
              fontFamily: "var(--font-sans)",
              fontFeatureSettings: '"tnum"',
              fontSize: 11,
              fontWeight: 600,
              borderRadius: 8,
              letterSpacing: "0.04em",
              minWidth: 84,
              textAlign: "center",
            }}
          >
            {tick ? `${tick} PKT` : "—— PKT"}
          </span>
        </div>
      </div>

      <style>{`
        @keyframes ss-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50%      { opacity: 0.5; transform: scale(0.85); }
        }
      `}</style>
    </section>
  );
}

function formatTime() {
  try {
    return new Date().toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      timeZone: "Asia/Karachi",
    });
  } catch {
    return "";
  }
}
