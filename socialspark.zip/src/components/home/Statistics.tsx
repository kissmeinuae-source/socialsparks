import { FadeSlide } from "@/components/anim/FadeSlide";
import { CountUp } from "@/components/anim/CountUp";
import { useLanguage } from "@/lib/language";

interface Stat {
  to: number;
  decimals?: number;
  suffix: string;
  label: [string, string];
  size: "hero" | "side";
}

const STATS: Stat[] = [
  { to: 50, suffix: "M+", size: "hero", label: ["Audience reach generated", "تخلیق شدہ سامعین کی رسائی"] },
  { to: 200, suffix: "+", size: "side", label: ["Brands sparked", "ترقی یافتہ برانڈز"] },
  { to: 3.2, decimals: 1, suffix: "×", size: "side", label: ["Average ROAS", "اوسط واپسی"] },
  { to: 98, suffix: "%", size: "side", label: ["Client retention", "کلائنٹ برقراری"] },
];

export function Statistics() {
  const { t, lang } = useLanguage();
  return (
    <section
      id="results"
      style={{
        background: "var(--ss-ink)",
        color: "var(--ss-cream)",
        borderBottom: "4px solid var(--ss-gold)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* watermark word */}
      <div
        aria-hidden
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: "var(--font-display)",
          fontWeight: 900,
          fontSize: "min(28vw, 28rem)",
          color: "var(--ss-gold)",
          opacity: 0.06,
          letterSpacing: "-0.05em",
          lineHeight: 1,
          pointerEvents: "none",
          userSelect: "none",
          textTransform: "uppercase",
        }}
      >
        LAHORE
      </div>

      <div
        className="relative"
        style={{
          maxWidth: 1400,
          margin: "0 auto",
          padding: "clamp(56px, 8vw, 112px) clamp(24px, 5vw, 72px)",
        }}
      >
        <FadeSlide>
          <span className="t-eyebrow">{t("Chapter 03 / Receipts", "باب 03 / ثبوت")}</span>
        </FadeSlide>
        <FadeSlide delay={80}>
          <h2
            style={{
              margin: "16px 0 0",
              maxWidth: 980,
              fontSize: "clamp(2.5rem, 1.6rem + 5vw, 5.5rem)",
              lineHeight: 0.85,
            }}
          >
            {t("Results we can ", "نتائج جو ہم ")}
            <span style={{ color: "var(--ss-gold)" }}>
              {t("actually measure.", "واقعی ناپ سکتے ہیں۔")}
            </span>
          </h2>
        </FadeSlide>
        <FadeSlide delay={140}>
          <p
            className={lang === "ur" ? "urdu" : ""}
            style={{
              margin: "18px 0 0",
              fontFamily: "var(--font-sans)",
              fontSize: 16,
              fontWeight: 500,
              lineHeight: 1.65,
              color: "var(--ss-slate)",
              maxWidth: 620,
            }}
          >
            {t(
              "Pulled live from client dashboards — not pitch decks. Refreshed every quarter and verified by the team that runs the work.",
              "نمبرز براہِ راست کلائنٹ ڈیش بورڈز سے — نہ کہ پچ ڈیک سے۔ ہر سہ ماہی تازہ ہوتے ہیں۔",
            )}
          </p>
        </FadeSlide>

        {/* HERO STAT */}
        <FadeSlide delay={200}>
          <div
            style={{
              marginTop: 64,
              display: "flex",
              flexDirection: "column",
              gap: 16,
              borderTop: "2px solid var(--ss-gold)",
              borderBottom: "2px solid var(--ss-gold)",
              paddingBlock: 40,
            }}
          >
            <div
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 900,
                fontSize: "clamp(6rem, 16vw, 15rem)",
                lineHeight: 0.8,
                letterSpacing: "-0.05em",
                color: "var(--ss-gold)",
                textTransform: "uppercase",
              }}
            >
              <CountUp to={STATS[0].to} decimals={STATS[0].decimals ?? 0} suffix={STATS[0].suffix} duration={1600} />
            </div>
            <div
              style={{
                fontFamily: "var(--font-sans)",
                fontSize: 14,
                fontWeight: 700,
                letterSpacing: "0.22em",
                textTransform: "uppercase",
                color: "var(--ss-cream)",
              }}
            >
              — {t(STATS[0].label[0], STATS[0].label[1])}
            </div>
          </div>
        </FadeSlide>

        {/* SIDE STATS */}
        <div
          className="grid grid-cols-1 md:grid-cols-3"
          style={{
            borderBottom: "2px solid var(--ss-gold)",
          }}
        >
          {STATS.slice(1).map((s, i) => (
            <FadeSlide key={s.label[0]} delay={300 + i * 80}>
              <div
                style={{
                  padding: "clamp(28px, 3vw, 48px) clamp(20px, 2.5vw, 32px)",
                  borderRight: i < 2 ? "2px solid var(--ss-gold)" : "none",
                  display: "flex",
                  flexDirection: "column",
                  gap: 16,
                  minHeight: 220,
                  justifyContent: "space-between",
                }}
              >
                <div
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 900,
                    fontSize: "clamp(3.5rem, 6vw, 6rem)",
                    lineHeight: 0.85,
                    letterSpacing: "-0.04em",
                    color: "var(--ss-cream)",
                  }}
                >
                  <CountUp to={s.to} decimals={s.decimals ?? 0} suffix={s.suffix} duration={1400} />
                </div>
                <div
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 12,
                    fontWeight: 700,
                    letterSpacing: "0.2em",
                    textTransform: "uppercase",
                    color: "var(--ss-slate)",
                  }}
                >
                  {t(s.label[0], s.label[1])}
                </div>
              </div>
            </FadeSlide>
          ))}
        </div>

        <FadeSlide delay={520}>
          <p
            style={{
              marginTop: 32,
              marginBottom: 0,
              fontFamily: "var(--font-sans)",
              fontSize: 12,
              fontWeight: 600,
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              color: "var(--ss-ash)",
              textAlign: "right",
            }}
          >
            {t("Verified · Updated quarterly", "تصدیق شدہ · سہ ماہی اپڈیٹ")}
          </p>
        </FadeSlide>
      </div>
    </section>
  );
}
