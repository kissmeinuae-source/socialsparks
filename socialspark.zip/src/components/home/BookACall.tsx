import { useState, type FormEvent } from "react";
import { z } from "zod";
import { useServerFn } from "@tanstack/react-start";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";
import { submitLead } from "@/lib/leads.functions";
import { HONEYPOT_FIELD, honeypotInputProps, honeypotStyle } from "@/lib/honeypot";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  whatsapp: z
    .string()
    .trim()
    .regex(/^\+92\s?3\d{2}\s?\d{7}$/, "WhatsApp must be in +92 3XX XXXXXXX format"),
  email: z.string().trim().email().max(160),
  business: z.string().min(1),
  service: z.string().min(1),
  message: z.string().trim().max(800).optional().or(z.literal("")),
});

const inputStyle: React.CSSProperties = {
  background: "transparent",
  border: "1px solid var(--ss-line)",
  borderRadius: "4px",
  padding: "12px 16px",
  color: "white",
  fontFamily: "var(--font-sans)",
  fontSize: "14px",
  width: "100%",
  outline: "none",
};

export function BookACall() {
  const { t } = useLanguage();
  const submit = useServerFn(submitLead);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = Object.fromEntries(fd.entries()) as Record<string, string>;
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Please complete all fields.");
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await submit({
        data: {
          type: "book",
          name: parsed.data.name,
          email: parsed.data.email,
          phone: parsed.data.whatsapp,
          business: parsed.data.business,
          message: `Service interest: ${parsed.data.service}${parsed.data.message ? `\n\n${parsed.data.message}` : ""}`,
          source_page: typeof window !== "undefined" ? window.location.pathname : null,
          website_url: (fd.get(HONEYPOT_FIELD) as string | null) ?? null,
        },
      });
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  const benefits = [
    t("Completely free, no commitment required", "مکمل مفت، کوئی پابندی نہیں"),
    t("Get a quick audit before the call even starts", "کال سے پہلے فوری آڈٹ"),
    t("We can conduct the call in Urdu or English", "اردو یا انگریزی میں کال"),
    t("Live in 48 hours if you decide to go ahead", "فیصلہ ہوا تو 48 گھنٹے میں لائیو"),
  ];

  return (
    <section
      id="book"
      className="relative"
      style={{ background: "var(--ss-ink)", padding: "112px 48px" }}
    >
      <div className="mx-auto grid max-w-[1280px] gap-16 lg:grid-cols-2">
        {/* LEFT */}
        <div>
          <FadeSlide>
            <div className="flex items-center gap-3">
              <span className="inline-block h-px w-6 bg-gold" />
              <span className="t-label text-gold">
                {t("BOOK A CALL", "کال بک کریں")}
              </span>
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h2 className="mt-6 text-white" style={{ fontFamily: "var(--font-display)", fontWeight: 800 }}>
              {t("Book a Free 30-Minute Call.", "مفت 30 منٹ کی کال بک کریں۔")}
            </h2>
          </FadeSlide>
          <FadeSlide delay={150}>
            <p className="mt-6" style={{ color: "var(--ss-ash)", fontSize: "16px", lineHeight: 1.75 }}>
              {t(
                "No pitch. No pressure. We look at your current online presence, tell you what's working and what isn't, and share what we'd do differently. You decide whether to proceed.",
                "نہ کوئی پچ، نہ کوئی دباؤ۔ ہم آپ کی موجودہ آن لائن موجودگی دیکھتے ہیں اور بتاتے ہیں کیا کام کر رہا ہے اور کیا نہیں۔",
              )}
            </p>
          </FadeSlide>
          <div className="mt-10 flex flex-col gap-5">
            {benefits.map((b, i) => (
              <FadeSlide key={i} delay={200 + i * 60}>
                <div className="flex items-center gap-4">
                  <span className="inline-block bg-gold" style={{ width: 16, height: 2 }} />
                  <span style={{ color: "var(--ss-ash)", fontSize: 14 }}>{b}</span>
                </div>
              </FadeSlide>
            ))}
          </div>
        </div>

        {/* RIGHT — form */}
        <FadeSlide delay={200}>
          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid var(--ss-line)",
              borderRadius: "4px",
              padding: "40px 44px",
            }}
          >
            {done ? (
              <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                <div
                  className="grid place-items-center"
                  style={{
                    width: 64,
                    height: 64,
                    borderRadius: "50%",
                    background: "var(--ss-gold)",
                    color: "var(--ss-ink)",
                    fontSize: 28,
                    fontWeight: 800,
                  }}
                >
                  ✓
                </div>
                <h3 className="mt-6 text-white" style={{ fontFamily: "var(--font-display)" }}>
                  {t("We'll WhatsApp you within a few hours.", "ہم چند گھنٹوں میں واٹس ایپ کریں گے۔")}
                </h3>
                <p className="mt-3" style={{ color: "var(--ss-ash)", fontSize: 14, maxWidth: 360, lineHeight: 1.6 }}>
                  {t(
                    "A senior strategist will confirm a time that works for you and send a short pre-call brief so we don't waste a minute.",
                    "ایک سینئر اسٹریٹجسٹ آپ کے مطابق وقت طے کرے گا اور مختصر بریف بھیجے گا تاکہ کال کا ایک منٹ بھی ضائع نہ ہو۔",
                  )}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
                <input {...honeypotInputProps} style={honeypotStyle} defaultValue="" />
                <div className="grid gap-4 sm:grid-cols-2">
                  <input style={inputStyle} name="name" required placeholder={t("Full name", "پورا نام")} />
                  <input style={inputStyle} name="whatsapp" required placeholder="+92 300 0000000" />
                </div>
                <input style={inputStyle} name="email" required type="email" placeholder={t("Email", "ای میل")} />
                <select style={inputStyle} name="business" required defaultValue="">
                  <option value="" disabled>{t("Business type", "کاروبار کی قسم")}</option>
                  <option>Restaurant/Food</option>
                  <option>Salon/Beauty</option>
                  <option>Clinic/Healthcare</option>
                  <option>Celebrity or Public Figure</option>
                  <option>Retail/eCommerce</option>
                  <option>Other</option>
                </select>
                <select style={inputStyle} name="service" required defaultValue="">
                  <option value="" disabled>{t("Service interest", "دلچسپی کی سروس")}</option>
                  <option>Social Media Management</option>
                  <option>Paid Advertising</option>
                  <option>Website Design</option>
                  <option>Full Retainer Package</option>
                  <option>Not sure yet — let's talk</option>
                </select>
                <textarea
                  style={{ ...inputStyle, minHeight: 90, resize: "vertical" }}
                  name="message"
                  placeholder={t(
                    "Tell us briefly about your business and your goals...",
                    "اپنے کاروبار اور اہداف کے بارے میں مختصر بتائیں...",
                  )}
                />
                {error && (
                  <p style={{ color: "var(--ss-gold)", fontSize: 13 }}>{error}</p>
                )}
                <button
                  type="submit"
                  disabled={submitting}
                  className="transition-colors"
                  style={{
                    background: "var(--ss-gold)",
                    color: "var(--ss-ink)",
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 14,
                    borderRadius: 4,
                    padding: "14px",
                    width: "100%",
                    border: "none",
                    cursor: submitting ? "wait" : "pointer",
                    opacity: submitting ? 0.7 : 1,
                  }}
                >
                  {submitting ? t("Sending…", "بھیج رہا ہے…") : t("Request my free call", "میری مفت کال طلب کریں")}
                </button>
              </form>
            )}
          </div>
        </FadeSlide>
      </div>
    </section>
  );
}
