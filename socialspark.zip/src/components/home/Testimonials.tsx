import { useQuery } from "@tanstack/react-query";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";
import { listPublishedTestimonials } from "@/lib/cms.functions";

interface Quote {
  text: [string, string];
  name: [string, string];
  role: [string, string];
}

const FEATURED: Quote = {
  text: [
    "As a public figure, your digital presence is your reputation. Social Spark understood that immediately. They handle my pages with the same care I'd give them — except they're far more skilled at it. My engagement tripled in six weeks and I've had zero incidents of off-brand content.",
    "ایک عوامی شخصیت کے طور پر، آپ کی ڈیجیٹل موجودگی آپ کی ساکھ ہے۔ سوشل اسپارک نے اسے فوراً سمجھ لیا۔ وہ میرے صفحات کو اسی توجہ سے سنبھالتے ہیں جیسے میں خود کرتا — مگر کہیں زیادہ مہارت سے۔ چھ ہفتوں میں میری اینگیجمنٹ تین گنا ہو گئی اور ایک بھی برانڈ کے خلاف مواد نہیں آیا۔",
  ],
  name: ["Waseem Badami", "وسیم بادامی"],
  role: ["ARY News Anchor", "اے آر وائی نیوز اینکر"],
};

const SECONDARY: Quote[] = [
  {
    text: [
      "We went from 800 followers to 12,000 in two months. The restaurant is fully booked every weekend now. We haven't run a single traditional ad since.",
      "ہم نے دو ماہ میں 800 سے 12,000 فالوورز حاصل کیے۔ ہر ویک اینڈ ریستوران مکمل بک ہوتا ہے۔ تب سے کوئی روایتی اشتہار نہیں چلایا۔",
    ],
    name: ["Ahmed Khan", "احمد خان"],
    role: ["Spice Route Restaurant, Lahore", "اسپائس روٹ ریستوران، لاہور"],
  },
  {
    text: [
      "Our clinic inquiries doubled in 30 days. The reporting is honest and clear — as a doctor I appreciate knowing exactly what's happening and why.",
      "ہمارے کلینک کی انکوائریز 30 دن میں دگنی ہو گئیں۔ رپورٹنگ ایماندار اور واضح ہے — ایک ڈاکٹر کے طور پر مجھے یہ جاننا اچھا لگتا ہے کہ کیا ہو رہا ہے اور کیوں۔",
    ],
    name: ["Dr. Rania Siddiqui", "ڈاکٹر رانیہ صدیقی"],
    role: ["Dermatologist, Islamabad", "ڈرمیٹولوجسٹ، اسلام آباد"],
  },
  {
    text: [
      "I've worked with three agencies before. Social Spark is the first one that actually picks up the phone, writes in real Urdu, and ships work I'm proud to put my name on.",
      "میں نے پہلے تین ایجنسیوں سے کام کیا ہے۔ سوشل اسپارک پہلی ہے جو واقعی فون اٹھاتی ہے، اصلی اردو لکھتی ہے، اور ایسا کام دیتی ہے جس پر میں اپنا نام رکھنے میں فخر کروں۔",
    ],
    name: ["Sara Malik", "سارہ ملک"],
    role: ["Founder, Velour Salon", "بانی، ویلور سیلون"],
  },
];

function OpenQuote({ size = 72 }: { size?: number }) {
  return (
    <span
      aria-hidden
      style={{
        fontFamily: "var(--font-display)",
        fontWeight: 800,
        fontSize: size,
        lineHeight: 0.7,
        color: "var(--ss-gold)",
        display: "inline-block",
      }}
    >
      “
    </span>
  );
}

function Attribution({ name, role, t }: { name: [string, string]; role: [string, string]; t: (e: string, u: string) => string }) {
  return (
    <div style={{ marginTop: 28 }}>
      <span
        aria-hidden
        style={{
          display: "block",
          width: 40,
          height: 1,
          backgroundColor: "var(--ss-gold)",
          marginBottom: 14,
        }}
      />
      <div
        style={{
          fontFamily: "var(--font-display)",
          fontWeight: 700,
          fontSize: 16,
          color: "#fff",
          letterSpacing: "-0.005em",
        }}
      >
        {t(name[0], name[1])}
      </div>
      <div
        style={{
          fontFamily: "var(--font-sans)",
          fontSize: 13,
          color: "var(--ss-ash)",
          marginTop: 4,
        }}
      >
        {t(role[0], role[1])}
      </div>
    </div>
  );
}

export function Testimonials() {
  const { t } = useLanguage();
  const { data: dbRows } = useQuery({
    queryKey: ["public", "testimonials"],
    queryFn: () => listPublishedTestimonials(),
    staleTime: 60_000,
  });

  // Map DB rows into the local Quote shape; fall back to hardcoded copy when empty.
  const mapped: Quote[] = (dbRows ?? []).map((r) => ({
    text: [r.quote_en, r.quote_ur ?? r.quote_en],
    name: [r.name, r.name],
    role: [
      [r.role_en, r.company].filter(Boolean).join(" · "),
      [r.role_ur ?? r.role_en, r.company].filter(Boolean).join(" · "),
    ],
  }));
  const featured = mapped[0] ?? FEATURED;
  const secondary = mapped.length > 1 ? mapped.slice(1, 4) : SECONDARY;
  if (mapped.length === 1) secondary.push(...SECONDARY.slice(0, 3));
  while (secondary.length < 3) secondary.push(SECONDARY[secondary.length]);

  return (
    <section
      id="testi"
      style={{ backgroundColor: "var(--ss-ink)", padding: "112px 48px" }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <FadeSlide>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
            <span
              aria-hidden
              style={{ display: "inline-block", width: 2, height: 24, backgroundColor: "var(--ss-gold)" }}
            />
            <span
              style={{
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 11,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "var(--ss-ash)",
              }}
            >
              {t("TESTIMONIALS", "تاثرات")}
            </span>
          </div>
        </FadeSlide>

        <FadeSlide delay={120}>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: "var(--type-h2-size)",
              color: "#fff",
              letterSpacing: "-0.025em",
              lineHeight: 1.05,
              margin: 0,
            }}
          >
            {t("In Their Words.", "ان کے الفاظ میں۔")}
          </h2>
        </FadeSlide>

        {/* Featured quote */}
        <FadeSlide delay={240}>
          <div
            style={{
              marginTop: 64,
              maxWidth: "70%",
              position: "relative",
            }}
            className="ss-featured-quote"
          >
            <div
              style={{
                position: "absolute",
                top: -28,
                left: -8,
                pointerEvents: "none",
              }}
            >
              <OpenQuote size={72} />
            </div>
            <blockquote
              style={{
                margin: 0,
                paddingLeft: 0,
                fontFamily: "var(--font-sans)",
                fontStyle: "italic",
                fontWeight: 400,
                fontSize: 22,
                lineHeight: 1.7,
                color: "#fff",
              }}
            >
              {t(featured.text[0], featured.text[1])}
            </blockquote>
            <Attribution name={featured.name} role={featured.role} t={t} />
          </div>
        </FadeSlide>

        {/* Smaller pair */}
        <div
          className="ss-testi-pair"
          style={{
            marginTop: 80,
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 48,
          }}
        >
          {secondary.map((q, i) => (
            <FadeSlide key={q.name[0]} delay={360 + i * 120}>
              <div style={{ position: "relative" }}>
                <div style={{ position: "absolute", top: -18, left: -4, pointerEvents: "none" }}>
                  <OpenQuote size={44} />
                </div>
                <blockquote
                  style={{
                    margin: 0,
                    fontFamily: "var(--font-sans)",
                    fontStyle: "italic",
                    fontWeight: 400,
                    fontSize: 16,
                    lineHeight: 1.7,
                    color: "var(--ss-ash)",
                  }}
                >
                  {t(q.text[0], q.text[1])}
                </blockquote>
                <Attribution name={q.name} role={q.role} t={t} />
              </div>
            </FadeSlide>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 960px) {
          .ss-testi-pair { grid-template-columns: 1fr 1fr !important; gap: 48px !important; }
        }
        @media (max-width: 640px) {
          .ss-featured-quote { max-width: 100% !important; }
          .ss-testi-pair { grid-template-columns: 1fr !important; gap: 48px !important; }
        }
      `}</style>
    </section>
  );
}
