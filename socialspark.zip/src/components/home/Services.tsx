import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language";
import { listPublishedServices } from "@/lib/cms.functions";

type Service = {
  num: string;
  title: { en: string; ur: string };
  body: { en: string; ur: string };
  tone: "ink" | "cream" | "gold";
};

const fallback: Service[] = [
  { num: "01", title: { en: "Celebrity Branding", ur: "سیلیبرٹی برانڈنگ" }, body: { en: "Legacy positioning and digital footprint management for Pakistan's biggest icons.", ur: "پاکستان کی بڑی شخصیات کے لیے ڈیجیٹل وراثت۔" }, tone: "ink" },
  { num: "02", title: { en: "Growth Hacking", ur: "گروتھ ہیکنگ" }, body: { en: "Aggressive performance marketing engineered for 3-10× ROAS on Meta and Google.", ur: "میٹا اور گوگل پر جارحانہ کارکردگی۔" }, tone: "cream" },
  { num: "03", title: { en: "Social PR", ur: "سوشل پی آر" }, body: { en: "Crisis containment, sentiment control, and proactive narrative engineering.", ur: "بحران پر قابو اور بیانیہ کنٹرول۔" }, tone: "ink" },
  { num: "04", title: { en: "Video Labs", ur: "ویڈیو لیبز" }, body: { en: "High-retention reels, longform, and broadcast-grade studio production in Lahore.", ur: "اعلیٰ معیار کی ویڈیو پروڈکشن۔" }, tone: "gold" },
  { num: "05", title: { en: "Website Design", ur: "ویب سائٹ ڈیزائن" }, body: { en: "Editorial, fast, conversion-tuned sites that read premium across every device.", ur: "تیز، ایڈیٹوریل ویب سائٹس۔" }, tone: "ink" },
  { num: "06", title: { en: "Brand Identity", ur: "برانڈ شناخت" }, body: { en: "Marks, type, tone — a complete identity system you can ship anywhere.", ur: "مکمل برانڈ شناخت کا نظام۔" }, tone: "cream" },
  { num: "07", title: { en: "SEO & Local", ur: "ایس ای او اور لوکل" }, body: { en: "Be the first result when Karachi searches your category at 11pm.", ur: "آپ کی کیٹیگری میں پہلا نتیجہ۔" }, tone: "ink" },
  { num: "08", title: { en: "Content Ops", ur: "کنٹینٹ آپس" }, body: { en: "Editorial calendar, community ops, and daily publishing on autopilot.", ur: "روزانہ مواد اور کمیونٹی۔" }, tone: "gold" },
];

function tileStyle(tone: Service["tone"]): React.CSSProperties {
  if (tone === "cream") return { background: "var(--ss-cream)", color: "var(--ss-ink)" };
  if (tone === "gold") return { background: "var(--ss-gold)", color: "var(--ss-ink)" };
  return { background: "var(--ss-ink)", color: "var(--ss-cream)" };
}

export function Services() {
  const { lang, t } = useLanguage();
  const { data: dbRows } = useQuery({
    queryKey: ["public", "services"],
    queryFn: () => listPublishedServices(),
    staleTime: 60_000,
  });
  const tones: Service["tone"][] = ["ink", "cream", "ink", "gold", "ink", "cream", "ink", "gold"];
  const live: Service[] = (dbRows ?? []).slice(0, 8).map((r, i) => ({
    num: String(i + 1).padStart(2, "0"),
    title: { en: r.title_en, ur: r.title_ur ?? r.title_en },
    body: { en: r.summary_en ?? "", ur: r.summary_ur ?? r.summary_en ?? "" },
    tone: tones[i],
  }));
  const items = live.length > 0 ? live : fallback;

  return (
    <section
      id="services"
      style={{
        background: "var(--ss-ink)",
        color: "var(--ss-cream)",
        borderBottom: "4px solid var(--ss-gold)",
      }}
    >
      {/* Header band */}
      <div
        className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between"
        style={{
          padding: "clamp(48px, 7vw, 96px) clamp(24px, 5vw, 72px)",
          borderBottom: "2px solid var(--ss-gold)",
        }}
      >
        <div>
          <span className="t-eyebrow">{t("Chapter 02 / Expertise", "باب 02 / مہارت")}</span>
          <h2
            style={{
              margin: "16px 0 0",
              fontSize: "clamp(2.5rem, 1.6rem + 5vw, 5.5rem)",
              lineHeight: 0.85,
            }}
          >
            {t("Eight disciplines.", "آٹھ شعبے۔")}
            <br />
            <span style={{ color: "var(--ss-gold)" }}>
              {t("One brand voice.", "ایک برانڈ۔")}
            </span>
          </h2>
        </div>
        <p
          className={lang === "ur" ? "urdu" : ""}
          style={{
            maxWidth: 420,
            margin: 0,
            color: "var(--ss-slate)",
            fontSize: "1.0625rem",
            lineHeight: 1.6,
            fontWeight: 500,
          }}
        >
          {t(
            "Every capability is run by a dedicated lead in our Lahore studio. No outsourcing, no white-label, no surprises on the invoice.",
            "ہر شعبہ ہمارے لاہور اسٹوڈیو میں ایک سرشار لیڈ چلاتا ہے۔ کوئی آؤٹ سورسنگ نہیں۔",
          )}
        </p>
      </div>

      {/* Brutalist grid — square tiles, hard yellow lines */}
      <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 list-none p-0 m-0">
        {items.map((s, i) => {
          const colIsLast = (i + 1) % 4 === 0;
          const colMdLast = (i + 1) % 2 === 0;
          return (
            <li
              key={s.num + s.title.en}
              className="group relative flex flex-col justify-between aspect-square ss-tile-in"
              style={{
                ...tileStyle(s.tone),
                padding: "clamp(20px, 2.5vw, 32px)",
                borderRight: `2px solid var(--ss-gold)`,
                borderBottom: `2px solid var(--ss-gold)`,
                animationDelay: `${i * 60}ms`,
              }}
              data-last-col={colIsLast || undefined}
              data-md-last={colMdLast || undefined}
            >
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 900,
                  fontSize: "clamp(2.5rem, 4vw, 3.75rem)",
                  lineHeight: 0.8,
                  letterSpacing: "-0.04em",
                  color: s.tone === "ink" ? "var(--ss-gold)" : "var(--ss-ink)",
                }}
              >
                {s.num}
              </div>

              <div>
                <h3
                  className={lang === "ur" ? "urdu" : ""}
                  style={{
                    fontFamily: lang === "ur" ? "var(--font-urdu)" : "var(--font-display)",
                    fontWeight: lang === "ur" ? 700 : 900,
                    fontSize: "clamp(1.5rem, 1.1rem + 1.2vw, 2.25rem)",
                    lineHeight: 0.95,
                    letterSpacing: "-0.03em",
                    textTransform: lang === "ur" ? "none" : "uppercase",
                    color: "inherit",
                    margin: "0 0 12px",
                  }}
                >
                  {lang === "en" ? s.title.en : s.title.ur}
                </h3>
                <p
                  className={lang === "ur" ? "urdu" : ""}
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 13,
                    lineHeight: 1.5,
                    fontWeight: 600,
                    textTransform: lang === "ur" ? "none" : "uppercase",
                    letterSpacing: "0.02em",
                    opacity: s.tone === "ink" ? 0.75 : 0.8,
                    margin: 0,
                  }}
                >
                  {lang === "en" ? s.body.en : s.body.ur}
                </p>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
