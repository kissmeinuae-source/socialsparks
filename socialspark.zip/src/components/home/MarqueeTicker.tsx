import { useLanguage } from "@/lib/language";

const items = [
  { en: "Celebrity Management", ur: "سیلیبرٹی مینجمنٹ" },
  { en: "Digital PR", ur: "ڈیجیٹل پی آر" },
  { en: "Viral Content", ur: "وائرل مواد" },
  { en: "Paid Media", ur: "پیڈ میڈیا" },
  { en: "Personal Branding", ur: "پرسنل برانڈنگ" },
  { en: "SEO & Local Search", ur: "ایس ای او" },
  { en: "Video Strategy", ur: "ویڈیو اسٹریٹجی" },
  { en: "Brand Identity", ur: "برانڈ شناخت" },
];

/**
 * Brutalist marquee — cream strip, Archivo Black, alternating yellow stroked words.
 */
export function MarqueeTicker() {
  const { lang } = useLanguage();
  const loop = [...items, ...items];

  return (
    <section
      aria-label="Capabilities"
      className="relative overflow-hidden"
      style={{
        background: "var(--ss-cream)",
        color: "var(--ss-ink)",
        borderBottom: "4px solid var(--ss-ink)",
      }}
    >
      <div
        className="ss-marquee flex items-center whitespace-nowrap"
        style={{ width: "max-content", paddingBlock: 20 }}
      >
        {loop.map((item, i) => {
          const accent = i % 2 === 1;
          return (
            <span
              key={i}
              className="flex items-center"
              style={{ paddingInline: 36 }}
            >
              <span
                className={lang === "ur" ? "urdu" : ""}
                style={{
                  fontFamily: lang === "ur" ? "var(--font-urdu)" : "var(--font-display)",
                  fontWeight: lang === "ur" ? 700 : 900,
                  fontSize: "clamp(1.75rem, 1.4rem + 1.2vw, 2.5rem)",
                  lineHeight: 1,
                  letterSpacing: "-0.03em",
                  textTransform: lang === "ur" ? "none" : "uppercase",
                  color: accent ? "var(--ss-gold)" : "var(--ss-ink)",
                  WebkitTextStroke: accent ? "1.5px var(--ss-ink)" : "0",
                }}
              >
                {lang === "en" ? item.en : item.ur}
              </span>
              <span
                aria-hidden
                className="ml-9 inline-block"
                style={{
                  width: 10,
                  height: 10,
                  background: "var(--ss-ink)",
                  transform: "rotate(45deg)",
                }}
              />
            </span>
          );
        })}
      </div>
    </section>
  );
}
