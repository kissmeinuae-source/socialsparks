import { useQuery } from "@tanstack/react-query";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";
import { listPublishedPricingPlans } from "@/lib/cms.functions";


interface Plan {
  tier: [string, string];
  price: string;
  features: Array<[string, string]>;
  featured?: boolean;
  cta: [string, string];
  tagline: [string, string];
}

const PLANS: Plan[] = [
  {
    tier: ["Starter", "اسٹارٹر"],
    price: "35,000",
    cta: ["Choose Starter", "اسٹارٹر منتخب کریں"],
    tagline: ["For brands finding their voice.", "اپنی آواز تلاش کرنے والے برانڈز کے لیے۔"],
    features: [
      ["2 social platforms managed", "2 سوشل پلیٹ فارمز"],
      ["12 posts per month", "ماہانہ 12 پوسٹس"],
      ["Graphic design included", "گرافک ڈیزائن شامل"],
      ["Monthly performance report", "ماہانہ کارکردگی رپورٹ"],
      ["WhatsApp support", "واٹس ایپ سپورٹ"],
    ],
  },
  {
    tier: ["Growth", "گروتھ"],
    price: "75,000",
    featured: true,
    cta: ["Choose Growth", "گروتھ منتخب کریں"],
    tagline: ["For brands ready to scale.", "ترقی کے لیے تیار برانڈز کے لیے۔"],
    features: [
      ["4 platforms including TikTok", "4 پلیٹ فارمز بشمول ٹک ٹاک"],
      ["24 posts + 8 stories monthly", "ماہانہ 24 پوسٹس + 8 اسٹوریز"],
      ["Meta & Google ad management", "میٹا اور گوگل ایڈز"],
      ["Reel scripting & strategy", "ریل اسکرپٹنگ اور حکمت عملی"],
      ["Dedicated account manager", "اکاؤنٹ مینیجر مختص"],
      ["Weekly reporting", "ہفتہ وار رپورٹنگ"],
    ],
  },
  {
    tier: ["Premium", "پریمیم"],
    price: "140,000",
    cta: ["Choose Premium", "پریمیم منتخب کریں"],
    tagline: ["For category leaders.", "صفِ اول کے برانڈز کے لیے۔"],
    features: [
      ["All platforms, no restrictions", "تمام پلیٹ فارمز"],
      ["Unlimited content production", "لامحدود کنٹینٹ"],
      ["Full ad account management", "مکمل ایڈ اکاؤنٹ مینجمنٹ"],
      ["Bilingual SEO (Urdu + English)", "دو لسانی SEO"],
      ["Daily reporting dashboard", "روزانہ رپورٹنگ ڈیش بورڈ"],
      ["Priority support, always-on", "ترجیحی سپورٹ، ہر وقت"],
    ],
  },
];

function PlanCard({ plan, t }: { plan: Plan; t: (e: string, u: string) => string }) {
  const featured = !!plan.featured;
  const tileClass = featured ? "tile tile-navy tile-elevated" : "tile";
  const titleColor = featured ? "var(--ss-cream)" : "var(--ss-ink)";
  const subColor = featured ? "rgba(245,243,238,0.7)" : "var(--ss-ash)";
  const featColor = featured ? "rgba(245,243,238,0.85)" : "var(--ss-slate)";
  const dotColor = featured ? "var(--ss-gold)" : "var(--ss-ink)";
  const ruleColor = featured ? "rgba(245,243,238,0.12)" : "var(--ss-line)";

  return (
    <div className={tileClass} style={{ padding: 36, display: "flex", flexDirection: "column", height: "100%", position: "relative" }}>
      {featured && (
        <span style={{ position: "absolute", top: 20, right: 20, fontFamily: "var(--font-sans)", fontSize: 10, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ss-ink)", background: "var(--ss-gold)", padding: "6px 12px", borderRadius: 9999 }}>
          {t("Most chosen", "زیادہ مقبول")}
        </span>
      )}
      <div style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: 32, lineHeight: 1, color: titleColor }}>
        {t(plan.tier[0], plan.tier[1])}
      </div>
      <p style={{ margin: "8px 0 0", fontFamily: "var(--font-sans)", fontSize: 13, color: subColor, lineHeight: 1.5 }}>
        {t(plan.tagline[0], plan.tagline[1])}
      </p>

      <div style={{ marginTop: 28, display: "flex", alignItems: "baseline", gap: 8 }}>
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, letterSpacing: "0.12em", color: subColor }}>PKR</span>
        <span style={{ fontFamily: "var(--font-display)", fontSize: 56, lineHeight: 1, letterSpacing: "-0.03em", color: titleColor, fontStyle: "italic" }}>
          {plan.price}
        </span>
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: subColor }}>/{t("mo", "ماہ")}</span>
      </div>

      <div style={{ marginTop: 28, marginBottom: 22, height: 1, backgroundColor: ruleColor }} />

      <ul style={{ listStyle: "none", margin: 0, padding: 0, flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
        {plan.features.map(([en, ur]) => (
          <li key={en} style={{ display: "flex", alignItems: "flex-start", gap: 12, fontFamily: "var(--font-sans)", fontSize: 14, lineHeight: 1.5, color: featColor }}>
            <span aria-hidden style={{ marginTop: 6, width: 5, height: 5, borderRadius: "50%", backgroundColor: dotColor, flexShrink: 0 }} />
            <span>{t(en, ur)}</span>
          </li>
        ))}
      </ul>

      <a href="#audit" className={featured ? "btn-yellow" : "btn-ghost"} style={{ marginTop: 32, justifyContent: "center", width: "100%" }}>
        {t(plan.cta[0], plan.cta[1])}
        <span aria-hidden>→</span>
      </a>
    </div>
  );
}

export function Pricing() {
  const { t } = useLanguage();
  const { data: dbRows } = useQuery({
    queryKey: ["public", "pricing"],
    queryFn: () => listPublishedPricingPlans(),
    staleTime: 60_000,
  });
  const live: Plan[] = (dbRows ?? []).map((r) => {
    const featuresRaw = Array.isArray(r.features) ? r.features : [];
    const features: Array<[string, string]> = featuresRaw
      .map((f) => {
        if (typeof f === "string") return [f, f] as [string, string];
        if (f && typeof f === "object") {
          const o = f as Record<string, unknown>;
          const en = typeof o.en === "string" ? o.en : "";
          if (!en) return null;
          return [en, typeof o.ur === "string" && o.ur ? o.ur : en] as [string, string];
        }
        return null;
      })
      .filter((x): x is [string, string] => !!x);
    return {
      tier: [r.name_en, r.name_ur ?? r.name_en],
      price: Number(r.price_pkr).toLocaleString(),
      featured: r.highlighted,
      cta: [`Choose ${r.name_en}`, `${r.name_ur ?? r.name_en} منتخب کریں`],
      tagline: [r.tagline_en ?? "", r.tagline_ur ?? r.tagline_en ?? ""],
      features,
    };
  });
  const items = live.length > 0 ? live : PLANS;

  return (
    <section id="pricing" style={{ backgroundColor: "var(--ss-cream)", padding: "112px 24px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <FadeSlide>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <span aria-hidden style={{ width: 28, height: 1, backgroundColor: "var(--ss-ink)", opacity: 0.4 }} />
            <span className="t-eyebrow">{t("Pricing", "قیمتیں")}</span>
          </div>
        </FadeSlide>
        <FadeSlide delay={80}>
          <h2 style={{ margin: 0, maxWidth: 880 }}>
            {t("Transparent rates. ", "شفاف قیمتیں۔ ")}
            <span style={{ fontStyle: "italic" }}>{t("No surprises.", "کوئی حیرانی نہیں۔")}</span>
          </h2>
        </FadeSlide>
        <FadeSlide delay={140}>
          <p style={{ margin: "16px 0 0", fontFamily: "var(--font-sans)", fontSize: 16, color: "var(--ss-slate)", maxWidth: 560 }}>
            {t("All plans in PKR. Month-to-month. Cancel with 30 days notice.", "تمام پلانز PKR میں۔ ماہانہ۔ 30 دن کے نوٹس پر منسوخ۔")}
          </p>
        </FadeSlide>

        <div className="ss-pricing-bento">
          {items.map((p, i) => (
            <FadeSlide key={`${p.tier[0]}-${i}`} delay={200 + i * 100}>
              <PlanCard plan={p} t={t} />
            </FadeSlide>
          ))}
        </div>


        <FadeSlide delay={520}>
          <p style={{ marginTop: 48, textAlign: "center", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ash)", fontStyle: "italic" }}>
            {t("Not sure which fits? The free call will tell us both.", "یقین نہیں کونسا پلان موزوں ہے؟ مفت کال سے معلوم ہو جائے گا۔")}{" "}
            <a href="#audit" style={{ color: "var(--ss-ink)", textDecoration: "underline", textUnderlineOffset: 4, fontStyle: "normal", fontWeight: 500 }}>
              {t("Book a free call", "مفت کال بک کریں")}
            </a>
          </p>
        </FadeSlide>
      </div>

      <style>{`
        .ss-pricing-bento {
          margin-top: 64px;
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
          align-items: stretch;
        }
        @media (max-width: 960px) {
          .ss-pricing-bento { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  );
}
