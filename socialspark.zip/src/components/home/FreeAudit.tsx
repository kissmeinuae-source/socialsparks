import { useState, type FormEvent } from "react";
import { z } from "zod";
import { useServerFn } from "@tanstack/react-start";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";
import { submitLead } from "@/lib/leads.functions";
import { HONEYPOT_FIELD, honeypotInputProps, honeypotStyle } from "@/lib/honeypot";

const auditSchema = z.object({
  business: z.string().trim().nonempty({ message: "Business name is required" }).max(100),
  social: z.string().trim().nonempty({ message: "Social URL is required" }).max(255),
  email: z.string().trim().email({ message: "Invalid email" }).max(255),
});

const inputStyle: React.CSSProperties = {
  width: "100%",
  backgroundColor: "var(--ss-cream)",
  border: "1px solid var(--ss-line)",
  borderRadius: "var(--radius-input)",
  padding: "14px 16px",
  fontFamily: "var(--font-sans)",
  fontSize: 14,
  color: "var(--ss-ink)",
  outline: "none",
  transition: "border-color 180ms ease, background-color 180ms ease",
};

export function FreeAudit() {
  const { t } = useLanguage();
  const submit = useServerFn(submitLead);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = {
      business: (form.elements.namedItem("business") as HTMLInputElement).value,
      social: (form.elements.namedItem("social") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
    };
    const result = auditSchema.safeParse(data);
    if (!result.success) {
      const next: Record<string, string> = {};
      for (const issue of result.error.issues) next[issue.path[0] as string] = issue.message;
      setErrors(next);
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      await submit({
        data: {
          type: "audit",
          email: data.email,
          business: data.business,
          social_url: data.social,
          source_page: typeof window !== "undefined" ? window.location.pathname : null,
          website_url: (form.elements.namedItem(HONEYPOT_FIELD) as HTMLInputElement | null)?.value ?? null,
        },
      });
      setSubmitted(true);
    } catch (err) {
      setErrors({ business: err instanceof Error ? err.message : "Submission failed. Please try again." });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="audit" style={{ backgroundColor: "var(--ss-cream)", padding: "112px 24px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div className="ss-audit-bento">
          {/* LEFT — yellow editorial tile */}
          <FadeSlide>
            <div className="tile tile-yellow" style={{ padding: "48px 44px", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", minHeight: 520 }}>
              <div>
                <span className="t-eyebrow" style={{ color: "rgba(14,27,61,0.65)" }}>
                  {t("Limited time", "محدود وقت")}
                </span>
                <h2 style={{ margin: "18px 0 20px", fontStyle: "italic", color: "var(--ss-ink)" }}>
                  {t("A free audit, ", "ایک مفت آڈٹ، ")}
                  <span style={{ fontStyle: "normal" }}>{t("on the house.", "بالکل مفت۔")}</span>
                </h2>
                <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: 16, lineHeight: 1.7, color: "rgba(14,27,61,0.8)", maxWidth: 460 }}>
                  {t(
                    "We record a personalised Loom of your social pages — what's working, what isn't, what to fix. No charge, no obligation, no sales call unless you ask.",
                    "ہم آپ کے سوشل پیجز کی ذاتی Loom ویڈیو ریکارڈ کرتے ہیں — کیا کام کر رہا ہے، کیا نہیں۔ کوئی فیس، کوئی ذمہ داری نہیں۔",
                  )}
                </p>
              </div>
              <ul style={{ listStyle: "none", margin: "40px 0 0", padding: 0, display: "flex", flexDirection: "column", gap: 14 }}>
                {[
                  t("Delivered within 24 hours", "24 گھنٹوں میں فراہم"),
                  t("Covers Instagram, Facebook & Google", "انسٹاگرام، فیس بک اور گوگل"),
                  t("200+ audits completed", "200+ آڈٹس مکمل"),
                ].map((line) => (
                  <li key={line} style={{ display: "flex", alignItems: "center", gap: 12, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-ink)" }}>
                    <span aria-hidden style={{ width: 18, height: 18, borderRadius: 9999, background: "var(--ss-ink)", color: "var(--ss-gold)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>✓</span>
                    {line}
                  </li>
                ))}
              </ul>
            </div>
          </FadeSlide>

          {/* RIGHT — form tile */}
          <FadeSlide delay={120}>
            {submitted ? (
              <div className="tile" style={{ padding: 56, textAlign: "center", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 520 }}>
                <div aria-hidden style={{ width: 64, height: 64, borderRadius: "50%", backgroundColor: "var(--ss-gold)", display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 24 }}>
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
                    <path d="M5 12l5 5 9-11" stroke="var(--ss-ink)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <h3 style={{ margin: "0 0 10px", fontStyle: "italic" }}>{t("Audit requested.", "آڈٹ کی درخواست موصول۔")}</h3>
                <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--ss-slate)" }}>
                  {t("Check your inbox within 24 hours.", "24 گھنٹوں میں اپنا ان باکس چیک کریں۔")}
                </p>
              </div>
            ) : (
              <div className="tile" style={{ padding: 44, height: "100%", display: "flex", flexDirection: "column", minHeight: 520 }}>
                <span className="t-eyebrow">{t("Request your audit", "اپنا آڈٹ منگوائیں")}</span>
                <h3 style={{ margin: "10px 0 28px", fontStyle: "italic" }}>{t("Three fields. That's it.", "تین خانے۔ بس۔")}</h3>
                <form onSubmit={onSubmit} noValidate style={{ display: "flex", flexDirection: "column", gap: 16, flex: 1 }}>
                  <input {...honeypotInputProps} style={honeypotStyle} defaultValue="" />
                  {[
                    { name: "business", placeholder: t("Business name", "کاروبار کا نام"), type: "text", maxLength: 100 },
                    { name: "social", placeholder: t("Social page URL", "سوشل پیج کا URL"), type: "text", maxLength: 255 },
                    { name: "email", placeholder: t("Email address", "ای میل ایڈریس"), type: "email", maxLength: 255 },
                  ].map((f) => (
                    <div key={f.name}>
                      <label style={{ display: "block", fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ss-ash)", marginBottom: 8 }}>
                        {f.placeholder}
                      </label>
                      <input
                        name={f.name}
                        type={f.type}
                        placeholder={f.placeholder}
                        maxLength={f.maxLength}
                        aria-label={f.placeholder}
                        aria-invalid={!!errors[f.name]}
                        className="ss-audit-input"
                        style={inputStyle}
                      />
                      {errors[f.name] && (
                        <div role="alert" style={{ marginTop: 6, fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--ss-gold-dim)" }}>
                          {errors[f.name]}
                        </div>
                      )}
                    </div>
                  ))}
                  <button type="submit" disabled={submitting} className="btn-primary" style={{ marginTop: "auto", justifyContent: "center", width: "100%", opacity: submitting ? 0.7 : 1, cursor: submitting ? "wait" : "pointer" }}>
                    {submitting ? t("Sending…", "بھیج رہا ہے…") : t("Request my free audit", "میرا مفت آڈٹ بھیجیں")}
                    {!submitting && <span aria-hidden>→</span>}
                  </button>
                </form>
              </div>
            )}
          </FadeSlide>
        </div>
      </div>

      <style>{`
        .ss-audit-bento {
          display: grid;
          grid-template-columns: 1.1fr 1fr;
          gap: 16px;
          align-items: stretch;
        }
        .ss-audit-input:focus {
          border-color: var(--ss-ink) !important;
          background-color: #fff !important;
        }
        @media (max-width: 960px) {
          .ss-audit-bento { grid-template-columns: 1fr; }
        }
      `}</style>
    </section>
  );
}
