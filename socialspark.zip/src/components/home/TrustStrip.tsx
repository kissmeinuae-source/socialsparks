import { useLanguage } from "@/lib/language";

const clients = [
  { name: "Waseem Badami", role: { en: "Prime-time News Anchor", ur: "پرائم ٹائم اینکر" }, featured: true },
  { name: "Tandoor Tales", role: { en: "Heritage Restaurant Group", ur: "ہیریٹیج ریسٹورنٹ گروپ" } },
  { name: "Dr. Rania", role: { en: "Aesthetic Clinic, Islamabad", ur: "کاسمیٹک کلینک، اسلام آباد" } },
  { name: "Ahmed Khan", role: { en: "Cricket Personality", ur: "کرکٹ شخصیت" } },
  { name: "Velour Salon", role: { en: "Premium Salon, DHA", ur: "پریمیم سیلون، ڈی ایچ اے" } },
  { name: "Lahore Co.", role: { en: "D2C Lifestyle Brand", ur: "ڈی ٹو سی لائف اسٹائل" } },
];

const metrics: Array<{ k: string; v: [string, string] }> = [
  { k: "50+", v: ["Brands trusted us this year", "اس سال 50 سے زائد برانڈز"] },
  { k: "8",   v: ["Industries served end-to-end", "8 صنعتوں میں خدمات"] },
  { k: "94%", v: ["Of clients renew after month 3", "تیسرے ماہ کے بعد دوبارہ معاہدہ"] },
  { k: "0",   v: ["PR incidents on managed pages", "زیرِ انتظام صفحات پر صفر بحران"] },
];

export function TrustStrip() {
  const { lang, t } = useLanguage();
  return (
    <section
      id="clients"
      className="bg-cream"
      style={{ paddingBlock: "clamp(72px, 9vw, 120px)" }}
    >
      <div className="mx-auto max-w-[1280px] px-6 md:px-10">
        <div className="grid gap-10 md:grid-cols-[1fr_2fr] md:gap-16 items-end">
          {/* Header */}
          <div>
            <p className="t-eyebrow mb-5">
              {t("Trusted by", "اعتماد")}
            </p>
            <h2
              className="display-italic"
              style={{
                fontStyle: "italic",
                fontSize: "clamp(2.25rem, 1.6rem + 2.8vw, 3.75rem)",
                lineHeight: 1,
                color: "var(--ss-ink)",
              }}
            >
              {t("People who shape", "رائے ساز")}
              <br />
              {t("the room.", "افراد۔")}
            </h2>
            <p
              style={{
                marginTop: 22,
                maxWidth: 360,
                fontFamily: "var(--font-sans)",
                fontSize: 15,
                lineHeight: 1.65,
                color: "var(--ss-slate)",
              }}
            >
              {t(
                "Anchors, founders, doctors and chefs across Pakistan trust one in-house team with the rooms they live in.",
                "پاکستان بھر کے اینکرز، بانیوں، ڈاکٹرز اور شیفس — سب ایک ہی اِن ہاؤس ٹیم پر اعتماد کرتے ہیں۔",
              )}
            </p>
          </div>

          {/* Client grid as bento mini-tiles */}
          <ul className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {clients.map((c) => (
              <li
                key={c.name}
                className={c.featured ? "tile tile-navy" : "tile"}
                style={{
                  padding: "20px 18px",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  minHeight: 110,
                  borderRadius: 18,
                }}
              >
                <div className="flex items-center justify-between">
                  <span
                    style={{
                      fontFamily: "var(--font-sans)",
                      fontWeight: 600,
                      fontSize: 14,
                      letterSpacing: "-0.01em",
                      color: c.featured ? "#fff" : "var(--ss-ink)",
                    }}
                  >
                    {c.name}
                  </span>
                  {c.featured && (
                    <span
                      aria-label="Featured client"
                      style={{
                        width: 18,
                        height: 18,
                        borderRadius: 9999,
                        background: "var(--ss-gold)",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "var(--ss-ink)",
                        fontSize: 11,
                        fontWeight: 700,
                      }}
                    >
                      ✓
                    </span>
                  )}
                </div>
                <span
                  className={lang === "ur" ? "urdu" : ""}
                  style={{
                    fontSize: 12,
                    color: c.featured ? "rgba(255,255,255,0.65)" : "var(--ss-ash)",
                    marginTop: 8,
                  }}
                >
                  {lang === "en" ? c.role.en : c.role.ur}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Trust metrics ribbon */}
        <ul
          className="ss-trust-metrics"
          style={{
            marginTop: "clamp(48px, 6vw, 72px)",
            paddingTop: "clamp(32px, 4vw, 48px)",
            borderTop: "1px solid var(--ss-rule)",
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 24,
            listStyle: "none",
          }}
        >
          {metrics.map((m) => (
            <li key={m.k} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <span
                style={{
                  fontFamily: "var(--font-display)",
                  fontStyle: "italic",
                  fontSize: "clamp(2rem, 3.5vw, 2.75rem)",
                  lineHeight: 1,
                  letterSpacing: "-0.02em",
                  color: "var(--ss-ink)",
                }}
              >
                {m.k}
              </span>
              <span
                className={lang === "ur" ? "urdu" : ""}
                style={{
                  fontFamily: "var(--font-sans)",
                  fontSize: 13,
                  lineHeight: 1.55,
                  color: "var(--ss-slate)",
                  maxWidth: 200,
                }}
              >
                {lang === "en" ? m.v[0] : m.v[1]}
              </span>
            </li>
          ))}
        </ul>
      </div>

      <style>{`
        @media (max-width: 720px) {
          .ss-trust-metrics { grid-template-columns: 1fr 1fr !important; }
        }
      `}</style>
    </section>
  );
}
