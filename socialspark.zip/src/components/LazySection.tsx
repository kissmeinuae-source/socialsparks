import { Suspense, type ReactNode } from "react";

/**
 * Wraps a lazy-loaded section with a min-height placeholder to keep CLS at 0
 * while the chunk streams in. The placeholder matches the cream background
 * so it's invisible to the user during normal scroll.
 */
export function LazySection({
  children,
  minHeight = 400,
}: {
  children: ReactNode;
  minHeight?: number;
}) {
  return (
    <Suspense
      fallback={
        <div
          aria-hidden="true"
          style={{ minHeight: `${minHeight}px` }}
          className="bg-cream"
        />
      }
    >
      {children}
    </Suspense>
  );
}
