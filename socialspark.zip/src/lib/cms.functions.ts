import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

// ============================================================
// Public read clients (anon key, narrow public SELECT policies)
// ============================================================
function publicClient() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

async function assertAdmin(ctx: { supabase: ReturnType<typeof publicClient>; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role: "admin" });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden — admins only");
}

// ============================================================
// TESTIMONIALS
// ============================================================
export const listPublishedTestimonials = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const { data, error } = await sb
    .from("testimonials")
    .select("id, name, role_en, role_ur, company, quote_en, quote_ur, avatar_url, rating, featured, sort_order")
    .eq("published", true)
    .order("featured", { ascending: false })
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const listAllTestimonials = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { data, error } = await context.supabase
      .from("testimonials")
      .select("*")
      .order("sort_order", { ascending: true })
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const testimonialUpsertSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(1).max(160),
  role_en: z.string().trim().max(160).optional().nullable(),
  role_ur: z.string().trim().max(160).optional().nullable(),
  company: z.string().trim().max(160).optional().nullable(),
  quote_en: z.string().trim().min(1).max(1200),
  quote_ur: z.string().trim().max(1200).optional().nullable(),
  avatar_url: z.string().trim().url().max(500).optional().nullable().or(z.literal("")),
  rating: z.number().int().min(1).max(5).default(5),
  featured: z.boolean().default(false),
  published: z.boolean().default(true),
  sort_order: z.number().int().default(0),
});

export const upsertTestimonial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof testimonialUpsertSchema>) => testimonialUpsertSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const row = { ...data, avatar_url: data.avatar_url || null };
    const { data: result, error } = await context.supabase
      .from("testimonials")
      .upsert(row)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return result;
  });

export const deleteTestimonial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { error } = await context.supabase.from("testimonials").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============================================================
// SITE SETTINGS (key/value JSONB store)
// ============================================================
export const listSiteSettings = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const { data, error } = await sb.from("site_settings").select("key, value, description, updated_at");
  if (error) throw new Error(error.message);
  return data ?? [];
});

const settingsUpsertSchema = z.object({
  key: z.string().trim().min(1).max(80),
  value: z.record(z.string(), z.unknown()),
  description: z.string().trim().max(400).optional().nullable(),
});

export const upsertSiteSetting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof settingsUpsertSchema>) => settingsUpsertSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { data: result, error } = await context.supabase
      .from("site_settings")
      .upsert({
        key: data.key,
        value: data.value as never,
        description: data.description ?? null,
        updated_by: context.userId,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return result;
  });

// ============================================================
// SERVICES
// ============================================================
export const listPublishedServices = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const { data, error } = await sb
    .from("services")
    .select("id, slug, title_en, title_ur, summary_en, summary_ur, body_en, body_ur, icon, sort_order")
    .eq("published", true)
    .order("sort_order", { ascending: true });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const listAllServices = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { data, error } = await context.supabase
      .from("services").select("*").order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const serviceUpsertSchema = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().trim().min(1).max(80).regex(/^[a-z0-9-]+$/, "lowercase letters, numbers, hyphens"),
  title_en: z.string().trim().min(1).max(160),
  title_ur: z.string().trim().max(160).optional().nullable(),
  summary_en: z.string().trim().max(600).optional().nullable(),
  summary_ur: z.string().trim().max(600).optional().nullable(),
  body_en: z.string().trim().max(4000).optional().nullable(),
  body_ur: z.string().trim().max(4000).optional().nullable(),
  icon: z.string().trim().max(40).optional().nullable(),
  published: z.boolean().default(true),
  sort_order: z.number().int().default(0),
});

export const upsertService = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof serviceUpsertSchema>) => serviceUpsertSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { data: result, error } = await context.supabase.from("services").upsert(data).select().single();
    if (error) throw new Error(error.message);
    return result;
  });

export const deleteService = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { error } = await context.supabase.from("services").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============================================================
// PRICING PLANS
// ============================================================
export const listPublishedPricingPlans = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const { data, error } = await sb
    .from("pricing_plans")
    .select("id, slug, name_en, name_ur, tagline_en, tagline_ur, price_pkr, period, features, highlighted, sort_order")
    .eq("published", true)
    .order("sort_order", { ascending: true });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const listAllPricingPlans = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { data, error } = await context.supabase
      .from("pricing_plans").select("*").order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const featurePairSchema = z.object({
  en: z.string().trim().min(1).max(200),
  ur: z.string().trim().max(200).optional().nullable(),
});

const pricingUpsertSchema = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().trim().min(1).max(80).regex(/^[a-z0-9-]+$/),
  name_en: z.string().trim().min(1).max(120),
  name_ur: z.string().trim().max(120).optional().nullable(),
  tagline_en: z.string().trim().max(300).optional().nullable(),
  tagline_ur: z.string().trim().max(300).optional().nullable(),
  price_pkr: z.number().int().min(0),
  period: z.string().trim().min(1).max(20).default("mo"),
  features: z.array(featurePairSchema).default([]),
  highlighted: z.boolean().default(false),
  published: z.boolean().default(true),
  sort_order: z.number().int().default(0),
});

export const upsertPricingPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof pricingUpsertSchema>) => pricingUpsertSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const row = { ...data, features: data.features as never };
    const { data: result, error } = await context.supabase.from("pricing_plans").upsert(row).select().single();
    if (error) throw new Error(error.message);
    return result;
  });

export const deletePricingPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { error } = await context.supabase.from("pricing_plans").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============================================================
// BLOG POSTS
// ============================================================
export const listPublishedPosts = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const { data, error } = await sb
    .from("blog_posts")
    .select("id, slug, category, title_en, title_ur, excerpt_en, excerpt_ur, cover_image_url, author_name, read_time, published_at, featured, sort_order")
    .eq("published", true)
    .order("featured", { ascending: false })
    .order("sort_order", { ascending: true })
    .order("published_at", { ascending: false, nullsFirst: false })
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const getPostBySlug = createServerFn({ method: "GET" })
  .inputValidator((d: { slug: string }) => z.object({ slug: z.string().trim().min(1).max(160) }).parse(d))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: row, error } = await sb
      .from("blog_posts")
      .select("*")
      .eq("slug", data.slug)
      .eq("published", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });

export const listAllPosts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { data, error } = await context.supabase
      .from("blog_posts").select("*")
      .order("published_at", { ascending: false, nullsFirst: false })
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const blogUpsertSchema = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().trim().min(1).max(160).regex(/^[a-z0-9-]+$/, "lowercase letters, numbers, hyphens"),
  category: z.string().trim().min(1).max(60).default("GENERAL"),
  title_en: z.string().trim().min(1).max(240),
  title_ur: z.string().trim().max(240).optional().nullable(),
  excerpt_en: z.string().trim().max(600).default(""),
  excerpt_ur: z.string().trim().max(600).optional().nullable(),
  body_en: z.string().trim().max(80000).default(""),
  body_ur: z.string().trim().max(80000).optional().nullable(),
  cover_image_url: z.string().trim().url().max(500).optional().nullable().or(z.literal("")),
  author_name: z.string().trim().min(1).max(120).default("Social Spark Team"),
  read_time: z.string().trim().min(1).max(40).default("5 min read"),
  seo_title: z.string().trim().max(180).optional().nullable(),
  seo_description: z.string().trim().max(320).optional().nullable(),
  og_image_url: z.string().trim().url().max(500).optional().nullable().or(z.literal("")),
  published: z.boolean().default(false),
  published_at: z.string().datetime().optional().nullable(),
  featured: z.boolean().default(false),
  sort_order: z.number().int().default(0),
});

export const upsertPost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof blogUpsertSchema>) => blogUpsertSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const row = {
      ...data,
      cover_image_url: data.cover_image_url || null,
      og_image_url: data.og_image_url || null,
      published_at: data.published
        ? (data.published_at ?? new Date().toISOString())
        : (data.published_at ?? null),
    };
    const { data: result, error } = await context.supabase.from("blog_posts").upsert(row).select().single();
    if (error) throw new Error(error.message);
    return result;
  });

export const deletePost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { error } = await context.supabase.from("blog_posts").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

