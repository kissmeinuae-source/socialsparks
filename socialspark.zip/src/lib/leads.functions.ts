import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader, getRequestIP } from "@tanstack/react-start/server";
import { createHash } from "crypto";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

// ---- Public: submit a lead from any form on the site ----

const leadInputSchema = z.object({
  type: z.enum(["audit", "book", "contact", "chat"]),
  name: z.string().trim().max(200).optional().nullable(),
  email: z.string().trim().email().max(320).optional().nullable(),
  phone: z.string().trim().max(32).optional().nullable(),
  business: z.string().trim().max(200).optional().nullable(),
  social_url: z.string().trim().max(500).optional().nullable(),
  message: z.string().trim().max(4000).optional().nullable(),
  source_page: z.string().trim().max(500).optional().nullable(),
  // Honeypot — real users leave this blank; bots fill it in.
  website_url: z.string().max(500).optional().nullable(),
});

// In-memory IP rate limiter (per worker isolate). Best-effort — not a hard guarantee.
const RL_WINDOW_MS = 60_000;
const RL_MAX = 5;
const ipHits = new Map<string, number[]>();
function rateLimited(key: string): boolean {
  const now = Date.now();
  const hits = (ipHits.get(key) ?? []).filter((t) => now - t < RL_WINDOW_MS);
  hits.push(now);
  ipHits.set(key, hits);
  if (ipHits.size > 5000) {
    // simple GC
    for (const [k, v] of ipHits) if (!v.length || now - v[v.length - 1] > RL_WINDOW_MS) ipHits.delete(k);
  }
  return hits.length > RL_MAX;
}

async function notifyAdminsOfNewLead(payload: {
  id: string;
  type: string;
  name?: string | null;
  email?: string | null;
  phone?: string | null;
  business?: string | null;
  social_url?: string | null;
  message?: string | null;
  source_page?: string | null;
}) {
  const RESEND_API_KEY = process.env.RESEND_API_KEY;
  const NOTIFY_TO = process.env.LEAD_NOTIFY_TO; // comma separated
  const NOTIFY_FROM = process.env.LEAD_NOTIFY_FROM ?? "Social Spark <onboarding@resend.dev>";
  if (!RESEND_API_KEY || !NOTIFY_TO) return; // soft no-op until configured
  const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
  if (!LOVABLE_API_KEY) return;

  const rows: Array<[string, string | null | undefined]> = [
    ["Type", payload.type],
    ["Name", payload.name],
    ["Email", payload.email],
    ["Phone", payload.phone],
    ["Business", payload.business],
    ["Social URL", payload.social_url],
    ["Source page", payload.source_page],
    ["Message", payload.message],
  ];
  const html = `
    <div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#F4EFE6;padding:32px">
      <div style="max-width:560px;margin:0 auto;background:#fff;border-radius:16px;padding:32px;box-shadow:0 6px 24px rgba(0,0,0,.06)">
        <div style="font:600 12px/1 system-ui;letter-spacing:.14em;color:#9AA0A6;text-transform:uppercase">Social Spark · New lead</div>
        <h1 style="font-family:Georgia,serif;font-style:italic;font-size:28px;color:#0E1B3D;margin:14px 0 22px">A new lead just landed.</h1>
        <table style="width:100%;border-collapse:collapse;font-size:14px;color:#0E1B3D">
          ${rows
            .filter(([, v]) => v && String(v).trim())
            .map(
              ([k, v]) =>
                `<tr><td style="padding:8px 0;color:#6B7280;width:120px;vertical-align:top">${k}</td><td style="padding:8px 0">${String(v).replace(/[<>]/g, "")}</td></tr>`,
            )
            .join("")}
        </table>
        <div style="margin-top:28px;padding-top:20px;border-top:1px solid #EEE;font-size:12px;color:#9AA0A6">Lead ID: ${payload.id}</div>
      </div>
    </div>`;

  try {
    await fetch("https://connector-gateway.lovable.dev/resend/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "X-Connection-Api-Key": RESEND_API_KEY,
      },
      body: JSON.stringify({
        from: NOTIFY_FROM,
        to: NOTIFY_TO.split(",").map((s) => s.trim()).filter(Boolean),
        subject: `New ${payload.type} lead${payload.business ? ` — ${payload.business}` : ""}`,
        html,
      }),
    });
  } catch (err) {
    console.error("[notifyAdminsOfNewLead] failed", err);
  }
}

export const submitLead = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => leadInputSchema.parse(data))
  .handler(async ({ data }) => {
    // Honeypot — silently accept-and-drop so bots think they succeeded.
    if (data.website_url && data.website_url.trim().length > 0) {
      return { id: "ok", ok: true as const };
    }
    if (!data.email && !data.phone) {
      throw new Error("Please provide an email or phone number.");
    }

    let ipForLimit: string | null = null;
    try { ipForLimit = getRequestIP({ xForwardedFor: true }) ?? null; } catch {}
    if (ipForLimit && rateLimited(`lead:${ipForLimit}`)) {
      throw new Error("Too many submissions. Please try again in a minute.");
    }

    const SUPABASE_URL = process.env.SUPABASE_URL!;
    const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY!;
    const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    });

    let ip_hash: string | null = null;
    try {
      const ip = getRequestIP({ xForwardedFor: true });
      if (ip) ip_hash = createHash("sha256").update(ip + (process.env.SUPABASE_URL ?? "")).digest("hex").slice(0, 32);
    } catch {}
    const user_agent = (() => {
      try { return getRequestHeader("user-agent") ?? null; } catch { return null; }
    })();

    const { data: inserted, error } = await supabase
      .from("leads")
      .insert({
        type: data.type,
        name: data.name ?? null,
        email: data.email ?? null,
        phone: data.phone ?? null,
        business: data.business ?? null,
        social_url: data.social_url ?? null,
        message: data.message ?? null,
        source_page: data.source_page ?? null,
        ip_hash,
        user_agent,
      })
      .select("id")
      .single();

    if (error) {
      console.error("[submitLead] insert failed", error);
      throw new Error("We couldn't save your request. Please try again.");
    }

    // Fire-and-forget notification + automations (won't block response)
    notifyAdminsOfNewLead({ id: inserted.id, ...data }).catch(() => {});
    import("./automations.server")
      .then((m) => m.runOnLeadCreated(inserted.id))
      .catch((err) => console.error("[submitLead] automations failed", err));

    return { id: inserted.id, ok: true as const };
  });

// ---- Admin/team: list leads with filters ----

export const listLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        status: z.string().optional(),
        type: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().int().min(1).max(500).default(200),
      })
      .parse(data ?? {}),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("leads")
      .select("id,type,name,email,phone,business,message,status,source_page,created_at,assigned_to")
      .order("created_at", { ascending: false })
      .limit(data.limit);

    if (data.status && data.status !== "all") q = q.eq("status", data.status);
    if (data.type && data.type !== "all") q = q.eq("type", data.type as Database["public"]["Enums"]["lead_type"]);
    if (data.search && data.search.trim()) {
      const s = `%${data.search.trim()}%`;
      q = q.or(`name.ilike.${s},email.ilike.${s},phone.ilike.${s},business.ilike.${s}`);
    }

    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

// ---- Admin/team: single lead with activity ----

export const getLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ leadId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const [{ data: lead, error: e1 }, { data: activity, error: e2 }] = await Promise.all([
      context.supabase.from("leads").select("*").eq("id", data.leadId).maybeSingle(),
      context.supabase
        .from("lead_activity")
        .select("id,kind,content,actor_id,created_at")
        .eq("lead_id", data.leadId)
        .order("created_at", { ascending: false }),
    ]);
    if (e1) throw new Error(e1.message);
    if (e2) throw new Error(e2.message);
    if (!lead) throw new Error("Lead not found");
    return { lead, activity: activity ?? [] };
  });

// ---- Admin/team: add a note to a lead ----

export const addLeadNote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ leadId: z.string().uuid(), note: z.string().trim().min(1).max(2000) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("lead_activity").insert({
      lead_id: data.leadId,
      actor_id: context.userId,
      kind: "note",
      content: data.note,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

// ---- Admin/team: update lead status ----

export const updateLeadStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        leadId: z.string().uuid(),
        status: z.enum(["new", "contacted", "qualified", "won", "lost"]),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("leads")
      .update({ status: data.status })
      .eq("id", data.leadId);
    if (error) throw new Error(error.message);

    await context.supabase.from("lead_activity").insert({
      lead_id: data.leadId,
      actor_id: context.userId,
      kind: "status_change",
      content: `Status changed to ${data.status}`,
    });

    return { ok: true as const };
  });

// ---- Admin/team: dashboard stats ----

export const getDashboardStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const [total, last30, byStatus] = await Promise.all([
      context.supabase.from("leads").select("id", { count: "exact", head: true }),
      context.supabase.from("leads").select("id", { count: "exact", head: true }).gte("created_at", since),
      context.supabase.from("leads").select("status"),
    ]);

    const counts: Record<string, number> = { new: 0, contacted: 0, qualified: 0, won: 0, lost: 0 };
    for (const row of byStatus.data ?? []) counts[row.status] = (counts[row.status] ?? 0) + 1;

    return {
      total: total.count ?? 0,
      last30: last30.count ?? 0,
      byStatus: counts,
    };
  });

// ---- Current user: get my role ----

export const getMyRole = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId);
    if (error) return { roles: [] as string[] };
    return { roles: (data ?? []).map((r) => r.role as string) };
  });
