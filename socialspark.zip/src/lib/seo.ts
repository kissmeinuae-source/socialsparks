// Centralized SEO helpers. Set VITE_SITE_URL once a production domain is live;
// until then absolute() returns relative URLs which crawlers resolve at request time.
export const SITE_URL: string =
  (typeof import.meta !== "undefined" && (import.meta as { env?: { VITE_SITE_URL?: string } }).env?.VITE_SITE_URL) || "";

export function absolute(path: string): string {
  if (!path) return SITE_URL || "/";
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  const p = path.startsWith("/") ? path : `/${path}`;
  return SITE_URL ? `${SITE_URL.replace(/\/$/, "")}${p}` : p;
}

type FAQ = { q: string; a: string };

export function faqPageSchema(faqs: FAQ[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: absolute(it.path),
    })),
  };
}

export function serviceSchema(input: {
  name: string;
  description: string;
  path: string;
  price?: string;
  priceCurrency?: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name: input.name,
    description: input.description,
    url: absolute(input.path),
    provider: {
      "@type": "LocalBusiness",
      name: "Social Spark",
      url: absolute("/"),
      address: {
        "@type": "PostalAddress",
        addressLocality: "Lahore",
        addressRegion: "Punjab",
        addressCountry: "PK",
      },
    },
    areaServed: { "@type": "Country", name: "Pakistan" },
    ...(input.price
      ? {
          offers: {
            "@type": "Offer",
            price: input.price,
            priceCurrency: input.priceCurrency ?? "PKR",
          },
        }
      : {}),
  };
}

export function articleSchema(input: {
  headline: string;
  description?: string;
  image?: string;
  path: string;
  datePublished?: string | null;
  dateModified?: string | null;
  authorName?: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: input.headline,
    description: input.description,
    image: input.image ? [absolute(input.image)] : undefined,
    mainEntityOfPage: { "@type": "WebPage", "@id": absolute(input.path) },
    datePublished: input.datePublished ?? undefined,
    dateModified: input.dateModified ?? input.datePublished ?? undefined,
    author: { "@type": "Organization", name: input.authorName ?? "Social Spark" },
    publisher: {
      "@type": "Organization",
      name: "Social Spark",
      logo: { "@type": "ImageObject", url: absolute("/logo.png") },
    },
  };
}

export function organizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Social Spark",
    url: absolute("/"),
    logo: absolute("/logo.png"),
    sameAs: [
      "https://instagram.com/socialspark",
      "https://facebook.com/socialspark",
      "https://linkedin.com/company/socialspark",
    ],
  };
}
