import type { ReactNode } from "react";

/**
 * Minimal, dependency-free markdown renderer:
 * - `## ` lines → <h2>
 * - `### ` lines → <h3>
 * - Blank line → paragraph break
 * - Single newlines inside a paragraph are preserved as <br />
 *
 * Sufficient for the long-form blog body editor (the heavy MDX/MD
 * libraries are too costly for the edge bundle for this use case).
 */
export function renderMarkdown(src: string): ReactNode[] {
  const blocks = src.replace(/\r\n/g, "\n").trim().split(/\n{2,}/);
  return blocks.map((raw, i) => {
    const block = raw.trim();
    if (!block) return null;
    if (block.startsWith("## ")) {
      return (
        <h2
          key={i}
          className="text-navy"
          style={{
            marginTop: 56,
            marginBottom: 16,
            fontFamily: "var(--font-serif, var(--font-display))",
            fontStyle: "italic",
            fontWeight: 500,
            fontSize: 30,
            lineHeight: 1.2,
          }}
        >
          {block.slice(3)}
        </h2>
      );
    }
    if (block.startsWith("### ")) {
      return (
        <h3
          key={i}
          className="text-navy"
          style={{
            marginTop: 36,
            marginBottom: 12,
            fontFamily: "var(--font-sans)",
            fontWeight: 700,
            fontSize: 20,
            lineHeight: 1.3,
          }}
        >
          {block.slice(4)}
        </h3>
      );
    }
    const lines = block.split("\n");
    return (
      <p key={i} style={{ marginBottom: 20 }}>
        {lines.map((line, j) => (
          <span key={j}>
            {line}
            {j < lines.length - 1 && <br />}
          </span>
        ))}
      </p>
    );
  });
}
