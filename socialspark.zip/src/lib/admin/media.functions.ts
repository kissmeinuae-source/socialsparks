import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        search: z.string().optional(),
        tag: z.string().optional(),
        type: z.enum(["all", "image", "video", "pdf", "other"]).default("all"),
        minSize: z.number().int().min(0).optional(), // bytes
        maxSize: z.number().int().min(0).optional(), // bytes
        from: z.string().datetime().optional(),       // ISO
        to: z.string().datetime().optional(),         // ISO
        page: z.number().int().min(1).default(1),
        pageSize: z.number().int().min(1).max(200).default(48),
        // legacy: callers passing only `limit` still work
        limit: z.number().int().min(1).max(500).optional(),
      })
      .parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    const pageSize = data.limit ?? data.pageSize;
    const page = data.limit ? 1 : data.page;
    const offset = (page - 1) * pageSize;

    let q = context.supabase
      .from("media_assets")
      .select("*", { count: "exact" })
      .order("created_at", { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (data.search?.trim()) q = q.ilike("filename", `%${data.search.trim()}%`);
    if (data.tag?.trim()) q = q.contains("tags", [data.tag.trim()]);

    switch (data.type) {
      case "image": q = q.like("mime_type", "image/%"); break;
      case "video": q = q.like("mime_type", "video/%"); break;
      case "pdf":   q = q.eq("mime_type", "application/pdf"); break;
      case "other":
        q = q
          .not("mime_type", "like", "image/%")
          .not("mime_type", "like", "video/%")
          .neq("mime_type", "application/pdf");
        break;
    }

    if (typeof data.minSize === "number") q = q.gte("size_bytes", data.minSize);
    if (typeof data.maxSize === "number") q = q.lte("size_bytes", data.maxSize);
    if (data.from) q = q.gte("created_at", data.from);
    if (data.to)   q = q.lte("created_at", data.to);

    const { data: rows, error, count } = await q;
    if (error) throw new Error(error.message);
    return { rows: rows ?? [], total: count ?? 0, page, pageSize };
  });


export const registerMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        storage_path: z.string().min(1),
        filename: z.string().min(1).max(300),
        mime_type: z.string().optional(),
        size_bytes: z.number().int().optional(),
        width: z.number().int().optional(),
        height: z.number().int().optional(),
        alt: z.string().max(300).optional(),
        tags: z.array(z.string()).default([]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("media_assets")
      .insert({
        ...data,
        url: data.storage_path,
        uploaded_by: context.userId,
      })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        alt: z.string().max(300).nullable().optional(),
        tags: z.array(z.string()).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const patch: { alt?: string | null; tags?: string[] } = {};
    if (data.alt !== undefined) patch.alt = data.alt;
    if (data.tags !== undefined) patch.tags = data.tags;
    const { error } = await context.supabase.from("media_assets").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const deleteMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: row } = await context.supabase
      .from("media_assets")
      .select("storage_path")
      .eq("id", data.id)
      .maybeSingle();
    if (row?.storage_path) {
      await context.supabase.storage.from("media").remove([row.storage_path]);
    }
    const { error } = await context.supabase.from("media_assets").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
