import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listActivity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        entity_type: z.string().optional(),
        entity_id: z.string().optional(),
        limit: z.number().int().min(1).max(200).default(60),
      })
      .parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("activity_log")
      .select("id, entity_type, entity_id, action, actor_id, diff, created_at")
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.entity_type) q = q.eq("entity_type", data.entity_type);
    if (data.entity_id) q = q.eq("entity_id", data.entity_id);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const logActivity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        entity_type: z.string().min(1).max(40),
        entity_id: z.string().min(1).max(80),
        action: z.string().min(1).max(60),
        diff: z.record(z.any()).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("activity_log").insert({
      entity_type: data.entity_type,
      entity_id: data.entity_id,
      action: data.action,
      diff: data.diff ?? null,
      actor_id: context.userId,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
