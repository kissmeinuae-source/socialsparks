import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listInbox = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        channel: z.string().optional(),
        leadId: z.string().uuid().optional(),
        limit: z.number().int().min(1).max(300).default(120),
      })
      .parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("inbox_messages")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.channel && data.channel !== "all") q = q.eq("channel", data.channel);
    if (data.leadId) q = q.eq("lead_id", data.leadId);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const postInboxNote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        leadId: z.string().uuid().optional(),
        channel: z.enum(["note", "email", "whatsapp", "form", "chat"]).default("note"),
        subject: z.string().max(200).optional(),
        body: z.string().trim().min(1).max(8000),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("inbox_messages").insert({
      lead_id: data.leadId ?? null,
      channel: data.channel,
      direction: "out",
      subject: data.subject ?? null,
      body: data.body,
      sent_by: context.userId,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
