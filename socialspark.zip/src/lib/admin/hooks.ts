import { useCallback, useEffect, useMemo, useRef, useState } from "react";

/** Global keyboard shortcut. `combo` examples: "mod+k", "mod+shift+a", "/", "?", "Escape". */
export function useHotkey(combo: string, handler: (e: KeyboardEvent) => void, deps: unknown[] = []) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const cb = useCallback(handler, deps);
  useEffect(() => {
    const parts = combo.toLowerCase().split("+").map((p) => p.trim());
    const needMod = parts.includes("mod") || parts.includes("ctrl") || parts.includes("cmd");
    const needShift = parts.includes("shift");
    const needAlt = parts.includes("alt");
    const key = parts.filter((p) => !["mod", "ctrl", "cmd", "shift", "alt"].includes(p))[0] ?? "";
    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName?.toLowerCase();
      const isEditing = tag === "input" || tag === "textarea" || tag === "select" || target?.isContentEditable;
      // allow Escape/mod-combos everywhere
      if (isEditing && !needMod && key !== "escape") return;
      const mod = e.metaKey || e.ctrlKey;
      if (needMod && !mod) return;
      if (!needMod && mod) return;
      if (needShift !== e.shiftKey) return;
      if (needAlt !== e.altKey) return;
      const k = e.key.toLowerCase();
      if (k !== key) return;
      e.preventDefault();
      cb(e);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [combo, cb]);
}

/** Multi-row selection set helper. */
export function useSelection<T extends string>() {
  const [ids, setIds] = useState<Set<T>>(new Set());
  const has = (id: T) => ids.has(id);
  const toggle = (id: T) =>
    setIds((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  const setAll = (list: T[], on: boolean) => setIds(on ? new Set(list) : new Set());
  const clear = () => setIds(new Set());
  return { ids, list: Array.from(ids), count: ids.size, has, toggle, setAll, clear };
}

export function useDebounced<T>(value: T, ms = 250): T {
  const [v, setV] = useState(value);
  const t = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (t.current) clearTimeout(t.current);
    t.current = setTimeout(() => setV(value), ms);
    return () => {
      if (t.current) clearTimeout(t.current);
    };
  }, [value, ms]);
  return v;
}

/** Persist small UI state in localStorage. */
export function useLocalState<T>(key: string, initial: T) {
  const [v, setV] = useState<T>(() => {
    if (typeof window === "undefined") return initial;
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(v));
    } catch {
      // ignore quota
    }
  }, [key, v]);
  return [v, setV] as const;
}

/** Stable stringified hash for filter objects (used as query keys). */
export function useFilterKey(filters: Record<string, unknown>) {
  return useMemo(() => JSON.stringify(filters), [filters]);
}
