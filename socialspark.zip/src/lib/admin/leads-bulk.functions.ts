import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const statusEnum = z.enum(["new", "contacted", "qualified", "won", "lost"]);

export const bulkUpdateLeadStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ ids: z.array(z.string().uuid()).min(1).max(500), status: statusEnum }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("leads")
      .update({ status: data.status })
      .in("id", data.ids);
    if (error) throw new Error(error.message);
    await context.supabase.from("activity_log").insert(
      data.ids.map((id) => ({
        entity_type: "lead",
        entity_id: id,
        action: `bulk:status=${data.status}`,
        actor_id: context.userId,
      })),
    );
    return { ok: true as const, count: data.ids.length };
  });

export const bulkDeleteLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ ids: z.array(z.string().uuid()).min(1).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("leads").delete().in("id", data.ids);
    if (error) throw new Error(error.message);
    return { ok: true as const, count: data.ids.length };
  });

export const bulkTagLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        ids: z.array(z.string().uuid()).min(1).max(500),
        tags: z.array(z.string().trim().min(1).max(40)).min(1).max(20),
        mode: z.enum(["add", "replace"]).default("add"),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    if (data.mode === "replace") {
      const { error } = await context.supabase
        .from("leads")
        .update({ tags: data.tags })
        .in("id", data.ids);
      if (error) throw new Error(error.message);
      return { ok: true as const };
    }
    // add (merge unique)
    const { data: existing } = await context.supabase
      .from("leads")
      .select("id, tags")
      .in("id", data.ids);
    for (const row of existing ?? []) {
      const merged = Array.from(new Set([...(row.tags ?? []), ...data.tags]));
      await context.supabase.from("leads").update({ tags: merged }).eq("id", row.id);
    }
    return { ok: true as const };
  });

export const updateLeadInline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        patch: z
          .object({
            name: z.string().trim().max(200).nullable().optional(),
            business: z.string().trim().max(200).nullable().optional(),
            email: z.string().trim().email().max(320).nullable().optional(),
            phone: z.string().trim().max(40).nullable().optional(),
            score: z.number().int().min(0).max(100).optional(),
          })
          .refine((o) => Object.keys(o).length > 0, "empty patch"),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("leads").update(data.patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    await context.supabase.from("activity_log").insert({
      entity_type: "lead",
      entity_id: data.id,
      action: "inline_edit",
      diff: data.patch,
      actor_id: context.userId,
    });
    return { ok: true as const };
  });
