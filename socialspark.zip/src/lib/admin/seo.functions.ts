import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// ---- Overrides ----
export const listSeoOverrides = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("seo_overrides")
      .select("*")
      .order("route", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const overrideShape = z.object({
  route: z.string().trim().min(1).max(300),
  title: z.string().trim().max(160).nullable().optional(),
  description: z.string().trim().max(320).nullable().optional(),
  canonical: z.string().trim().url().max(500).nullable().optional(),
  og_image: z.string().trim().max(500).nullable().optional(),
  noindex: z.boolean().default(false),
});

export const upsertSeoOverride = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => overrideShape.parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("seo_overrides")
      .upsert({ ...data, updated_by: context.userId, updated_at: new Date().toISOString() }, { onConflict: "route" });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const deleteSeoOverride = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("seo_overrides").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

// ---- Redirects ----
export const listRedirects = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("redirects")
      .select("*")
      .order("from_path", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const redirectShape = z.object({
  from_path: z.string().trim().regex(/^\//, "must start with /").max(300),
  to_path: z.string().trim().min(1).max(500),
  code: z.number().int().refine((n) => n === 301 || n === 302 || n === 307 || n === 308, "invalid code").default(301),
  enabled: z.boolean().default(true),
});

export const upsertRedirect = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid().optional() }).and(redirectShape).parse(d))
  .handler(async ({ data, context }) => {
    const { id, ...rest } = data;
    if (id) {
      const { error } = await context.supabase.from("redirects").update(rest).eq("id", id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await context.supabase.from("redirects").insert(rest);
      if (error) throw new Error(error.message);
    }
    return { ok: true as const };
  });

export const deleteRedirect = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("redirects").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
