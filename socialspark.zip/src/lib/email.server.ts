// Server-only email sender. Edge-safe (HTTP only, no SMTP sockets).
// Reads provider credentials from the admin-controlled `email_config` table.
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export type EmailProvider = "brevo" | "resend" | "mailgun" | "sendgrid" | "postmark";

export type EmailConfig = {
  provider: EmailProvider;
  api_key: string | null;
  api_secret: string | null;
  mailgun_domain: string | null;
  from_name: string;
  from_email: string;
  reply_to: string | null;
  notify_to: string | null;
  enabled: boolean;
};

function admin() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}

export async function loadEmailConfig(): Promise<EmailConfig | null> {
  const { data } = await admin()
    .from("email_config" as never)
    .select("provider, api_key, api_secret, mailgun_domain, from_name, from_email, reply_to, notify_to, enabled")
    .eq("id", true)
    .maybeSingle();
  return (data as EmailConfig | null) ?? null;
}

export type SendArgs = {
  to: string | string[];
  subject: string;
  html: string;
  replyTo?: string;
};

export type SendResult = { ok: true; provider: EmailProvider; id?: string } | { ok: false; error: string };

export async function sendWithConfig(cfg: EmailConfig, args: SendArgs): Promise<SendResult> {
  if (!cfg.enabled) return { ok: false, error: "Email is disabled in admin settings." };
  if (!cfg.api_key) return { ok: false, error: "No API key configured." };
  if (!cfg.from_email) return { ok: false, error: "No from address configured." };
  const recipients = Array.isArray(args.to) ? args.to : [args.to];
  if (recipients.length === 0) return { ok: false, error: "No recipient." };
  const replyTo = args.replyTo ?? cfg.reply_to ?? undefined;
  try {
    switch (cfg.provider) {
      case "brevo":   return await sendBrevo(cfg, recipients, args, replyTo);
      case "resend":  return await sendResend(cfg, recipients, args, replyTo);
      case "sendgrid":return await sendSendgrid(cfg, recipients, args, replyTo);
      case "postmark":return await sendPostmark(cfg, recipients, args, replyTo);
      case "mailgun": return await sendMailgun(cfg, recipients, args, replyTo);
      default:        return { ok: false, error: `Unknown provider: ${cfg.provider}` };
    }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function sendEmail(args: SendArgs): Promise<SendResult> {
  const cfg = await loadEmailConfig();
  if (!cfg) return { ok: false, error: "Email not configured." };
  return sendWithConfig(cfg, args);
}

// ---------- Providers (HTTP only) ----------

async function sendBrevo(cfg: EmailConfig, to: string[], a: SendArgs, replyTo?: string): Promise<SendResult> {
  const res = await fetch("https://api.brevo.com/v3/smtp/email", {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": cfg.api_key! },
    body: JSON.stringify({
      sender: { name: cfg.from_name, email: cfg.from_email },
      to: to.map((email) => ({ email })),
      subject: a.subject,
      htmlContent: a.html,
      ...(replyTo ? { replyTo: { email: replyTo } } : {}),
    }),
  });
  if (!res.ok) return { ok: false, error: `Brevo ${res.status}: ${await res.text()}` };
  const j = await res.json().catch(() => ({}));
  return { ok: true, provider: "brevo", id: (j as { messageId?: string }).messageId };
}

async function sendResend(cfg: EmailConfig, to: string[], a: SendArgs, replyTo?: string): Promise<SendResult> {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.api_key!}` },
    body: JSON.stringify({
      from: `${cfg.from_name} <${cfg.from_email}>`,
      to,
      subject: a.subject,
      html: a.html,
      ...(replyTo ? { reply_to: replyTo } : {}),
    }),
  });
  if (!res.ok) return { ok: false, error: `Resend ${res.status}: ${await res.text()}` };
  const j = await res.json().catch(() => ({}));
  return { ok: true, provider: "resend", id: (j as { id?: string }).id };
}

async function sendSendgrid(cfg: EmailConfig, to: string[], a: SendArgs, replyTo?: string): Promise<SendResult> {
  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.api_key!}` },
    body: JSON.stringify({
      personalizations: [{ to: to.map((email) => ({ email })) }],
      from: { email: cfg.from_email, name: cfg.from_name },
      subject: a.subject,
      content: [{ type: "text/html", value: a.html }],
      ...(replyTo ? { reply_to: { email: replyTo } } : {}),
    }),
  });
  if (res.status !== 202) return { ok: false, error: `SendGrid ${res.status}: ${await res.text()}` };
  return { ok: true, provider: "sendgrid" };
}

async function sendPostmark(cfg: EmailConfig, to: string[], a: SendArgs, replyTo?: string): Promise<SendResult> {
  const res = await fetch("https://api.postmarkapp.com/email", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      "X-Postmark-Server-Token": cfg.api_key!,
    },
    body: JSON.stringify({
      From: `${cfg.from_name} <${cfg.from_email}>`,
      To: to.join(","),
      Subject: a.subject,
      HtmlBody: a.html,
      MessageStream: "outbound",
      ...(replyTo ? { ReplyTo: replyTo } : {}),
    }),
  });
  if (!res.ok) return { ok: false, error: `Postmark ${res.status}: ${await res.text()}` };
  const j = await res.json().catch(() => ({}));
  return { ok: true, provider: "postmark", id: (j as { MessageID?: string }).MessageID };
}

async function sendMailgun(cfg: EmailConfig, to: string[], a: SendArgs, replyTo?: string): Promise<SendResult> {
  if (!cfg.mailgun_domain) return { ok: false, error: "Mailgun requires a sending domain." };
  const body = new URLSearchParams();
  body.set("from", `${cfg.from_name} <${cfg.from_email}>`);
  to.forEach((t) => body.append("to", t));
  body.set("subject", a.subject);
  body.set("html", a.html);
  if (replyTo) body.set("h:Reply-To", replyTo);
  const auth = btoa(`api:${cfg.api_key!}`);
  const res = await fetch(`https://api.mailgun.net/v3/${encodeURIComponent(cfg.mailgun_domain)}/messages`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });
  if (!res.ok) return { ok: false, error: `Mailgun ${res.status}: ${await res.text()}` };
  const j = await res.json().catch(() => ({}));
  return { ok: true, provider: "mailgun", id: (j as { id?: string }).id };
}
