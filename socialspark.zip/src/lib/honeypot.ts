/**
 * Honeypot helpers — a hidden field bots tend to fill in.
 * Use HONEYPOT_FIELD as the input `name`, render it visually hidden,
 * and reject the submission server-side when isSpam() returns true.
 */
export const HONEYPOT_FIELD = "website_url" as const;

export const honeypotInputProps = {
  type: "text",
  name: HONEYPOT_FIELD,
  tabIndex: -1,
  autoComplete: "off",
  "aria-hidden": true,
} as const;

export const honeypotStyle: React.CSSProperties = {
  position: "absolute",
  width: 1,
  height: 1,
  padding: 0,
  margin: -1,
  overflow: "hidden",
  clip: "rect(0,0,0,0)",
  whiteSpace: "nowrap",
  border: 0,
};

export function isSpam(value: unknown): boolean {
  return typeof value === "string" && value.trim().length > 0;
}
