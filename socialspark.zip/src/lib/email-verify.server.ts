// Server-only provider health checks. HTTP-only, edge-safe.
// Verifies API credentials and (where supported) sender-domain readiness
// without sending any email.

import type { EmailProvider } from "./email.server";

export type VerifyInput = {
  provider: EmailProvider;
  api_key: string;
  mailgun_domain?: string | null;
  from_email?: string | null;
};

export type VerifyCheck = { label: string; ok: boolean; detail?: string };
export type VerifyResult =
  | { ok: true; provider: EmailProvider; account?: string; checks: VerifyCheck[] }
  | { ok: false; provider: EmailProvider; error: string; checks: VerifyCheck[] };

const fromDomain = (email?: string | null) => {
  if (!email) return null;
  const at = email.lastIndexOf("@");
  return at > -1 ? email.slice(at + 1).toLowerCase() : null;
};

export async function verifyProvider(input: VerifyInput): Promise<VerifyResult> {
  const checks: VerifyCheck[] = [];
  try {
    switch (input.provider) {
      case "brevo": {
        const r = await fetch("https://api.brevo.com/v3/account", {
          headers: { "api-key": input.api_key, accept: "application/json" },
        });
        if (!r.ok) return fail("brevo", `Brevo ${r.status}: ${await r.text()}`, checks);
        const j = (await r.json()) as { email?: string; companyName?: string };
        checks.push({ label: "API key valid", ok: true, detail: j.email });
        const dom = fromDomain(input.from_email);
        if (dom) {
          const sr = await fetch(`https://api.brevo.com/v3/senders/domains/${encodeURIComponent(dom)}`, {
            headers: { "api-key": input.api_key, accept: "application/json" },
          });
          if (sr.status === 404) checks.push({ label: `Sender domain ${dom}`, ok: false, detail: "Not added in Brevo. Add & authenticate it." });
          else if (!sr.ok) checks.push({ label: `Sender domain ${dom}`, ok: false, detail: `Brevo ${sr.status}` });
          else {
            const sj = (await sr.json()) as { authenticated?: boolean; verified?: boolean };
            const authed = !!(sj.authenticated ?? sj.verified);
            checks.push({ label: `Sender domain ${dom}`, ok: authed, detail: authed ? "Authenticated" : "DNS not authenticated yet" });
          }
        }
        return { ok: true, provider: "brevo", account: j.email ?? j.companyName, checks };
      }
      case "resend": {
        const r = await fetch("https://api.resend.com/domains", {
          headers: { Authorization: `Bearer ${input.api_key}` },
        });
        if (!r.ok) return fail("resend", `Resend ${r.status}: ${await r.text()}`, checks);
        checks.push({ label: "API key valid", ok: true });
        const j = (await r.json()) as { data?: Array<{ name: string; status: string }> };
        const dom = fromDomain(input.from_email);
        if (dom) {
          const match = j.data?.find((d) => d.name.toLowerCase() === dom);
          if (!match) checks.push({ label: `Sender domain ${dom}`, ok: false, detail: "Not added in Resend." });
          else checks.push({ label: `Sender domain ${dom}`, ok: match.status === "verified", detail: `Status: ${match.status}` });
        }
        return { ok: true, provider: "resend", checks };
      }
      case "sendgrid": {
        const r = await fetch("https://api.sendgrid.com/v3/scopes", {
          headers: { Authorization: `Bearer ${input.api_key}` },
        });
        if (!r.ok) return fail("sendgrid", `SendGrid ${r.status}: ${await r.text()}`, checks);
        const j = (await r.json()) as { scopes?: string[] };
        checks.push({ label: "API key valid", ok: true, detail: `${j.scopes?.length ?? 0} scopes` });
        const sends = j.scopes?.some((s) => s.startsWith("mail.send"));
        checks.push({ label: "mail.send scope", ok: !!sends, detail: sends ? undefined : "Key lacks mail.send permission" });
        return { ok: true, provider: "sendgrid", checks };
      }
      case "postmark": {
        const r = await fetch("https://api.postmarkapp.com/server", {
          headers: { Accept: "application/json", "X-Postmark-Server-Token": input.api_key },
        });
        if (!r.ok) return fail("postmark", `Postmark ${r.status}: ${await r.text()}`, checks);
        const j = (await r.json()) as { Name?: string };
        checks.push({ label: "Server token valid", ok: true, detail: j.Name });
        return { ok: true, provider: "postmark", account: j.Name, checks };
      }
      case "mailgun": {
        if (!input.mailgun_domain) return fail("mailgun", "Mailgun requires a sending domain.", checks);
        const auth = btoa(`api:${input.api_key}`);
        const r = await fetch(`https://api.mailgun.net/v3/domains/${encodeURIComponent(input.mailgun_domain)}`, {
          headers: { Authorization: `Basic ${auth}` },
        });
        if (!r.ok) return fail("mailgun", `Mailgun ${r.status}: ${await r.text()}`, checks);
        const j = (await r.json()) as { domain?: { state?: string; name?: string } };
        checks.push({ label: "API key valid", ok: true });
        const state = j.domain?.state ?? "unknown";
        checks.push({ label: `Domain ${j.domain?.name ?? input.mailgun_domain}`, ok: state === "active", detail: `State: ${state}` });
        return { ok: true, provider: "mailgun", checks };
      }
    }
  } catch (e) {
    return fail(input.provider, e instanceof Error ? e.message : String(e), checks);
  }
}

function fail(provider: EmailProvider, error: string, checks: VerifyCheck[]): VerifyResult {
  return { ok: false, provider, error, checks };
}
