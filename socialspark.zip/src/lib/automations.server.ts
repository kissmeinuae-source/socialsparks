// Server-only automation engine. Never import from a route or component file —
// load it inside server-function/server-route handlers.
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

type Lead = Database["public"]["Tables"]["leads"]["Row"];

function admin() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}

async function isEnabled(key: string): Promise<boolean> {
  try {
    const { data } = await admin()
      .from("automation_rules")
      .select("enabled")
      .eq("key", key)
      .maybeSingle();
    return data?.enabled ?? true;
  } catch {
    return true;
  }
}

async function logRun(input: {
  rule_key: string;
  trigger: string;
  status?: "success" | "skipped" | "error";
  lead_id?: string | null;
  payload?: Record<string, unknown>;
  error?: string | null;
}) {
  const supa = admin();
  const status = input.status ?? "success";
  try {
    await supa.from("automation_runs").insert({
      rule_key: input.rule_key,
      trigger: input.trigger,
      status,
      lead_id: input.lead_id ?? null,
      payload: (input.payload ?? {}) as never,
      error: input.error ?? null,
    });
    await supa
      .from("automation_rules")
      .update({ last_run_at: new Date().toISOString(), last_run_status: status })
      .eq("key", input.rule_key);
  } catch (e) {
    console.error("[automations] logRun failed", e);
  }
}

// ---------- Scoring ----------

const BUDGET_HINTS = [
  /\b(50k|100k|lakh|crore|million|budget|enterprise|premium|long.term|retainer)\b/i,
];
const URGENCY_HINTS = [/\b(asap|urgent|immediately|this week|tomorrow)\b/i];
const SMALL_BUSINESS_HINTS = [/\b(startup|small|new business|just started)\b/i];

export function scoreLead(lead: Pick<Lead, "type" | "business" | "message" | "social_url" | "email" | "phone">): {
  score: number;
  tags: string[];
} {
  let s = 30;
  const tags = new Set<string>();
  const text = `${lead.business ?? ""} ${lead.message ?? ""} ${lead.social_url ?? ""}`.toLowerCase();

  if (lead.type === "book") {
    s += 30;
    tags.add("ready-to-book");
  } else if (lead.type === "audit") {
    s += 18;
    tags.add("audit-request");
  } else if (lead.type === "contact") {
    s += 10;
  }

  if (lead.email && lead.phone) {
    s += 10;
    tags.add("full-contact");
  }
  if (lead.social_url) {
    s += 6;
  }
  if (BUDGET_HINTS.some((r) => r.test(text))) {
    s += 25;
    tags.add("budget-signal");
  }
  if (URGENCY_HINTS.some((r) => r.test(text))) {
    s += 15;
    tags.add("urgent");
  }
  if (SMALL_BUSINESS_HINTS.some((r) => r.test(text))) {
    s -= 8;
    tags.add("small-business");
  }
  if ((lead.message ?? "").length > 200) {
    s += 6;
    tags.add("detailed-brief");
  }

  s = Math.max(0, Math.min(100, s));
  if (s >= 75) tags.add("hot");
  else if (s >= 55) tags.add("warm");
  else tags.add("cold");

  return { score: s, tags: [...tags] };
}

// ---------- On lead created ----------

export async function runOnLeadCreated(leadId: string) {
  const supa = admin();
  const { data: lead } = await supa.from("leads").select("*").eq("id", leadId).maybeSingle();
  if (!lead) return;

  // 1. Score + tag
  if (await isEnabled("lead.score")) {
    const { score, tags } = scoreLead(lead);
    await supa
      .from("leads")
      .update({
        score,
        tags,
        last_auto_action: `scored:${score}`,
        last_auto_action_at: new Date().toISOString(),
      })
      .eq("id", leadId);
    await supa.from("lead_activity").insert({
      lead_id: leadId,
      kind: "automation",
      content: `Auto-scored ${score}/100 · tags: ${tags.join(", ")}`,
      metadata: { score, tags } as never,
    });
    await logRun({
      rule_key: "lead.score",
      trigger: "lead.created",
      lead_id: leadId,
      payload: { score, tags },
    });
  }

  // 2. Customer auto-reply
  if (lead.email && (await isEnabled("lead.customer_autoreply"))) {
    try {
      await sendCustomerAutoReply({
        to: lead.email,
        name: lead.name,
        type: lead.type,
        business: lead.business,
      });
      await supa
        .from("leads")
        .update({ last_auto_action: "autoreply_sent", last_auto_action_at: new Date().toISOString() })
        .eq("id", leadId);
      await supa.from("lead_activity").insert({
        lead_id: leadId,
        kind: "auto_reply_sent",
        content: `Confirmation email sent to ${lead.email}`,
      });
      await logRun({
        rule_key: "lead.customer_autoreply",
        trigger: "lead.created",
        lead_id: leadId,
        payload: { to: lead.email },
      });
    } catch (err) {
      await logRun({
        rule_key: "lead.customer_autoreply",
        trigger: "lead.created",
        lead_id: leadId,
        status: "error",
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}

// ---------- Email sender (delegates to admin-configured provider) ----------

async function sendEmail(input: { to: string | string[]; subject: string; html: string }) {
  const { sendEmail: send } = await import("./email.server");
  const result = await send({ to: input.to, subject: input.subject, html: input.html });
  if (!result.ok) throw new Error(result.error);
}


async function sendCustomerAutoReply(input: {
  to: string;
  name?: string | null;
  type: string;
  business?: string | null;
}) {
  const greeting = input.name ? `Hi ${input.name.split(/\s+/)[0]},` : "Hi there,";
  const typeLine =
    input.type === "book"
      ? "Your call request just landed with us."
      : input.type === "audit"
        ? "Your free audit request is in."
        : "Your message just reached our team.";
  const html = `
    <div style="font-family:Georgia,serif;background:#F4EFE6;padding:40px 16px">
      <div style="max-width:560px;margin:0 auto;background:#fff;border-radius:20px;padding:36px">
        <div style="font:600 11px/1 system-ui;letter-spacing:.18em;color:#8A8275;text-transform:uppercase">Social Spark</div>
        <h1 style="font-style:italic;font-size:32px;color:#0E1B3D;margin:18px 0 12px;line-height:1.1">Thanks, we've got it.</h1>
        <p style="font:400 15px/1.6 system-ui;color:#3F4655;margin:0 0 14px">${greeting}</p>
        <p style="font:400 15px/1.6 system-ui;color:#3F4655;margin:0 0 14px">${typeLine} Our growth team reviews every inbound within <strong>2 working hours</strong> (Mon–Sat, 10am–7pm PKT) and will reach out with next steps${input.business ? ` for ${input.business}` : ""}.</p>
        <p style="font:400 15px/1.6 system-ui;color:#3F4655;margin:0 0 22px">In the meantime, you can WhatsApp us directly on <a href="https://wa.me/923000000000" style="color:#0E1B3D">+92 300 000 0000</a>.</p>
        <div style="border-top:1px solid #EEE;padding-top:18px;font:400 12px/1.6 system-ui;color:#8A8275">
          Social Spark · Lahore, Pakistan<br/>
          This is an automated confirmation — replies go straight to our team.
        </div>
      </div>
    </div>`;
  await sendEmail({
    to: input.to,
    subject: "We've received your request — Social Spark",
    html,
  });
}

// ---------- Stale lead sweep ----------

export async function runStaleLeadSweep() {
  if (!(await isEnabled("cron.stale_leads"))) {
    await logRun({ rule_key: "cron.stale_leads", trigger: "cron", status: "skipped" });
    return { flagged: 0, skipped: true };
  }
  const supa = admin();
  const cutoff = new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString();
  const { data: stale, error } = await supa
    .from("leads")
    .select("id, tags")
    .eq("status", "contacted")
    .lt("updated_at", cutoff)
    .limit(200);
  if (error) {
    await logRun({ rule_key: "cron.stale_leads", trigger: "cron", status: "error", error: error.message });
    throw error;
  }
  let flagged = 0;
  for (const lead of stale ?? []) {
    const tags = new Set(lead.tags ?? []);
    if (tags.has("needs-followup")) continue;
    tags.add("needs-followup");
    await supa
      .from("leads")
      .update({
        tags: [...tags],
        last_auto_action: "stale_flag",
        last_auto_action_at: new Date().toISOString(),
      })
      .eq("id", lead.id);
    await supa.from("lead_activity").insert({
      lead_id: lead.id,
      kind: "automation",
      content: "Stale lead — no activity in 72h. Tagged needs-followup.",
    });
    flagged += 1;
  }
  await logRun({
    rule_key: "cron.stale_leads",
    trigger: "cron",
    payload: { flagged, scanned: stale?.length ?? 0 },
  });
  return { flagged, skipped: false };
}

// ---------- Daily digest ----------

export async function runDailyDigest() {
  if (!(await isEnabled("cron.daily_digest"))) {
    await logRun({ rule_key: "cron.daily_digest", trigger: "cron", status: "skipped" });
    return { sent: false, reason: "disabled" };
  }
  const { loadEmailConfig } = await import("./email.server");
  const cfg = await loadEmailConfig();
  const NOTIFY_TO = cfg?.notify_to ?? process.env.LEAD_NOTIFY_TO ?? "";
  if (!NOTIFY_TO) {
    await logRun({ rule_key: "cron.daily_digest", trigger: "cron", status: "skipped", error: "No notify_to recipients" });
    return { sent: false, reason: "no recipients" };
  }
  const supa = admin();
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const { data: recent } = await supa
    .from("leads")
    .select("id, name, business, type, score, tags, status, created_at")
    .gte("created_at", since)
    .order("score", { ascending: false })
    .limit(50);

  const total = recent?.length ?? 0;
  const hot = (recent ?? []).filter((l) => (l.score ?? 0) >= 75);
  const rowsHtml = (recent ?? [])
    .slice(0, 15)
    .map(
      (l) =>
        `<tr><td style="padding:6px 10px;border-bottom:1px solid #F0EDE5">${l.name ?? "—"}</td><td style="padding:6px 10px;border-bottom:1px solid #F0EDE5">${l.business ?? ""}</td><td style="padding:6px 10px;border-bottom:1px solid #F0EDE5">${l.type}</td><td style="padding:6px 10px;border-bottom:1px solid #F0EDE5;text-align:right;font-weight:600">${l.score ?? 0}</td></tr>`,
    )
    .join("");

  const html = `
    <div style="font-family:Georgia,serif;background:#F4EFE6;padding:32px">
      <div style="max-width:640px;margin:0 auto;background:#fff;border-radius:20px;padding:32px">
        <div style="font:600 11px/1 system-ui;letter-spacing:.18em;color:#8A8275;text-transform:uppercase">Social Spark · Daily digest</div>
        <h1 style="font-style:italic;font-size:30px;color:#0E1B3D;margin:14px 0 22px">${total} new leads in the last 24h</h1>
        <p style="font:400 14px/1.6 system-ui;color:#3F4655;margin:0 0 18px"><strong style="color:#0E1B3D">${hot.length}</strong> are hot (score ≥ 75) and worth a same-day follow-up.</p>
        <table style="width:100%;border-collapse:collapse;font:400 13px/1.4 system-ui;color:#0E1B3D">
          <thead><tr style="color:#8A8275;text-align:left"><th style="padding:6px 10px;border-bottom:1px solid #E5E1D6">Name</th><th style="padding:6px 10px;border-bottom:1px solid #E5E1D6">Business</th><th style="padding:6px 10px;border-bottom:1px solid #E5E1D6">Type</th><th style="padding:6px 10px;border-bottom:1px solid #E5E1D6;text-align:right">Score</th></tr></thead>
          <tbody>${rowsHtml || `<tr><td colspan="4" style="padding:18px;text-align:center;color:#8A8275">No new leads today.</td></tr>`}</tbody>
        </table>
      </div>
    </div>`;

  try {
    await sendEmail({
      to: NOTIFY_TO.split(",").map((s) => s.trim()).filter(Boolean),
      subject: `Daily digest — ${total} leads, ${hot.length} hot`,
      html,
    });
    await logRun({ rule_key: "cron.daily_digest", trigger: "cron", payload: { total, hot: hot.length } });
    return { sent: true, total, hot: hot.length };
  } catch (err) {
    await logRun({
      rule_key: "cron.daily_digest",
      trigger: "cron",
      status: "error",
      error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
}
