import { useQuery } from "@tanstack/react-query";
import { listSiteSettings } from "@/lib/cms.functions";

export type SettingValue = Record<string, unknown>;

export function useSiteSettings() {
  return useQuery({
    queryKey: ["public", "site-settings"],
    queryFn: () => listSiteSettings(),
    staleTime: 5 * 60_000,
  });
}

export function pickSetting(rows: { key: string; value: unknown }[] | undefined, key: string): SettingValue {
  if (!rows) return {};
  const row = rows.find((r) => r.key === key);
  return (row?.value as SettingValue) ?? {};
}

export function str(v: SettingValue, k: string, fallback = ""): string {
  const x = v[k];
  return typeof x === "string" && x.trim() ? x : fallback;
}
