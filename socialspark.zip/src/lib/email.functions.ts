import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const PROVIDERS = ["brevo", "resend", "mailgun", "sendgrid", "postmark"] as const;

async function assertAdmin(ctx: { supabase: { rpc: (fn: string, args: unknown) => Promise<{ data: unknown }> }; userId: string }) {
  const { data } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role: "admin" });
  if (!data) throw new Error("Forbidden — admins only");
}

export type EmailConfigRow = {
  provider: "brevo" | "resend" | "mailgun" | "sendgrid" | "postmark";
  api_key: string | null;
  api_secret: string | null;
  mailgun_domain: string | null;
  from_name: string;
  from_email: string;
  reply_to: string | null;
  notify_to: string | null;
  enabled: boolean;
  last_test_at: string | null;
  last_test_status: string | null;
  last_test_error: string | null;
};

export const getEmailConfig = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<EmailConfigRow | null> => {
    await assertAdmin(context as never);
    const { data, error } = await context.supabase
      .from("email_config" as never)
      .select("provider, api_key, api_secret, mailgun_domain, from_name, from_email, reply_to, notify_to, enabled, last_test_at, last_test_status, last_test_error")
      .eq("id", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return (data as EmailConfigRow | null) ?? null;
  });

const saveSchema = z.object({
  provider: z.enum(PROVIDERS),
  api_key: z.string().trim().max(500).optional().nullable(),
  api_secret: z.string().trim().max(500).optional().nullable(),
  mailgun_domain: z.string().trim().max(200).optional().nullable(),
  from_name: z.string().trim().min(1).max(120),
  from_email: z.string().trim().email().max(200),
  reply_to: z.string().trim().email().max(200).optional().nullable().or(z.literal("")),
  notify_to: z.string().trim().max(500).optional().nullable().or(z.literal("")),
  enabled: z.boolean(),
});

export const saveEmailConfig = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof saveSchema>) => saveSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const row = {
      id: true,
      ...data,
      api_key: data.api_key || null,
      api_secret: data.api_secret || null,
      mailgun_domain: data.mailgun_domain || null,
      reply_to: data.reply_to || null,
      notify_to: data.notify_to || null,
      updated_by: context.userId,
    };
    const { error } = await context.supabase
      .from("email_config" as never)
      .upsert(row as never);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const testSchema = z.object({
  to: z.string().trim().email().max(200),
});

export const sendTestEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof testSchema>) => testSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const mod = await import("./email.server");
    const cfg = await mod.loadEmailConfig();
    if (!cfg) {
      await context.supabase
        .from("email_config" as never)
        .update({ last_test_at: new Date().toISOString(), last_test_status: "error", last_test_error: "Config missing" } as never)
        .eq("id", true);
      return { ok: false as const, error: "Email config not found." };
    }
    const result = await mod.sendWithConfig(cfg, {
      to: data.to,
      subject: `Test from Social Spark · ${new Date().toLocaleString()}`,
      html: `<div style="font-family:Arial,sans-serif;background:#F4EFE6;padding:32px"><div style="max-width:520px;margin:0 auto;background:#fff;border-radius:16px;padding:32px"><div style="font:600 11px/1 system-ui;letter-spacing:.18em;color:#8A8275;text-transform:uppercase">Social Spark</div><h1 style="font-family:Georgia,serif;font-style:italic;font-size:28px;color:#0E1B3D;margin:14px 0 12px">Test email — it works.</h1><p style="font:400 15px/1.6 system-ui;color:#3F4655;margin:0 0 14px">Your <strong>${cfg.provider}</strong> connection is live. From this point on, customer auto-replies and admin digests will use this configuration.</p><p style="font:400 13px/1.6 system-ui;color:#8A8275;margin:0">Sent ${new Date().toUTCString()}</p></div></div>`,
    });
    await context.supabase
      .from("email_config" as never)
      .update({
        last_test_at: new Date().toISOString(),
        last_test_status: result.ok ? "success" : "error",
        last_test_error: result.ok ? null : result.error,
      } as never)
      .eq("id", true);
    return result;
  });

const verifySchema = z.object({
  provider: z.enum(PROVIDERS),
  api_key: z.string().trim().min(1, "API key is required").max(500),
  mailgun_domain: z.string().trim().max(200).optional().nullable(),
  from_email: z.string().trim().email().max(200).optional().nullable().or(z.literal("")),
});

export type VerifyProviderResult = Awaited<ReturnType<typeof import("./email-verify.server").verifyProvider>>;

export const verifyEmailProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: z.input<typeof verifySchema>) => verifySchema.parse(d))
  .handler(async ({ data, context }): Promise<VerifyProviderResult> => {
    await assertAdmin(context as never);
    const { verifyProvider } = await import("./email-verify.server");
    return verifyProvider({
      provider: data.provider,
      api_key: data.api_key,
      mailgun_domain: data.mailgun_domain ?? null,
      from_email: data.from_email || null,
    });
  });
