export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          diff: Json | null
          entity_id: string
          entity_type: string
          id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          diff?: Json | null
          entity_id: string
          entity_type: string
          id?: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          diff?: Json | null
          entity_id?: string
          entity_type?: string
          id?: string
        }
        Relationships: []
      }
      admin_audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          id: string
          ip_address: string | null
          metadata: Json | null
          target_id: string | null
          target_type: string | null
          user_agent: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          target_id?: string | null
          target_type?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      admin_views: {
        Row: {
          columns: Json
          created_at: string
          filters: Json
          id: string
          is_default: boolean
          module: string
          name: string
          sort: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          columns?: Json
          created_at?: string
          filters?: Json
          id?: string
          is_default?: boolean
          module: string
          name: string
          sort?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          columns?: Json
          created_at?: string
          filters?: Json
          id?: string
          is_default?: boolean
          module?: string
          name?: string
          sort?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      automation_rules: {
        Row: {
          config: Json
          created_at: string
          description: string | null
          enabled: boolean
          id: string
          key: string
          last_run_at: string | null
          last_run_status: string | null
          name: string
          updated_at: string
        }
        Insert: {
          config?: Json
          created_at?: string
          description?: string | null
          enabled?: boolean
          id?: string
          key: string
          last_run_at?: string | null
          last_run_status?: string | null
          name: string
          updated_at?: string
        }
        Update: {
          config?: Json
          created_at?: string
          description?: string | null
          enabled?: boolean
          id?: string
          key?: string
          last_run_at?: string | null
          last_run_status?: string | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      automation_runs: {
        Row: {
          created_at: string
          error: string | null
          id: string
          lead_id: string | null
          payload: Json
          rule_key: string
          status: string
          trigger: string
        }
        Insert: {
          created_at?: string
          error?: string | null
          id?: string
          lead_id?: string | null
          payload?: Json
          rule_key: string
          status?: string
          trigger: string
        }
        Update: {
          created_at?: string
          error?: string | null
          id?: string
          lead_id?: string | null
          payload?: Json
          rule_key?: string
          status?: string
          trigger?: string
        }
        Relationships: [
          {
            foreignKeyName: "automation_runs_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_posts: {
        Row: {
          author_name: string
          body_en: string
          body_ur: string | null
          category: string
          cover_image_url: string | null
          created_at: string
          excerpt_en: string
          excerpt_ur: string | null
          featured: boolean
          id: string
          og_image_url: string | null
          published: boolean
          published_at: string | null
          read_time: string
          seo_description: string | null
          seo_title: string | null
          slug: string
          sort_order: number
          title_en: string
          title_ur: string | null
          updated_at: string
        }
        Insert: {
          author_name?: string
          body_en?: string
          body_ur?: string | null
          category?: string
          cover_image_url?: string | null
          created_at?: string
          excerpt_en?: string
          excerpt_ur?: string | null
          featured?: boolean
          id?: string
          og_image_url?: string | null
          published?: boolean
          published_at?: string | null
          read_time?: string
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          sort_order?: number
          title_en: string
          title_ur?: string | null
          updated_at?: string
        }
        Update: {
          author_name?: string
          body_en?: string
          body_ur?: string | null
          category?: string
          cover_image_url?: string | null
          created_at?: string
          excerpt_en?: string
          excerpt_ur?: string | null
          featured?: boolean
          id?: string
          og_image_url?: string | null
          published?: boolean
          published_at?: string | null
          read_time?: string
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          sort_order?: number
          title_en?: string
          title_ur?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      email_config: {
        Row: {
          api_key: string | null
          api_secret: string | null
          created_at: string
          enabled: boolean
          from_email: string
          from_name: string
          id: boolean
          last_test_at: string | null
          last_test_error: string | null
          last_test_status: string | null
          mailgun_domain: string | null
          notify_to: string | null
          provider: string
          reply_to: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          api_key?: string | null
          api_secret?: string | null
          created_at?: string
          enabled?: boolean
          from_email?: string
          from_name?: string
          id?: boolean
          last_test_at?: string | null
          last_test_error?: string | null
          last_test_status?: string | null
          mailgun_domain?: string | null
          notify_to?: string | null
          provider?: string
          reply_to?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          api_key?: string | null
          api_secret?: string | null
          created_at?: string
          enabled?: boolean
          from_email?: string
          from_name?: string
          id?: boolean
          last_test_at?: string | null
          last_test_error?: string | null
          last_test_status?: string | null
          mailgun_domain?: string | null
          notify_to?: string | null
          provider?: string
          reply_to?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      inbox_messages: {
        Row: {
          body: string
          channel: string
          created_at: string
          direction: string
          id: string
          lead_id: string | null
          meta: Json
          sent_by: string | null
          subject: string | null
        }
        Insert: {
          body: string
          channel: string
          created_at?: string
          direction: string
          id?: string
          lead_id?: string | null
          meta?: Json
          sent_by?: string | null
          subject?: string | null
        }
        Update: {
          body?: string
          channel?: string
          created_at?: string
          direction?: string
          id?: string
          lead_id?: string | null
          meta?: Json
          sent_by?: string | null
          subject?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "inbox_messages_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_activity: {
        Row: {
          actor_id: string | null
          content: string | null
          created_at: string
          id: string
          kind: string
          lead_id: string
          metadata: Json | null
        }
        Insert: {
          actor_id?: string | null
          content?: string | null
          created_at?: string
          id?: string
          kind: string
          lead_id: string
          metadata?: Json | null
        }
        Update: {
          actor_id?: string | null
          content?: string | null
          created_at?: string
          id?: string
          kind?: string
          lead_id?: string
          metadata?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_activity_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          assigned_to: string | null
          business: string | null
          created_at: string
          email: string | null
          id: string
          ip_hash: string | null
          last_auto_action: string | null
          last_auto_action_at: string | null
          message: string | null
          name: string | null
          notes: string | null
          phone: string | null
          score: number
          social_url: string | null
          source_page: string | null
          status: string
          tags: string[]
          type: Database["public"]["Enums"]["lead_type"]
          updated_at: string
          user_agent: string | null
        }
        Insert: {
          assigned_to?: string | null
          business?: string | null
          created_at?: string
          email?: string | null
          id?: string
          ip_hash?: string | null
          last_auto_action?: string | null
          last_auto_action_at?: string | null
          message?: string | null
          name?: string | null
          notes?: string | null
          phone?: string | null
          score?: number
          social_url?: string | null
          source_page?: string | null
          status?: string
          tags?: string[]
          type: Database["public"]["Enums"]["lead_type"]
          updated_at?: string
          user_agent?: string | null
        }
        Update: {
          assigned_to?: string | null
          business?: string | null
          created_at?: string
          email?: string | null
          id?: string
          ip_hash?: string | null
          last_auto_action?: string | null
          last_auto_action_at?: string | null
          message?: string | null
          name?: string | null
          notes?: string | null
          phone?: string | null
          score?: number
          social_url?: string | null
          source_page?: string | null
          status?: string
          tags?: string[]
          type?: Database["public"]["Enums"]["lead_type"]
          updated_at?: string
          user_agent?: string | null
        }
        Relationships: []
      }
      media_assets: {
        Row: {
          alt: string | null
          created_at: string
          filename: string
          height: number | null
          id: string
          mime_type: string | null
          size_bytes: number | null
          storage_path: string
          tags: string[]
          updated_at: string
          uploaded_by: string | null
          url: string
          width: number | null
        }
        Insert: {
          alt?: string | null
          created_at?: string
          filename: string
          height?: number | null
          id?: string
          mime_type?: string | null
          size_bytes?: number | null
          storage_path: string
          tags?: string[]
          updated_at?: string
          uploaded_by?: string | null
          url: string
          width?: number | null
        }
        Update: {
          alt?: string | null
          created_at?: string
          filename?: string
          height?: number | null
          id?: string
          mime_type?: string | null
          size_bytes?: number | null
          storage_path?: string
          tags?: string[]
          updated_at?: string
          uploaded_by?: string | null
          url?: string
          width?: number | null
        }
        Relationships: []
      }
      media_usage: {
        Row: {
          asset_id: string
          created_at: string
          entity_id: string | null
          entity_type: string | null
          id: string
          used_on: string
        }
        Insert: {
          asset_id: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          used_on: string
        }
        Update: {
          asset_id?: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          used_on?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_usage_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "media_assets"
            referencedColumns: ["id"]
          },
        ]
      }
      pricing_plans: {
        Row: {
          created_at: string
          features: Json
          highlighted: boolean
          id: string
          name_en: string
          name_ur: string | null
          period: string
          price_pkr: number
          published: boolean
          slug: string
          sort_order: number
          tagline_en: string | null
          tagline_ur: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          features?: Json
          highlighted?: boolean
          id?: string
          name_en: string
          name_ur?: string | null
          period?: string
          price_pkr?: number
          published?: boolean
          slug: string
          sort_order?: number
          tagline_en?: string | null
          tagline_ur?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          features?: Json
          highlighted?: boolean
          id?: string
          name_en?: string
          name_ur?: string | null
          period?: string
          price_pkr?: number
          published?: boolean
          slug?: string
          sort_order?: number
          tagline_en?: string | null
          tagline_ur?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      redirects: {
        Row: {
          code: number
          created_at: string
          enabled: boolean
          from_path: string
          id: string
          to_path: string
          updated_at: string
        }
        Insert: {
          code?: number
          created_at?: string
          enabled?: boolean
          from_path: string
          id?: string
          to_path: string
          updated_at?: string
        }
        Update: {
          code?: number
          created_at?: string
          enabled?: boolean
          from_path?: string
          id?: string
          to_path?: string
          updated_at?: string
        }
        Relationships: []
      }
      seo_overrides: {
        Row: {
          canonical: string | null
          created_at: string
          description: string | null
          id: string
          json_ld: Json | null
          noindex: boolean
          og_image: string | null
          route: string
          title: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          canonical?: string | null
          created_at?: string
          description?: string | null
          id?: string
          json_ld?: Json | null
          noindex?: boolean
          og_image?: string | null
          route: string
          title?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          canonical?: string | null
          created_at?: string
          description?: string | null
          id?: string
          json_ld?: Json | null
          noindex?: boolean
          og_image?: string | null
          route?: string
          title?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      seo_scan_results: {
        Row: {
          checked_at: string
          error: string | null
          id: string
          ok: boolean
          scan_id: string
          status_code: number | null
          url: string
        }
        Insert: {
          checked_at?: string
          error?: string | null
          id?: string
          ok?: boolean
          scan_id: string
          status_code?: number | null
          url: string
        }
        Update: {
          checked_at?: string
          error?: string | null
          id?: string
          ok?: boolean
          scan_id?: string
          status_code?: number | null
          url?: string
        }
        Relationships: []
      }
      services: {
        Row: {
          body_en: string | null
          body_ur: string | null
          created_at: string
          icon: string | null
          id: string
          published: boolean
          slug: string
          sort_order: number
          summary_en: string | null
          summary_ur: string | null
          title_en: string
          title_ur: string | null
          updated_at: string
        }
        Insert: {
          body_en?: string | null
          body_ur?: string | null
          created_at?: string
          icon?: string | null
          id?: string
          published?: boolean
          slug: string
          sort_order?: number
          summary_en?: string | null
          summary_ur?: string | null
          title_en: string
          title_ur?: string | null
          updated_at?: string
        }
        Update: {
          body_en?: string | null
          body_ur?: string | null
          created_at?: string
          icon?: string | null
          id?: string
          published?: boolean
          slug?: string
          sort_order?: number
          summary_en?: string | null
          summary_ur?: string | null
          title_en?: string
          title_ur?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          created_at: string
          description: string | null
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          created_at?: string
          description?: string | null
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          created_at?: string
          description?: string | null
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      testimonials: {
        Row: {
          avatar_url: string | null
          company: string | null
          created_at: string
          featured: boolean
          id: string
          name: string
          published: boolean
          quote_en: string
          quote_ur: string | null
          rating: number
          role_en: string | null
          role_ur: string | null
          sort_order: number
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          company?: string | null
          created_at?: string
          featured?: boolean
          id?: string
          name: string
          published?: boolean
          quote_en: string
          quote_ur?: string | null
          rating?: number
          role_en?: string | null
          role_ur?: string | null
          sort_order?: number
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          company?: string | null
          created_at?: string
          featured?: boolean
          id?: string
          name?: string
          published?: boolean
          quote_en?: string
          quote_ur?: string | null
          rating?: number
          role_en?: string | null
          role_ur?: string | null
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "team"
      lead_type: "audit" | "book" | "contact" | "chat"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "team"],
      lead_type: ["audit", "book", "contact", "chat"],
    },
  },
} as const
