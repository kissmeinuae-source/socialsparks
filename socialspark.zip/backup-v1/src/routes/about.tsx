import { createFileRoute } from "@tanstack/react-router";
import { About } from "@/components/home/About";
import { FadeSlide } from "@/components/anim/FadeSlide";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Social Spark" },
      {
        name: "description",
        content:
          "Built in Lahore for Pakistani businesses and personalities. Meet the team and milestones behind Social Spark.",
      },
      { property: "og:title", content: "About — Social Spark" },
      {
        property: "og:description",
        content:
          "We're a small Lahore-based team helping Pakistani brands grow online without templates or fluff.",
      },
      { property: "og:url", content: "/about" },

    ],

    links: [{ rel: "canonical", href: "/about" }],
    }),
  component: AboutPage,
});

const milestones = [
  { year: "2022", label: "Founded in Lahore" },
  { year: "2023", label: "First celebrity client" },
  { year: "2024", label: "50+ brands served" },
  { year: "2025", label: "Nationwide reach" },
];

function AboutPage() {
  return (
    <>
      <About />

      {/* Founder */}
      <section style={{ background: "var(--ss-paper)", padding: "112px 48px" }}>
        <div className="mx-auto max-w-[1160px]">
          <FadeSlide>
            <div className="flex items-center gap-3">
              <span className="h-px w-6 bg-gold" />
              <span className="t-label text-gold">THE FOUNDER</span>
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h2 className="mt-5 text-navy">A small team. Hands on every account.</h2>
          </FadeSlide>

          <FadeSlide delay={150}>
            <div
              className="mt-10 grid items-center gap-10 md:grid-cols-[280px_1fr]"
              style={{
                background: "var(--ss-ink)",
                border: "1px solid var(--ss-line)",
                borderRadius: 4,
                padding: 40,
              }}
            >
              <div
                style={{
                  width: 240,
                  height: 240,
                  borderRadius: 4,
                  background:
                    "linear-gradient(135deg, var(--ss-navy), oklch(from var(--ss-gold) l c h / 0.25))",
                  display: "grid",
                  placeItems: "center",
                  fontFamily: "var(--font-display)",
                  fontSize: 72,
                  fontWeight: 800,
                  color: "var(--ss-gold)",
                }}
              >
                HA
              </div>
              <div>
                <div className="t-label text-gold">FOUNDER & STRATEGY LEAD</div>
                <h3 className="mt-2 text-white" style={{ fontSize: 32 }}>
                  Hassan Ahmed
                </h3>
                <p
                  className="mt-5"
                  style={{ color: "var(--ss-ash)", fontSize: 16, lineHeight: 1.85 }}
                >
                  Hassan started Social Spark after seven years building brands
                  for Pakistani SMBs and media personalities. He runs strategy
                  on every account personally — no account-manager middleman,
                  no offshore handoff.
                  <br />
                  <br />
                  Trained in Lahore, obsessed with the Pakistani consumer, and
                  fluent enough in both Urdu and English to brief a clinic in
                  Islamabad and an ARY anchor the same afternoon.
                </p>
              </div>
            </div>
          </FadeSlide>
        </div>
      </section>

      {/* Timeline */}
      <section style={{ background: "var(--ss-paper)", padding: "0 48px 112px" }}>
        <div className="mx-auto max-w-[1160px]">
          <FadeSlide>
            <h2 className="text-navy">Four years in.</h2>
          </FadeSlide>

          <div className="relative mt-16">
            <div
              aria-hidden
              style={{
                position: "absolute",
                top: 7,
                left: 0,
                right: 0,
                height: 2,
                background: "var(--ss-gold)",
              }}
            />
            <div className="relative grid gap-10 sm:grid-cols-4">
              {milestones.map((m, i) => (
                <FadeSlide key={m.year} delay={i * 100}>
                  <div className="flex flex-col items-start">
                    <span
                      style={{
                        width: 16,
                        height: 16,
                        borderRadius: "50%",
                        background: "var(--ss-navy)",
                        border: "2px solid var(--ss-gold)",
                        marginTop: -1,
                      }}
                    />
                    <div
                      className="mt-5 text-navy"
                      style={{
                        fontFamily: "var(--font-display)",
                        fontWeight: 800,
                        fontSize: 32,
                      }}
                    >
                      {m.year}
                    </div>
                    <div
                      className="mt-1"
                      style={{ color: "var(--ss-slate)", fontSize: 14 }}
                    >
                      {m.label}
                    </div>
                  </div>
                </FadeSlide>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section style={{ background: "var(--ss-ink)", padding: "144px 48px" }}>
        <div className="mx-auto max-w-[1080px] text-center">
          <FadeSlide>
            <p
              className="text-white"
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 800,
                fontSize: "clamp(28px, 4.5vw, 52px)",
                lineHeight: 1.2,
                letterSpacing: "-0.02em",
                textWrap: "balance",
              }}
            >
              We believe every Pakistani business deserves a digital presence
              that reflects the quality of what they{" "}
              <span className="text-gold">actually do</span>.
            </p>
          </FadeSlide>
        </div>
      </section>
    </>
  );
}
