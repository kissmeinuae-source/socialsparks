import { createFileRoute } from "@tanstack/react-router";
import { LegalLayout } from "@/components/legal/LegalLayout";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Social Spark" },
      { name: "description", content: "How Social Spark collects, uses, and protects your data under Pakistan's PDPA." },
      { property: "og:url", content: "/privacy-policy" },

    ],

    links: [{ rel: "canonical", href: "/privacy-policy" }],
    }),
  component: () => (
    <LegalLayout title="Privacy Policy" updated="June 26, 2026">
      <p>
        Social Spark (Private) Limited ("we", "us", "our") operates
        socialspark.pk and provides digital marketing services to clients
        based primarily in Pakistan. This policy explains what personal data
        we collect, how we use it, and the rights you have under the Personal
        Data Protection Act (PDPA), 2023 of Pakistan.
      </p>

      <h2>1. Data we collect</h2>
      <ul>
        <li>Contact details you submit through forms (name, email, WhatsApp number, business name)</li>
        <li>Information you share during consultations or onboarding</li>
        <li>Account access you grant for managed services (with revocable permissions)</li>
        <li>Technical data: IP address, browser, device type, referring page</li>
        <li>Cookie data — see our Cookie Policy</li>
      </ul>

      <h2>2. How we use it</h2>
      <ul>
        <li>To respond to enquiries and provide the services you request</li>
        <li>To send invoices, contracts, and service updates</li>
        <li>To improve our website, content, and service quality</li>
        <li>To comply with Pakistani legal and tax obligations</li>
      </ul>
      <p>We do not sell your data. We do not use it for purposes outside the ones listed.</p>

      <h2>3. Third parties</h2>
      <p>
        We share data only with vetted processors that help us deliver the
        service: payment providers (JazzCash, EasyPaisa, bank gateways),
        analytics (Google Analytics), email (Postmark/Resend), and platform
        APIs (Meta, Google, TikTok) when you give us access. Each provider has
        its own privacy terms.
      </p>

      <h2>4. Cookies</h2>
      <p>
        We use first-party and a limited set of third-party cookies. Details
        are in our <a href="/cookie-policy">Cookie Policy</a>.
      </p>

      <h2>5. Your rights</h2>
      <ul>
        <li>Access the personal data we hold about you</li>
        <li>Correct inaccurate data</li>
        <li>Request deletion (subject to legal retention)</li>
        <li>Withdraw consent at any time</li>
        <li>Lodge a complaint with the National Commission for Personal Data Protection</li>
      </ul>

      <h2>6. Retention</h2>
      <p>
        We keep client records for up to 7 years after the engagement ends to
        meet tax and contractual obligations. Marketing leads are deleted
        within 24 months of inactivity.
      </p>

      <h2>7. Contact</h2>
      <p>
        Data requests: <a href="mailto:privacy@socialspark.pk">privacy@socialspark.pk</a>
        <br />
        Address: Social Spark, Lahore, Pakistan.
      </p>
    </LegalLayout>
  ),
});
