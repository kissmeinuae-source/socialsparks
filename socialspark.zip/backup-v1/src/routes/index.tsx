import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/home/Hero";
import { MarqueeTicker } from "@/components/home/MarqueeTicker";
import { TrustStrip } from "@/components/home/TrustStrip";
import { Services } from "@/components/home/Services";
import { Statistics } from "@/components/home/Statistics";
import { Process } from "@/components/home/Process";
import { FreeAudit } from "@/components/home/FreeAudit";
import { Pricing } from "@/components/home/Pricing";
import { Testimonials } from "@/components/home/Testimonials";
import { FAQ } from "@/components/home/FAQ";
import { About } from "@/components/home/About";
import { BookACall } from "@/components/home/BookACall";
import { Contact } from "@/components/home/Contact";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Social Spark — Digital Marketing Agency | Lahore, Pakistan" },
      {
        name: "description",
        content:
          "Social Spark is Pakistan's premium digital marketing agency. Social media, paid ads, website design for SMBs and public figures. Based in Lahore. Book a free call.",
      },
      {
        property: "og:title",
        content: "Social Spark — Digital Marketing Agency | Lahore, Pakistan",
      },
      {
        property: "og:description",
        content:
          "Premium digital marketing for Pakistan's most recognisable brands and personalities. No vanity metrics — measurable growth.",
      },
      { property: "og:url", content: "/" },
      { property: "og:type", content: "website" },
      {
        name: "twitter:title",
        content: "Social Spark — Digital Marketing Agency | Lahore, Pakistan",
      },
      {
        name: "twitter:description",
        content:
          "Premium digital marketing for Pakistan's most recognisable brands and personalities.",
      },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: "Social Spark",
          url: "/",
          image: "/og-image.png",
          logo: "/logo.png",
          description:
            "Premium digital marketing agency in Lahore, Pakistan. Social media, paid ads, website design for SMBs and public figures.",
          telephone: "+92-300-0000000",
          address: {
            "@type": "PostalAddress",
            addressLocality: "Lahore",
            addressRegion: "Punjab",
            addressCountry: "PK",
          },
          areaServed: "PK",
          priceRange: "$$",
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <MarqueeTicker />
      <TrustStrip />
      <Services />
      <Statistics />
      <Process />
      <FreeAudit />
      <Pricing />
      <Testimonials />
      <FAQ />
      <About />
      <BookACall />
      <Contact />
    </>
  );
}
