import { createFileRoute } from "@tanstack/react-router";
import { Contact } from "@/components/home/Contact";
import { FadeSlide } from "@/components/anim/FadeSlide";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Social Spark" },
      {
        name: "description",
        content:
          "Contact Social Spark in Lahore. Email, WhatsApp, or send us a message — we reply within one business day.",
      },
      { property: "og:title", content: "Contact — Social Spark" },
      {
        property: "og:description",
        content:
          "Get in touch with Social Spark — Lahore-based digital marketing agency.",
      },
      { property: "og:url", content: "/contact" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <>
      <section
        className="relative overflow-hidden"
        style={{ background: "var(--ss-ink)", padding: "120px 48px 64px" }}
      >
        <div className="relative mx-auto max-w-[900px] text-center">
          <FadeSlide>
            <div className="inline-flex items-center gap-3">
              <span className="h-px w-6 bg-gold" />
              <span className="t-label text-gold">CONTACT</span>
              <span className="h-px w-6 bg-gold" />
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h1
              className="mt-6 text-white"
              style={{ fontFamily: "var(--font-display)", fontWeight: 800 }}
            >
              Say hello.
            </h1>
          </FadeSlide>
          <FadeSlide delay={150}>
            <p
              className="mx-auto mt-6 max-w-[640px]"
              style={{ color: "var(--ss-ash)", fontSize: 17, lineHeight: 1.75 }}
            >
              Email, WhatsApp, or the form below. We reply within one Lahore
              business day.
            </p>
          </FadeSlide>
        </div>
      </section>
      <Contact />
    </>
  );
}
