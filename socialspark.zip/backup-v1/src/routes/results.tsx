import { createFileRoute } from "@tanstack/react-router";
import { FadeSlide } from "@/components/anim/FadeSlide";

export const Route = createFileRoute("/results")({
  head: () => ({
    meta: [
      { title: "Case Studies & Results — Social Spark" },
      {
        name: "description",
        content:
          "Real numbers from Pakistani restaurants, clinics, and media personalities we've worked with.",
      },
      { property: "og:title", content: "Case Studies & Results — Social Spark" },
      {
        property: "og:description",
        content:
          "Three case studies from Lahore-based brands — challenge, work, and measurable outcome.",
      },
      { property: "og:url", content: "/results" },

    ],

    links: [{ rel: "canonical", href: "/results" }],
    }),
  component: ResultsPage,
});

const cases = [
  {
    name: "Tandoor Tales",
    category: "RESTAURANT · LAHORE",
    challenge:
      "A family-run Lahori restaurant doing strong food but invisible online. Instagram followers stuck at 1,800 for 18 months. Walk-ins flat. Owner refused to lower prices to compete.",
    work: [
      "Repositioned around heritage and craft — moved away from generic food shots",
      "Switched to a tight weekly content rhythm: 3 reels, 2 carousels, daily stories",
      "Built a small but consistent paid budget targeting affluent Lahore neighbourhoods",
      "Trained one in-house person to shoot phone-first content during service",
      "Set up Google Business Profile properly for the first time in their 9-year history",
    ],
    results: [
      { n: "11.4k", l: "New followers in 6 months" },
      { n: "3.8×", l: "Weekend reservation lift" },
      { n: "47%", l: "Drop in cost per booking" },
    ],
    quote:
      "We always knew our food was good. They made the internet know it too. Friday nights are unrecognisable now.",
    by: "Imran S. — Owner, Tandoor Tales",
  },
  {
    name: "Dr. Rania Khan",
    category: "DERMATOLOGY · ISLAMABAD",
    challenge:
      "A senior dermatologist with twenty years' experience but a sparse online presence — patients couldn't verify her before booking. Old Facebook page, no Instagram, low Google review count.",
    work: [
      "Launched a clinical, calm Instagram identity — no before/after gimmicks",
      "Produced one long-form educational reel each week, in Urdu and English",
      "Reorganised the patient journey: ad → DM → WhatsApp consult → booking",
      "Ran 90-day Google review campaign that lifted the profile to 4.9 stars",
      "Wrote 6 evergreen blog posts so the clinic ranks for Islamabad searches",
    ],
    results: [
      { n: "5.6×", l: "More booked consults / month" },
      { n: "4.9", l: "Google rating, 240+ reviews" },
      { n: "−61%", l: "Cancellation rate" },
    ],
    quote:
      "I was hesitant to be on social media at all. They built something I'm proud to share with patients.",
    by: "Dr. Rania Khan",
  },
  {
    name: "Ahmed Khan",
    category: "PUBLIC FIGURE · KARACHI",
    challenge:
      "Established TV anchor with strong recognition but no commercial pipeline from his platforms. Brands approached him directly, but he had no media kit, no rate card, and no way to demonstrate engagement quality.",
    work: [
      "Built a public media kit and private brand-deck on his domain",
      "Restructured the content mix: 40% commentary, 40% behind-the-scenes, 20% brand",
      "Created a streamlined approval flow for brand partnerships",
      "Negotiated tiered packages that doubled his average per-post fee",
      "Set up monthly performance reports so brands re-book without asking",
    ],
    results: [
      { n: "2.1×", l: "Avg. brand deal value" },
      { n: "+38%", l: "Reels view-through rate" },
      { n: "8", l: "New retainer partnerships" },
    ],
    quote:
      "They treated my account like a business, not a vanity project. That changed everything.",
    by: "Ahmed Khan",
  },
];

function ResultsPage() {
  return (
    <>
      <section style={{ background: "var(--ss-paper)", padding: "120px 48px 64px" }}>
        <div className="mx-auto max-w-[1160px]">
          <FadeSlide>
            <div className="flex items-center gap-3">
              <span className="h-px w-6 bg-gold" />
              <span className="t-label text-gold">CASE STUDIES</span>
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h1 className="mt-5 text-navy">Real numbers, real brands.</h1>
          </FadeSlide>
          <FadeSlide delay={150}>
            <p
              className="mt-6 max-w-[640px]"
              style={{ color: "var(--ss-slate)", fontSize: 17, lineHeight: 1.75 }}
            >
              Three different categories. Same approach: understand the brand,
              build the right system, measure what matters.
            </p>
          </FadeSlide>
        </div>
      </section>

      <section style={{ background: "var(--ss-paper)", padding: "32px 48px 144px" }}>
        <div className="mx-auto flex max-w-[1160px] flex-col gap-24">
          {cases.map((c, i) => {
            const reverse = i % 2 === 1;
            return (
              <FadeSlide key={c.name}>
                <article
                  className={`grid gap-12 lg:grid-cols-[${reverse ? "40fr_60fr" : "60fr_40fr"}]`}
                  style={{
                    background: "white",
                    border: "1px solid var(--ss-rule)",
                    borderRadius: 14,
                    padding: 40,
                  }}
                >
                  <div style={{ order: reverse ? 2 : 1 }}>
                    <div className="t-label text-gold">{c.category}</div>
                    <h2
                      className="mt-2 text-navy"
                      style={{ fontFamily: "var(--font-display)", fontSize: 36 }}
                    >
                      {c.name}
                    </h2>
                    <p
                      className="mt-5"
                      style={{ color: "var(--ss-slate)", fontSize: 16, lineHeight: 1.75 }}
                    >
                      {c.challenge}
                    </p>

                    <div className="mt-8">
                      <div className="t-label" style={{ color: "var(--ss-ash)" }}>
                        WHAT WE DID
                      </div>
                      <ul className="mt-3 flex flex-col gap-2">
                        {c.work.map((w) => (
                          <li
                            key={w}
                            className="flex gap-3"
                            style={{ color: "var(--ss-slate)", fontSize: 15, lineHeight: 1.7 }}
                          >
                            <span className="text-gold" style={{ flexShrink: 0 }}>·</span>
                            {w}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <blockquote
                      className="mt-8 pl-5"
                      style={{
                        borderLeft: "2px solid var(--ss-gold)",
                        fontFamily: "var(--font-display)",
                        fontStyle: "italic",
                        fontSize: 18,
                        color: "var(--ss-navy)",
                        lineHeight: 1.5,
                      }}
                    >
                      "{c.quote}"
                      <footer
                        className="mt-3"
                        style={{
                          fontFamily: "var(--font-sans)",
                          fontStyle: "normal",
                          fontSize: 13,
                          color: "var(--ss-ash)",
                        }}
                      >
                        — {c.by}
                      </footer>
                    </blockquote>
                  </div>

                  <div style={{ order: reverse ? 1 : 2 }}>
                    <div
                      style={{
                        background: "var(--ss-ink)",
                        borderRadius: 14,
                        padding: 32,
                        display: "flex",
                        flexDirection: "column",
                        gap: 28,
                      }}
                    >
                      {c.results.map((r) => (
                        <div key={r.l}>
                          <div
                            className="text-gold"
                            style={{
                              fontFamily: "var(--font-display)",
                              fontWeight: 800,
                              fontSize: 56,
                              lineHeight: 1,
                              letterSpacing: "-0.03em",
                            }}
                          >
                            {r.n}
                          </div>
                          <div
                            className="mt-2"
                            style={{ color: "var(--ss-ash)", fontSize: 13 }}
                          >
                            {r.l}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </article>
              </FadeSlide>
            );
          })}
        </div>
      </section>
    </>
  );
}
