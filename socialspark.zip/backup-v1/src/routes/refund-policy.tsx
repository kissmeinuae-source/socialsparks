import { createFileRoute } from "@tanstack/react-router";
import { LegalLayout } from "@/components/legal/LegalLayout";

export const Route = createFileRoute("/refund-policy")({
  head: () => ({
    meta: [
      { title: "Refund Policy — Social Spark" },
      { name: "description", content: "Social Spark's 30-day satisfaction policy and refund process." },
      { property: "og:url", content: "/refund-policy" },

    ],

    links: [{ rel: "canonical", href: "/refund-policy" }],
    }),
  component: () => (
    <LegalLayout title="Refund Policy" updated="June 26, 2026">
      <p>
        We want you to feel the engagement is worth what you're paying for —
        from the first month onward. This policy explains when a refund is
        available, when it isn't, and how to request one.
      </p>

      <h2>30-day satisfaction clause</h2>
      <p>
        For any new monthly retainer, if you're genuinely unhappy with the
        work in the first 30 days, contact us. We will either fix the issue
        or refund 100% of that month's retainer fee (excluding ad spend
        already placed with third-party platforms).
      </p>

      <h2>What qualifies</h2>
      <ul>
        <li>Deliverables not produced within the timelines we agreed</li>
        <li>Work that falls materially short of the standard shown in our portfolio</li>
        <li>Mismatch with what was described in the signed proposal</li>
      </ul>

      <h2>What doesn't qualify</h2>
      <ul>
        <li>Platform-side performance changes (ad CPMs, algorithm shifts, account suspensions)</li>
        <li>Results not meeting projections — we never guarantee a specific outcome</li>
        <li>Work already delivered, approved, or published</li>
        <li>Ad spend already invoiced and placed with Meta, Google, or TikTok</li>
        <li>One-off projects after production has begun</li>
      </ul>

      <h2>How to request a refund</h2>
      <p>
        Email <a href="mailto:hello@socialspark.pk">hello@socialspark.pk</a>{" "}
        with your account name and a short description of the concern. We
        respond within 2 working days and process approved refunds via the
        original payment method within 7 working days.
      </p>
    </LegalLayout>
  ),
});
