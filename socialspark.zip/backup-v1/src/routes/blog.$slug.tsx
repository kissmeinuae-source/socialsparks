import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { posts } from "./blog.index";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = posts.find((p) => p.slug === params.slug);
    if (!post) throw notFound();
    return post;
  },
  head: ({ params, loaderData }) => ({
    meta: [
      { title: `${loaderData?.title ?? "Post"} — Social Spark` },
      { name: "description", content: loaderData?.excerpt ?? "" },
      { property: "og:title", content: loaderData?.title ?? "Post" },
      { property: "og:description", content: loaderData?.excerpt ?? "" },
      { property: "og:url", content: `/blog/${params.slug}` },
      { property: "og:type", content: "article" },
    ],
    links: [{ rel: "canonical", href: `/blog/${params.slug}` }],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-[720px] px-6 py-32 text-center">
      <h1 className="text-navy">Post not found</h1>
      <Link to="/blog" className="mt-6 inline-block text-gold underline">
        Back to all posts
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-[720px] px-6 py-32 text-center">
      <h1 className="text-navy">Couldn't load this post</h1>
      <p style={{ color: "var(--ss-slate)" }}>{error.message}</p>
    </div>
  ),
  component: BlogPost,
});

function BlogPost() {
  const post = Route.useLoaderData();
  // Only post 1 has full content; others reuse a stub
  const isFeatured = post.slug === "restaurant-instagram-2025";

  return (
    <article style={{ background: "var(--ss-paper)", padding: "120px 24px 144px" }}>
      <div className="mx-auto max-w-[720px]">
        <FadeSlide>
          <div className="flex items-center gap-3">
            <Link to="/blog" className="text-gold" style={{ fontSize: 13 }}>
              ← All posts
            </Link>
          </div>
        </FadeSlide>

        <FadeSlide delay={80}>
          <div className="mt-10">
            <div className="t-label text-gold">{post.category}</div>
            <h1 className="mt-3 text-navy" style={{ fontSize: "clamp(32px, 5vw, 48px)" }}>
              {post.title}
            </h1>
            <div
              className="mt-5 flex flex-wrap items-center gap-3"
              style={{ color: "var(--ss-ash)", fontSize: 13 }}
            >
              <span>By Social Spark Team</span>
              <span>·</span>
              <span>{post.date}</span>
              <span>·</span>
              <span>{post.read}</span>
            </div>
          </div>
        </FadeSlide>

        <FadeSlide delay={140}>
          {isFeatured ? <RestaurantInstagramBody /> : <StubBody excerpt={post.excerpt} />}
        </FadeSlide>

        {/* CTA */}
        <FadeSlide delay={200}>
          <div
            className="mt-16 text-center"
            style={{
              background: "var(--ss-ink)",
              padding: "48px 32px",
              borderRadius: 14,
            }}
          >
            <h3 className="text-white" style={{ fontSize: 24 }}>
              Ready to grow your restaurant?
            </h3>
            <p
              className="mx-auto mt-3 max-w-[440px]"
              style={{ color: "var(--ss-ash)", fontSize: 15 }}
            >
              Book a free 30-minute call. We'll review your current presence and
              show you exactly what to fix first.
            </p>
            <a
              href="/#book"
              className="mt-6 inline-block"
              style={{
                background: "var(--ss-gold)",
                color: "var(--ss-ink)",
                padding: "14px 28px",
                borderRadius: 6,
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: 14,
                textDecoration: "none",
              }}
            >
              Book a free call →
            </a>
          </div>
        </FadeSlide>
      </div>
    </article>
  );
}

const proseStyle: React.CSSProperties = {
  color: "var(--ss-slate)",
  fontSize: 17,
  lineHeight: 1.85,
};

function H2({ children }: { children: React.ReactNode }) {
  return (
    <h2
      className="text-navy"
      style={{
        marginTop: 56,
        marginBottom: 16,
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 28,
      }}
    >
      {children}
    </h2>
  );
}

function RestaurantInstagramBody() {
  return (
    <div className="mt-12" style={proseStyle}>
      <p>
        Walk into almost any restaurant in Lahore or Karachi today and ask the
        owner where their last ten customers came from. A growing share will
        say "Instagram" — either through a post they saw, a story their friend
        shared, or a reel that found them while they were scrolling on the way
        home. In 2025, your restaurant's Instagram isn't optional. It's part
        of the dining experience itself.
      </p>

      <H2>1. It's the new word of mouth</H2>
      <p>
        Pakistanis don't browse restaurant directories. They open Instagram,
        check a friend's story, save a reel, and decide. If your last post is
        from December, you've effectively told an entire generation of diners
        that you're closed.
      </p>

      <H2>2. Reels reach people search never will</H2>
      <p>
        A single well-shot reel — a sizzling karahi, a perfectly cut steak,
        the first crack of a crème brûlée — can reach more potential customers
        in 48 hours than a Google ad will all month. The platform actively
        rewards short, sensory food content, and the algorithm doesn't care
        whether you have ten followers or ten thousand.
      </p>

      <H2>3. It removes the booking friction</H2>
      <p>
        DMs are now a primary booking channel for restaurants in Pakistan.
        Customers prefer messaging over calling, and an Instagram inbox
        connected to WhatsApp Business makes the journey from "looks good" to
        "table booked" almost frictionless. No phone calls, no engaged tones,
        no language awkwardness.
      </p>

      <H2>4. It builds trust before they arrive</H2>
      <p>
        First-time diners scroll your grid the same way they scan a menu. If
        they see consistent quality, clean photography, and recent reviews
        re-shared in stories, they arrive already expecting a good time. That
        trust shows up in higher average spend, fewer complaints, and more
        repeat visits.
      </p>

      <H2>5. It's the cheapest marketing you'll ever do</H2>
      <p>
        A phone, decent lighting, and a consistent weekly rhythm are enough.
        You don't need a videographer, a studio, or a 200,000-rupee shoot.
        The restaurants growing fastest in Pakistan right now are the ones
        treating their phone like a marketing department.
      </p>

      <H2>The bottom line</H2>
      <p>
        Instagram in 2025 isn't a "nice to have" — it's how your restaurant
        gets discovered, booked, and remembered. The good news: the bar for
        most Pakistani restaurants is still low, which means showing up
        consistently puts you ahead of 80% of your competition. Start this
        week, not next month.
      </p>
    </div>
  );
}

function StubBody({ excerpt }: { excerpt: string }) {
  return (
    <div className="mt-12" style={proseStyle}>
      <p>{excerpt}</p>
      <p className="mt-6">Full article coming soon.</p>
    </div>
  );
}
