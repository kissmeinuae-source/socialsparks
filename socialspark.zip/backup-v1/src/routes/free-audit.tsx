import { createFileRoute } from "@tanstack/react-router";
import { FreeAudit } from "@/components/home/FreeAudit";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { Clock, Eye, Target } from "lucide-react";

export const Route = createFileRoute("/free-audit")({
  head: () => ({
    meta: [
      { title: "Free Social Media Audit — Social Spark" },
      {
        name: "description",
        content:
          "Get a free, personalised audit of your Instagram, Facebook and Google presence. Delivered within 24 hours.",
      },
      { property: "og:title", content: "Free Social Media Audit — Social Spark" },
      {
        property: "og:description",
        content:
          "Personalised Loom-recorded audit of your social presence — no charge, no pitch.",
      },
      { property: "og:url", content: "/free-audit" },

    ],

    links: [{ rel: "canonical", href: "/free-audit" }],
    }),
  component: FreeAuditPage,
});

function FreeAuditPage() {
  return (
    <>
      <section
        className="relative overflow-hidden"
        style={{
          background: "var(--ss-ink)",
          padding: "120px 48px 72px",
          minHeight: "60vh",
        }}
      >
        {/* atmosphere */}
        <div
          aria-hidden
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage:
              "linear-gradient(oklch(from var(--ss-gold) l c h / 0.04) 1px, transparent 1px), linear-gradient(90deg, oklch(from var(--ss-gold) l c h / 0.04) 1px, transparent 1px)",
            backgroundSize: "72px 72px",
            pointerEvents: "none",
          }}
        />
        <div
          aria-hidden
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            width: 800,
            height: 600,
            background:
              "radial-gradient(ellipse at top right, oklch(from var(--ss-gold) l c h / 0.07) 0%, transparent 60%)",
            pointerEvents: "none",
          }}
        />
        <div
          aria-hidden
          style={{
            position: "absolute",
            top: "52%",
            left: 0,
            right: 0,
            height: 1,
            background: "oklch(from var(--ss-gold) l c h / 0.18)",
          }}
        />

        <div className="relative mx-auto max-w-[900px] text-center">
          <FadeSlide>
            <div className="inline-flex items-center gap-3">
              <span className="h-px w-6 bg-gold" />
              <span className="t-label text-gold">FREE AUDIT</span>
              <span className="h-px w-6 bg-gold" />
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h1
              className="mt-6 text-white"
              style={{ fontFamily: "var(--font-display)", fontWeight: 800 }}
            >
              Your Free Social Media Audit.
            </h1>
          </FadeSlide>
          <FadeSlide delay={150}>
            <p
              className="mx-auto mt-6 max-w-[640px]"
              style={{ color: "var(--ss-ash)", fontSize: 17, lineHeight: 1.75 }}
            >
              We review your Instagram, Facebook and Google presence — content,
              consistency, conversion, ad setup, profile completeness — and send
              a personalised Loom video back within 24 hours. No pitch attached.
            </p>
          </FadeSlide>
        </div>
      </section>

      <FreeAudit />

      {/* Benefits */}
      <section style={{ background: "var(--ss-paper)", padding: "96px 48px" }}>
        <div className="mx-auto grid max-w-[1160px] gap-12 md:grid-cols-3">
          {[
            {
              Icon: Clock,
              title: "Delivered in 24h",
              text: "Recorded the same day you submit. No queues, no waiting weeks.",
            },
            {
              Icon: Eye,
              title: "Specific & honest",
              text: "We name the exact posts, settings and gaps holding your account back.",
            },
            {
              Icon: Target,
              title: "Action-ready",
              text: "Every observation comes with a clear next step you can apply yourself.",
            },
          ].map(({ Icon, title, text }, i) => (
            <FadeSlide key={title} delay={i * 80}>
              <div className="flex gap-4">
                <Icon size={28} style={{ color: "var(--ss-gold)", flexShrink: 0 }} />
                <div>
                  <h3 className="text-navy" style={{ fontSize: 18 }}>
                    {title}
                  </h3>
                  <p
                    className="mt-2"
                    style={{ color: "var(--ss-slate)", fontSize: 14, lineHeight: 1.7 }}
                  >
                    {text}
                  </p>
                </div>
              </div>
            </FadeSlide>
          ))}
        </div>
      </section>
    </>
  );
}
