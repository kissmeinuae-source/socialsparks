import { createFileRoute } from "@tanstack/react-router";
import { LegalLayout } from "@/components/legal/LegalLayout";

export const Route = createFileRoute("/terms-of-service")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Social Spark" },
      { name: "description", content: "The terms under which Social Spark provides services in Pakistan." },
      { property: "og:url", content: "/terms-of-service" },

    ],

    links: [{ rel: "canonical", href: "/terms-of-service" }],
    }),
  component: () => (
    <LegalLayout title="Terms of Service" updated="June 26, 2026">
      <p>
        These Terms govern the relationship between Social Spark (Private)
        Limited ("we") and you ("client") when you engage us for any digital
        marketing service. By signing a proposal, paying an invoice, or
        instructing us to begin work, you agree to these Terms.
      </p>

      <h2>1. Services</h2>
      <p>
        Services and deliverables are defined in the proposal or statement of
        work attached to each engagement. Anything outside that scope is
        treated as a change request and billed separately.
      </p>

      <h2>2. Payment</h2>
      <ul>
        <li>Monthly retainers are billed in advance on the same date each month</li>
        <li>One-off projects require a 50% deposit before work begins</li>
        <li>Invoices are due within 7 days; late payments may pause delivery</li>
        <li>All fees are in PKR and exclusive of GST unless stated</li>
      </ul>

      <h2>3. Cancellation</h2>
      <p>
        Either party may cancel a monthly retainer with 14 days' written
        notice. Work paid for before the notice period is delivered. Deposits
        for one-off projects are non-refundable once production has begun.
      </p>

      <h2>4. Intellectual property</h2>
      <p>
        Final, paid-for creative deliverables (images, video, copy) transfer
        to the client on receipt of full payment. Strategy frameworks,
        templates, and internal tools remain our property and are licensed for
        client use during the engagement.
      </p>

      <h2>5. Confidentiality</h2>
      <p>
        Both parties agree to keep non-public information shared during the
        engagement confidential, both during and after the relationship.
      </p>

      <h2>6. Liability</h2>
      <p>
        Our maximum liability for any claim is limited to the fees paid by the
        client in the three months preceding the claim. We are not liable for
        third-party platform decisions (ad disapprovals, account suspensions,
        algorithm changes).
      </p>

      <h2>7. Governing law</h2>
      <p>
        These Terms are governed by the laws of the Islamic Republic of
        Pakistan. Any disputes will be resolved in the courts of Lahore.
      </p>

      <h2>8. Contact</h2>
      <p>
        Questions: <a href="mailto:legal@socialspark.pk">legal@socialspark.pk</a>
      </p>
    </LegalLayout>
  ),
});
