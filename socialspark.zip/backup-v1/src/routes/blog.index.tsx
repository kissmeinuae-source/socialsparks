import { createFileRoute, Link } from "@tanstack/react-router";
import { FadeSlide } from "@/components/anim/FadeSlide";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Insights — Social Spark Blog" },
      {
        name: "description",
        content:
          "Practical writing on social media, paid ads, and digital growth for Pakistani businesses.",
      },
      { property: "og:title", content: "Insights — Social Spark Blog" },
      {
        property: "og:description",
        content:
          "Field notes from a Lahore-based agency working with restaurants, clinics, salons and public figures.",
      },
      { property: "og:url", content: "/blog" },

    ],

    links: [{ rel: "canonical", href: "/blog" }],
    }),
  component: BlogIndex,
});

export const posts = [
  {
    slug: "restaurant-instagram-2025",
    category: "SOCIAL MEDIA",
    title: "5 Reasons Your Restaurant Needs Instagram in 2025",
    excerpt:
      "If your restaurant isn't on Instagram in 2025, you're invisible to a whole generation of diners. Here's why — and what to do about it.",
    date: "Jun 12, 2025",
    read: "6 min read",
  },
  {
    slug: "pakistani-meta-ads-budget",
    category: "PAID ADS",
    title: "How Pakistani Businesses Win With Meta Ads on a Tight Budget",
    excerpt:
      "Spending less than PKR 30,000 a month on Meta? Here's how to make every rupee work harder without spraying budget.",
    date: "May 28, 2025",
    read: "8 min read",
  },
  {
    slug: "salon-social-media-guide",
    category: "CONTENT",
    title: "The Complete Social Media Guide for Salons and Beauty Businesses",
    excerpt:
      "A practical playbook for salons, clinics, and beauty brands — from content cadence to bookings via DM.",
    date: "May 14, 2025",
    read: "10 min read",
  },
];

function BlogIndex() {
  return (
    <section style={{ background: "var(--ss-paper)", padding: "120px 48px 144px" }}>
      <div className="mx-auto max-w-[1160px]">
        <FadeSlide>
          <div className="flex items-center gap-3">
            <span className="h-px w-6 bg-gold" />
            <span className="t-label text-gold">JOURNAL</span>
          </div>
        </FadeSlide>
        <FadeSlide delay={80}>
          <h1 className="mt-5 text-navy">Insights.</h1>
        </FadeSlide>
        <FadeSlide delay={140}>
          <p
            className="mt-5 max-w-[640px]"
            style={{ color: "var(--ss-slate)", fontSize: 17, lineHeight: 1.75 }}
          >
            Field notes from a small Lahore agency. No fluff, no listicles —
            just what we've actually seen work for Pakistani brands.
          </p>
        </FadeSlide>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {posts.map((p, i) => (
            <FadeSlide key={p.slug} delay={i * 80}>
              <Link
                to="/blog/$slug"
                params={{ slug: p.slug }}
                className="group block h-full transition-transform hover:-translate-y-1"
                style={{
                  background: "white",
                  border: "1px solid var(--ss-rule)",
                  borderRadius: 14,
                  padding: 28,
                  textDecoration: "none",
                  height: "100%",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <div className="t-label text-gold">{p.category}</div>
                <h2
                  className="mt-3 text-navy"
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 22,
                    lineHeight: 1.25,
                  }}
                >
                  {p.title}
                </h2>
                <p
                  className="mt-4 flex-1"
                  style={{
                    color: "var(--ss-slate)",
                    fontSize: 14,
                    lineHeight: 1.7,
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                    overflow: "hidden",
                  }}
                >
                  {p.excerpt}
                </p>
                <div
                  className="mt-6 flex items-center gap-3"
                  style={{ color: "var(--ss-ash)", fontSize: 13 }}
                >
                  <span>{p.date}</span>
                  <span>·</span>
                  <span>{p.read}</span>
                </div>
              </Link>
            </FadeSlide>
          ))}
        </div>
      </div>
    </section>
  );
}
