import { createFileRoute } from "@tanstack/react-router";
import { BookACall } from "@/components/home/BookACall";
import { FadeSlide } from "@/components/anim/FadeSlide";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: "Book a Call — Social Spark" },
      {
        name: "description",
        content:
          "Book a free 30-minute strategy call with Social Spark. We'll review your social media, paid ads, and growth opportunities — no obligation.",
      },
      { property: "og:title", content: "Book a Call — Social Spark" },
      {
        property: "og:description",
        content:
          "Free 30-minute strategy call. Honest feedback on your social, ads, and digital growth.",
      },
      { property: "og:url", content: "/book" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: "/book" }],
  }),
  component: BookPage,
});

function BookPage() {
  return (
    <>
      <section
        className="relative overflow-hidden"
        style={{ background: "var(--ss-ink)", padding: "120px 48px 64px" }}
      >
        <div
          aria-hidden
          style={{
            position: "absolute",
            top: "55%",
            left: 0,
            right: 0,
            height: 1,
            background: "oklch(from var(--ss-gold) l c h / 0.18)",
          }}
        />
        <div className="relative mx-auto max-w-[900px] text-center">
          <FadeSlide>
            <div className="inline-flex items-center gap-3">
              <span className="h-px w-6 bg-gold" />
              <span className="t-label text-gold">BOOK A CALL</span>
              <span className="h-px w-6 bg-gold" />
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h1
              className="mt-6 text-white"
              style={{ fontFamily: "var(--font-display)", fontWeight: 800 }}
            >
              Let's talk for 30 minutes.
            </h1>
          </FadeSlide>
          <FadeSlide delay={150}>
            <p
              className="mx-auto mt-6 max-w-[640px]"
              style={{ color: "var(--ss-ash)", fontSize: 17, lineHeight: 1.75 }}
            >
              No deck. No pitch. Tell us where you're stuck, we'll tell you
              what we'd do — and whether we're the right fit.
            </p>
          </FadeSlide>
        </div>
      </section>
      <BookACall />
    </>
  );
}
