import type { ReactNode } from "react";
import { FadeSlide } from "@/components/anim/FadeSlide";

export function LegalLayout({
  title,
  updated,
  children,
}: {
  title: string;
  updated: string;
  children: ReactNode;
}) {
  return (
    <section style={{ background: "var(--ss-paper)", padding: "120px 24px 144px" }}>
      <div className="mx-auto max-w-[720px]">
        <FadeSlide>
          <h1
            className="text-navy"
            style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
          >
            {title}
          </h1>
        </FadeSlide>
        <FadeSlide delay={80}>
          <p className="mt-3" style={{ color: "var(--ss-ash)", fontSize: 13 }}>
            Last updated: {updated}
          </p>
        </FadeSlide>
        <FadeSlide delay={140}>
          <div
            className="mt-10 legal-prose"
            style={{ color: "var(--ss-slate)", fontSize: 16, lineHeight: 1.85 }}
          >
            {children}
          </div>
        </FadeSlide>
      </div>
      <style>{`
        .legal-prose h2 {
          color: var(--ss-navy);
          font-family: var(--font-display);
          font-weight: 700;
          font-size: 22px;
          margin-top: 40px;
          margin-bottom: 14px;
        }
        .legal-prose h3 {
          color: var(--ss-navy);
          font-family: var(--font-display);
          font-weight: 700;
          font-size: 17px;
          margin-top: 24px;
          margin-bottom: 8px;
        }
        .legal-prose p { margin-bottom: 16px; }
        .legal-prose ul { margin: 8px 0 20px; padding-left: 22px; list-style: disc; }
        .legal-prose li { margin-bottom: 6px; }
        .legal-prose a { color: var(--ss-gold); text-decoration: underline; }
        .legal-prose table {
          width: 100%;
          border-collapse: collapse;
          margin: 20px 0;
          font-size: 14px;
        }
        .legal-prose th, .legal-prose td {
          text-align: left;
          padding: 12px 14px;
          border-bottom: 1px solid var(--ss-rule);
        }
        .legal-prose th {
          background: var(--ss-smoke);
          color: var(--ss-navy);
          font-weight: 700;
        }
      `}</style>
    </section>
  );
}
