import type { ElementType, ReactNode } from "react";
import { useInView } from "@/hooks/use-in-view";

interface FadeSlideProps {
  children: ReactNode;
  as?: ElementType;
  className?: string;
  /** Delay in ms before this element starts revealing. */
  delay?: number;
}

/**
 * opacity 0 + translateY(24px) → visible. 550ms ease-out.
 * Triggered when scrolled into view (threshold 0.12).
 */
export function FadeSlide({
  children,
  as,
  className = "",
  delay = 0,
}: FadeSlideProps) {
  const Tag = (as ?? "div") as ElementType;
  const [ref, inView] = useInView<HTMLElement>({ threshold: 0.12 });

  return (
    <Tag
      ref={ref}
      className={`ss-fade-slide${inView ? " is-in" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}
