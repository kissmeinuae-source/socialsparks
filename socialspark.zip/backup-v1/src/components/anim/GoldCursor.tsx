import { useEffect, useRef } from "react";

interface GoldCursorProps {
  /** Glow diameter in px. Default 200. */
  size?: number;
  /** Glow opacity 0–1. Default 0.12. */
  opacity?: number;
  className?: string;
}

/**
 * Renders a 200px radial gold glow that follows the cursor inside its parent.
 * Use on dark-bg sections only. Pointer-events: none, z-index: 0. The parent
 * should be position: relative.
 */
export function GoldCursor({
  size = 200,
  opacity = 0.12,
  className = "",
}: GoldCursorProps) {
  const dotRef = useRef<HTMLDivElement | null>(null);
  const parentRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const dot = dotRef.current;
    if (!dot) return;
    const parent = dot.parentElement as HTMLElement | null;
    if (!parent) return;
    parentRef.current = parent;

    if (typeof window !== "undefined") {
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (reduce) return;
    }

    let raf = 0;
    let targetX = 0;
    let targetY = 0;
    let currentX = 0;
    let currentY = 0;

    const onMove = (e: MouseEvent) => {
      const rect = parent.getBoundingClientRect();
      targetX = e.clientX - rect.left;
      targetY = e.clientY - rect.top;
      if (!raf) raf = requestAnimationFrame(loop);
    };

    const onLeave = () => {
      dot.style.opacity = "0";
    };

    const onEnter = () => {
      dot.style.opacity = String(opacity);
    };

    const loop = () => {
      currentX += (targetX - currentX) * 0.18;
      currentY += (targetY - currentY) * 0.18;
      dot.style.transform = `translate3d(${currentX - size / 2}px, ${currentY - size / 2}px, 0)`;
      if (Math.abs(targetX - currentX) > 0.5 || Math.abs(targetY - currentY) > 0.5) {
        raf = requestAnimationFrame(loop);
      } else {
        raf = 0;
      }
    };

    parent.addEventListener("mousemove", onMove);
    parent.addEventListener("mouseenter", onEnter);
    parent.addEventListener("mouseleave", onLeave);

    return () => {
      parent.removeEventListener("mousemove", onMove);
      parent.removeEventListener("mouseenter", onEnter);
      parent.removeEventListener("mouseleave", onLeave);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [size, opacity]);

  return (
    <div
      ref={dotRef}
      aria-hidden
      className={`pointer-events-none absolute top-0 left-0 ${className}`}
      style={{
        width: size,
        height: size,
        zIndex: 0,
        opacity: 0,
        background: `radial-gradient(circle, var(--ss-gold) 0%, transparent 70%)`,
        transition: "opacity 300ms ease-out",
        willChange: "transform, opacity",
      }}
    />
  );
}
