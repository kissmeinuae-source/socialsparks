import { useMemo, type ElementType, type ReactNode } from "react";
import { useInView } from "@/hooks/use-in-view";

interface TextRevealProps {
  /** Plain text. Split by newline → one line per element. */
  children: string;
  as?: ElementType;
  className?: string;
  /** Stagger between lines in ms. Default 80ms. */
  stagger?: number;
  /** Delay before the first line starts, in ms. */
  delay?: number;
}

/**
 * Reveals each text line by animating clip-path: inset(0 0 100% 0) → inset(0).
 * One line per newline. Uses CSS transition (600ms ease-out per line).
 */
export function TextReveal({
  children,
  as,
  className = "",
  stagger = 80,
  delay = 0,
}: TextRevealProps) {
  const Tag = (as ?? "span") as ElementType;
  const [ref, inView] = useInView<HTMLElement>({ threshold: 0.12 });

  const lines = useMemo(() => children.split("\n"), [children]);

  return (
    <Tag ref={ref} className={className}>
      {lines.map((line, i) => (
        <span
          key={i}
          className={`ss-line-clip${inView ? " is-in" : ""}`}
          style={{ transitionDelay: `${delay + i * stagger}ms` }}
        >
          {line || "\u00A0"}
        </span>
      ))}
    </Tag>
  );
}

/**
 * When you need richer children (links, em, etc.) but still want the clip
 * reveal — wraps the whole block as one line.
 */
export function TextRevealBlock({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const [ref, inView] = useInView<HTMLDivElement>({ threshold: 0.12 });
  return (
    <div ref={ref} className={className}>
      <span
        className={`ss-line-clip${inView ? " is-in" : ""}`}
        style={{ transitionDelay: `${delay}ms` }}
      >
        {children}
      </span>
    </div>
  );
}
