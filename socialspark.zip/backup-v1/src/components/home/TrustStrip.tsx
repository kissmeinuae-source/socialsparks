import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

interface Client {
  initials: string;
  name: [string, string];
  role: [string, string];
  verified?: boolean;
  featured?: boolean;
}

const CLIENTS: Client[] = [
  {
    initials: "WB",
    name: ["Waseem Badami", "وسیم بادامی"],
    role: ["ARY News Anchor", "اے آر وائی نیوز اینکر"],
    verified: true,
    featured: true,
  },
  {
    initials: "FA",
    name: ["Faisal Abdullah", "فیصل عبداللہ"],
    role: ["Media Personality", "میڈیا شخصیت"],
  },
  {
    initials: "MK",
    name: ["Masala Kitchen", "مصالحہ کچن"],
    role: ["Restaurant, Lahore", "ریستوران، لاہور"],
  },
  {
    initials: "GS",
    name: ["Glow Studio", "گلو اسٹوڈیو"],
    role: ["Beauty Salon", "بیوٹی سیلون"],
  },
  {
    initials: "DH",
    name: ["Dr. Hassan Clinic", "ڈاکٹر حسن کلینک"],
    role: ["Dermatology", "ڈرمیٹولوجی"],
  },
];

const CATEGORIES: Array<[string, string]> = [
  ["Media Personalities.", "میڈیا شخصیات۔"],
  ["Restaurants.", "ریستوران۔"],
  ["Clinics & Salons.", "کلینکس اور سیلون۔"],
  ["Retail Brands.", "ریٹیل برانڈز۔"],
];

function VerifiedTick() {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 24 24"
      aria-label="Verified"
      style={{ marginLeft: 6, flexShrink: 0 }}
    >
      <path
        d="M12 2l2.39 2.42 3.39-.39.39 3.39L20.59 9.8 18.17 12l2.42 2.2-2.42 2.39.39 3.39-3.39-.39L12.78 22 12 19.58 11.22 22 8.83 19.58l-3.39.39.39-3.39L3.41 14.2 5.83 12 3.41 9.8l2.42-2.39-.39-3.39 3.39.39L9.61 2 12 4.42 12 2z"
        fill="var(--ss-gold)"
      />
      <path
        d="M8.5 12.5l2.5 2.5 4.5-5"
        stroke="var(--ss-ink)"
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ClientEntry({ client, t }: { client: Client; t: (e: string, u: string) => string }) {
  const featured = client.featured;
  const circleSize = featured ? 52 : 40;

  return (
    <div
      className="ss-client-entry"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: 12,
        padding: "0 36px",
        borderLeft: "1px solid var(--ss-line)",
        transition: "border-color 200ms ease",
        flex: featured ? "0 0 auto" : "1 1 0",
        minWidth: featured ? 220 : 160,
      }}
    >
      <span
        aria-hidden
        style={{
          width: circleSize,
          height: circleSize,
          borderRadius: "50%",
          backgroundColor: featured ? "var(--ss-navy)" : "var(--ss-ink)",
          border: featured
            ? "1.5px solid var(--ss-gold)"
            : "1px solid var(--ss-line)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: "var(--font-display)",
          fontWeight: featured ? 800 : 700,
          fontSize: featured ? 20 : 14,
          color: featured ? "var(--ss-gold)" : "var(--ss-ash)",
          letterSpacing: "0.02em",
        }}
      >
        {client.initials}
      </span>
      <div style={{ display: "flex", alignItems: "center" }}>
        <span
          className="ss-client-name"
          style={{
            fontFamily: "var(--font-display)",
            fontWeight: featured ? 700 : 600,
            fontSize: featured ? 16 : 14,
            color: "#fff",
            lineHeight: 1.2,
            transition: "color 200ms ease",
          }}
        >
          {t(client.name[0], client.name[1])}
        </span>
        {client.verified && <VerifiedTick />}
      </div>
      <span
        style={{
          fontFamily: "var(--font-sans)",
          fontSize: featured ? 13 : 12,
          color: "var(--ss-ash)",
          lineHeight: 1.3,
        }}
      >
        {t(client.role[0], client.role[1])}
      </span>
    </div>
  );
}

export function TrustStrip() {
  const { t } = useLanguage();

  return (
    <section
      id="clients"
      style={{
        backgroundColor: "var(--ss-ink)",
        padding: "72px 48px",
        position: "relative",
      }}
    >
      <div
        className="ss-trust-grid"
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "30% 70%",
          gap: 56,
          alignItems: "start",
        }}
      >
        {/* LEFT */}
        <FadeSlide>
          <div>
            <div
              style={{
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 10,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color: "var(--ss-gold)",
                marginBottom: 24,
              }}
            >
              {t("TRUSTED BY", "اعتماد کرتے ہیں")}
            </div>
            <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
              {CATEGORIES.map(([en, ur], i) => (
                <li
                  key={en}
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 24,
                    lineHeight: 1.2,
                    color: "#fff",
                    padding: "14px 0",
                    borderBottom:
                      i === CATEGORIES.length - 1
                        ? "none"
                        : "1px solid var(--ss-line)",
                  }}
                >
                  {t(en, ur)}
                </li>
              ))}
            </ul>
          </div>
        </FadeSlide>

        {/* RIGHT */}
        <FadeSlide delay={150}>
          <div
            className="ss-clients-row"
            style={{
              display: "flex",
              alignItems: "stretch",
              flexWrap: "nowrap",
              overflowX: "auto",
              paddingBottom: 4,
            }}
          >
            {CLIENTS.map((c) => (
              <ClientEntry key={c.initials} client={c} t={t} />
            ))}
          </div>
        </FadeSlide>
      </div>

      <style>{`
        .ss-client-entry:hover { border-left-color: var(--ss-gold) !important; }
        .ss-client-entry:hover .ss-client-name { color: var(--ss-gold) !important; }
        .ss-clients-row::-webkit-scrollbar { height: 4px; }
        @media (max-width: 959px) {
          .ss-trust-grid { grid-template-columns: 1fr !important; gap: 40px !important; }
          .ss-clients-row {
            flex-direction: column !important;
            overflow: visible !important;
          }
          .ss-client-entry {
            border-left: none !important;
            border-top: 1px solid var(--ss-line);
            padding: 24px 0 !important;
            flex-direction: row !important;
            align-items: center !important;
            gap: 18px !important;
            min-width: 0 !important;
          }
          .ss-client-entry:hover {
            border-left-color: transparent !important;
            border-top-color: var(--ss-gold) !important;
          }
        }
      `}</style>
    </section>
  );
}
