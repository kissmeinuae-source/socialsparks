import { useState, type FormEvent } from "react";
import { z } from "zod";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

const auditSchema = z.object({
  business: z
    .string()
    .trim()
    .nonempty({ message: "Business name is required" })
    .max(100, { message: "Too long" }),
  social: z
    .string()
    .trim()
    .nonempty({ message: "Social URL is required" })
    .max(255, { message: "Too long" }),
  email: z
    .string()
    .trim()
    .email({ message: "Invalid email" })
    .max(255, { message: "Too long" }),
});

const inputStyle: React.CSSProperties = {
  width: "100%",
  backgroundColor: "#fff",
  border: "1.5px solid rgba(14,22,40,0.15)",
  borderRadius: 6,
  padding: "12px 14px",
  fontFamily: "var(--font-sans)",
  fontSize: 14,
  color: "var(--ss-ink)",
  outline: "none",
  transition: "border-color 180ms ease",
};

export function FreeAudit() {
  const { t } = useLanguage();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = {
      business: (form.elements.namedItem("business") as HTMLInputElement).value,
      social: (form.elements.namedItem("social") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
    };
    const result = auditSchema.safeParse(data);
    if (!result.success) {
      const next: Record<string, string> = {};
      for (const issue of result.error.issues) {
        next[issue.path[0] as string] = issue.message;
      }
      setErrors(next);
      return;
    }
    setErrors({});
    setSubmitted(true);
  };

  return (
    <section
      id="audit"
      style={{
        backgroundColor: "var(--ss-gold)",
        padding: "96px 48px",
      }}
    >
      <div
        className="ss-audit-grid"
        style={{
          maxWidth: 1160,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 80,
          alignItems: "center",
        }}
      >
        {/* LEFT */}
        <FadeSlide>
          <div>
            <div
              style={{
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 10,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color: "var(--ss-ink)",
                opacity: 0.6,
                marginBottom: 12,
              }}
            >
              {t("LIMITED TIME", "محدود وقت")}
            </div>
            <h2
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 800,
                fontSize: "var(--type-h2-size)",
                color: "var(--ss-ink)",
                letterSpacing: "-0.025em",
                lineHeight: 1.05,
                margin: "0 0 20px",
              }}
            >
              {t(
                "Get a Free Social Media Audit.",
                "مفت سوشل میڈیا آڈٹ حاصل کریں۔",
              )}
            </h2>
            <p
              style={{
                fontFamily: "var(--font-sans)",
                fontSize: 16,
                lineHeight: 1.75,
                color: "rgba(14,22,40,0.65)",
                margin: "0 0 24px",
                maxWidth: 520,
              }}
            >
              {t(
                "We record a personalised Loom video of your social pages — telling you exactly what's working, what isn't, and what to fix. No charge. No obligation. No sales call unless you want one.",
                "ہم آپ کے سوشل پیجز کی ذاتی Loom ویڈیو ریکارڈ کرتے ہیں — بتاتے ہیں کیا کام کر رہا ہے، کیا نہیں، اور کیا ٹھیک کرنا ہے۔ کوئی فیس نہیں، کوئی ذمہ داری نہیں۔",
              )}
            </p>
            <ul
              style={{
                listStyle: "none",
                margin: 0,
                padding: 0,
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              {[
                t("Delivered within 24 hours", "24 گھنٹوں میں فراہم"),
                t("Covers Instagram, Facebook & Google", "انسٹاگرام، فیس بک اور گوگل کا احاطہ"),
                t("200+ audits completed", "200+ آڈٹس مکمل"),
              ].map((line) => (
                <li
                  key={line}
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 13,
                    color: "var(--ss-ink)",
                    opacity: 0.6,
                  }}
                >
                  ✓ {line}
                </li>
              ))}
            </ul>
          </div>
        </FadeSlide>

        {/* RIGHT */}
        <FadeSlide delay={150}>
          {submitted ? (
            <div
              style={{
                backgroundColor: "#fff",
                borderRadius: 8,
                padding: 48,
                textAlign: "center",
              }}
            >
              <div
                aria-hidden
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: "50%",
                  backgroundColor: "var(--ss-gold)",
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  margin: "0 auto 20px",
                }}
              >
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M5 12l5 5 9-11"
                    stroke="var(--ss-ink)"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: 24,
                  color: "var(--ss-ink)",
                  margin: "0 0 8px",
                }}
              >
                {t("Audit requested.", "آڈٹ کی درخواست موصول۔")}
              </div>
              <div
                style={{
                  fontFamily: "var(--font-sans)",
                  fontSize: 14,
                  color: "var(--ss-slate)",
                }}
              >
                {t(
                  "Check your inbox within 24 hours.",
                  "24 گھنٹوں میں اپنا ان باکس چیک کریں۔",
                )}
              </div>
            </div>
          ) : (
            <form
              onSubmit={onSubmit}
              noValidate
              style={{ display: "flex", flexDirection: "column", gap: 14 }}
            >
              {[
                { name: "business", placeholder: t("Business name", "کاروبار کا نام"), type: "text", maxLength: 100 },
                { name: "social", placeholder: t("Social page URL", "سوشل پیج کا URL"), type: "text", maxLength: 255 },
                { name: "email", placeholder: t("Email address", "ای میل ایڈریس"), type: "email", maxLength: 255 },
              ].map((f) => (
                <div key={f.name}>
                  <input
                    name={f.name}
                    type={f.type}
                    placeholder={f.placeholder}
                    maxLength={f.maxLength}
                    aria-label={f.placeholder}
                    aria-invalid={!!errors[f.name]}
                    className="ss-audit-input"
                    style={inputStyle}
                  />
                  {errors[f.name] && (
                    <div
                      role="alert"
                      style={{
                        marginTop: 6,
                        fontFamily: "var(--font-sans)",
                        fontSize: 12,
                        color: "var(--ss-ink)",
                        fontWeight: 600,
                      }}
                    >
                      {errors[f.name]}
                    </div>
                  )}
                </div>
              ))}
              <button
                type="submit"
                className="ss-audit-submit"
                style={{
                  marginTop: 6,
                  width: "100%",
                  backgroundColor: "var(--ss-ink)",
                  color: "#fff",
                  border: 0,
                  padding: 14,
                  borderRadius: 6,
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: 14,
                  cursor: "pointer",
                  transition: "background-color 200ms ease",
                  letterSpacing: "0.02em",
                }}
              >
                {t("Request My Free Audit", "میرا مفت آڈٹ بھیجیں")}
              </button>
            </form>
          )}
        </FadeSlide>
      </div>

      <style>{`
        .ss-audit-input:focus {
          border-color: var(--ss-ink) !important;
          border-width: 1.5px !important;
        }
        .ss-audit-submit:hover { background-color: var(--ss-navy) !important; }
        @media (max-width: 880px) {
          .ss-audit-grid { grid-template-columns: 1fr !important; gap: 48px !important; }
        }
      `}</style>
    </section>
  );
}
