import { useLanguage } from "@/lib/language";

const ITEMS: Array<[string, string]> = [
  ["SOCIAL MEDIA MANAGEMENT", "سوشل میڈیا مینجمنٹ"],
  ["PAID ADVERTISING", "پیڈ ایڈورٹائزنگ"],
  ["WEBSITE DESIGN", "ویب سائٹ ڈیزائن"],
  ["SEO & LOCAL SEARCH", "ایس ای او اور لوکل سرچ"],
  ["CONTENT CREATION", "کنٹینٹ تخلیق"],
  ["VIDEO STRATEGY", "ویڈیو حکمت عملی"],
  ["BRAND IDENTITY", "برانڈ شناخت"],
  ["INSTAGRAM GROWTH", "انسٹاگرام گروتھ"],
];

function Bolt() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden>
      <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="var(--ss-ink)" />
    </svg>
  );
}

function Diamond() {
  return (
    <span
      aria-hidden
      style={{
        display: "inline-block",
        width: 4,
        height: 4,
        backgroundColor: "var(--ss-ink)",
        opacity: 0.3,
        transform: "rotate(45deg)",
        margin: "0 28px",
      }}
    />
  );
}

export function MarqueeTicker() {
  const { t } = useLanguage();

  const renderRun = (key: string) =>
    ITEMS.map(([en, ur], i) => (
      <span
        key={`${key}-${i}`}
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 10,
          padding: "0 22px",
        }}
      >
        <Bolt />
        <span
          style={{
            fontFamily: "var(--font-display)",
            fontWeight: 700,
            fontSize: 13,
            letterSpacing: "0.05em",
            textTransform: "uppercase",
            color: "var(--ss-ink)",
          }}
        >
          {t(en, ur)}
        </span>
        <Diamond />
      </span>
    ));

  return (
    <div
      aria-hidden
      style={{
        position: "relative",
        width: "100%",
        height: 48,
        backgroundColor: "var(--ss-gold)",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
      }}
    >
      <div
        className="ss-marquee-track"
        style={{
          display: "inline-flex",
          alignItems: "center",
          whiteSpace: "nowrap",
          willChange: "transform",
          animation: "ss-marquee 35s linear infinite",
        }}
      >
        {renderRun("a")}
        {renderRun("b")}
      </div>
      <style>{`
        @keyframes ss-marquee {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
        @media (prefers-reduced-motion: reduce) {
          .ss-marquee-track { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
