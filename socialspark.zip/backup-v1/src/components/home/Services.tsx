import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

interface SecondaryService {
  num: string;
  icon: string;
  name: [string, string];
  desc: [string, string];
}

const SECONDARY: SecondaryService[] = [
  {
    num: "02",
    icon: "🎯",
    name: ["Paid Advertising", "پیڈ ایڈورٹائزنگ"],
    desc: [
      "Meta & Google campaigns that convert.",
      "میٹا اور گوگل مہمات جو نتائج لاتی ہیں۔",
    ],
  },
  {
    num: "03",
    icon: "🌐",
    name: ["Website Design", "ویب سائٹ ڈیزائن"],
    desc: [
      "Fast, mobile-first, built to sell.",
      "تیز، موبائل فرسٹ، فروخت کے لیے بنی۔",
    ],
  },
  {
    num: "04",
    icon: "✍️",
    name: ["Content Creation", "کنٹینٹ تخلیق"],
    desc: [
      "Urdu & English, on-brand, every day.",
      "اردو اور انگریزی، برانڈ کے مطابق، روزانہ۔",
    ],
  },
  {
    num: "05",
    icon: "🔍",
    name: ["SEO & Local Search", "ایس ای او اور لوکل سرچ"],
    desc: ["Found first, every time.", "ہر بار پہلے نمبر پر۔"],
  },
  {
    num: "06",
    icon: "🎬",
    name: ["Video & Reels", "ویڈیو اور ریلز"],
    desc: [
      "Scripts, edits, viral growth strategies.",
      "اسکرپٹ، ایڈٹس، وائرل گروتھ حکمت عملی۔",
    ],
  },
];

export function Services() {
  const { t } = useLanguage();

  return (
    <section
      id="services"
      style={{
        backgroundColor: "var(--ss-paper)",
        padding: "112px 48px",
      }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        {/* Header */}
        <FadeSlide>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
              marginBottom: 18,
            }}
          >
            <span
              aria-hidden
              style={{
                display: "inline-block",
                width: 2,
                height: 24,
                backgroundColor: "var(--ss-gold)",
              }}
            />
            <span
              style={{
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 11,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "var(--ss-ash)",
              }}
            >
              {t("WHAT WE DO", "ہم کیا کرتے ہیں")}
            </span>
          </div>
        </FadeSlide>

        <FadeSlide delay={120}>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: "var(--type-h2-size)",
              color: "var(--ss-navy)",
              letterSpacing: "-0.025em",
              lineHeight: 1.05,
              margin: 0,
              maxWidth: 880,
            }}
          >
            {t(
              "Every Digital Service Your Business Needs.",
              "ہر ڈیجیٹل سروس جو آپ کے کاروبار کو چاہیے۔",
            )}
          </h2>
        </FadeSlide>

        {/* Featured card */}
        <FadeSlide delay={240}>
          <a
            href="#services"
            className="ss-service-featured"
            style={{
              display: "block",
              marginTop: 64,
              backgroundColor: "#fff",
              border: "1px solid var(--ss-rule)",
              borderLeft: "1px solid var(--ss-rule)",
              borderRadius: 16,
              padding: 48,
              textDecoration: "none",
              color: "inherit",
              transition: "border-color 220ms ease, border-left-width 220ms ease",
            }}
          >
            <div
              className="ss-featured-grid"
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 2fr",
                gap: 48,
                alignItems: "center",
              }}
            >
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 800,
                  fontSize: 72,
                  color: "var(--ss-gold)",
                  lineHeight: 1,
                }}
              >
                01
              </div>
              <div>
                <h3
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 28,
                    color: "var(--ss-navy)",
                    margin: "0 0 14px",
                    letterSpacing: "-0.01em",
                  }}
                >
                  {t("Social Media Management", "سوشل میڈیا مینجمنٹ")}
                </h3>
                <p
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 16,
                    lineHeight: 1.7,
                    color: "var(--ss-slate)",
                    margin: "0 0 22px",
                    maxWidth: 560,
                  }}
                >
                  {t(
                    "Daily Instagram, Facebook, and TikTok management — strategy, posting, engagement, and growth — handled end-to-end by a Lahore-based team that lives in the platforms your audience scrolls.",
                    "روزانہ انسٹاگرام، فیس بک اور ٹک ٹاک کا انتظام — حکمت عملی، پوسٹنگ، اینگیجمنٹ اور گروتھ — لاہور میں موجود ٹیم آپ کے سامعین کے پلیٹ فارمز پر مکمل سنبھالتی ہے۔",
                  )}
                </p>
                <span
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 14,
                    color: "var(--ss-navy)",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 8,
                  }}
                >
                  {t("Explore", "دریافت کریں")}
                  <span aria-hidden>→</span>
                </span>
              </div>
            </div>
          </a>
        </FadeSlide>

        {/* Secondary 5-col grid */}
        <div
          className="ss-services-grid"
          style={{
            marginTop: 22,
            display: "grid",
            gridTemplateColumns: "repeat(5, minmax(0, 1fr))",
            gap: 18,
          }}
        >
          {SECONDARY.map((s, i) => (
            <FadeSlide key={s.num} delay={320 + i * 80}>
              <a
                href="#services"
                className="ss-service-card"
                style={{
                  display: "block",
                  backgroundColor: "#fff",
                  border: "1px solid var(--ss-rule)",
                  borderLeft: "1px solid var(--ss-rule)",
                  borderRadius: 14,
                  padding: "28px 24px",
                  textDecoration: "none",
                  color: "inherit",
                  transition:
                    "transform 220ms ease, box-shadow 220ms ease, border-color 220ms ease, border-left-width 220ms ease",
                  height: "100%",
                }}
              >
                <div
                  aria-hidden
                  style={{
                    fontSize: 24,
                    lineHeight: 1,
                    marginBottom: 16,
                  }}
                >
                  {s.icon}
                </div>
                <h4
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 16,
                    color: "var(--ss-navy)",
                    margin: "0 0 8px",
                    letterSpacing: "-0.005em",
                  }}
                >
                  {t(s.name[0], s.name[1])}
                </h4>
                <p
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 13,
                    lineHeight: 1.55,
                    color: "var(--ss-ash)",
                    margin: 0,
                  }}
                >
                  {t(s.desc[0], s.desc[1])}
                </p>
              </a>
            </FadeSlide>
          ))}
        </div>
      </div>

      <style>{`
        .ss-service-featured:hover {
          border-left: 3px solid var(--ss-gold) !important;
        }
        .ss-service-card:hover {
          border-left: 2px solid var(--ss-gold) !important;
          transform: translateY(-3px);
          box-shadow: 0 8px 24px rgba(28,41,81,0.07);
        }
        @media (max-width: 1100px) {
          .ss-services-grid { grid-template-columns: repeat(3, minmax(0, 1fr)) !important; }
        }
        @media (max-width: 720px) {
          .ss-services-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .ss-featured-grid { grid-template-columns: 1fr !important; gap: 20px !important; }
        }
        @media (max-width: 480px) {
          .ss-services-grid { grid-template-columns: 1fr !important; }
        }
        @media (prefers-reduced-motion: reduce) {
          .ss-service-card:hover { transform: none !important; }
        }
      `}</style>
    </section>
  );
}
