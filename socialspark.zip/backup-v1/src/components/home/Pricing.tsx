import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

interface Plan {
  tier: [string, string];
  price: string;
  features: Array<[string, string]>;
  featured?: boolean;
  cta: [string, string];
}

const PLANS: Plan[] = [
  {
    tier: ["STARTER", "اسٹارٹر"],
    price: "35,000",
    cta: ["Choose Starter", "اسٹارٹر منتخب کریں"],
    features: [
      ["2 social platforms managed", "2 سوشل پلیٹ فارمز کا انتظام"],
      ["12 posts per month", "ماہانہ 12 پوسٹس"],
      ["Graphic design included", "گرافک ڈیزائن شامل"],
      ["Monthly performance report", "ماہانہ کارکردگی رپورٹ"],
      ["WhatsApp support", "واٹس ایپ سپورٹ"],
    ],
  },
  {
    tier: ["GROWTH", "گروتھ"],
    price: "75,000",
    featured: true,
    cta: ["Choose Growth", "گروتھ منتخب کریں"],
    features: [
      ["4 platforms including TikTok", "4 پلیٹ فارمز بشمول ٹک ٹاک"],
      ["24 posts + 8 stories monthly", "ماہانہ 24 پوسٹس + 8 اسٹوریز"],
      ["Meta & Google ad management", "میٹا اور گوگل ایڈز کا انتظام"],
      ["Reel scripting & strategy", "ریل اسکرپٹنگ اور حکمت عملی"],
      ["Dedicated account manager", "اکاؤنٹ مینیجر مختص"],
      ["Weekly reporting", "ہفتہ وار رپورٹنگ"],
    ],
  },
  {
    tier: ["PREMIUM", "پریمیم"],
    price: "140,000",
    cta: ["Choose Premium", "پریمیم منتخب کریں"],
    features: [
      ["All platforms, no restrictions", "تمام پلیٹ فارمز، بغیر پابندی"],
      ["Unlimited content production", "لامحدود کنٹینٹ پروڈکشن"],
      ["Full ad account management", "مکمل ایڈ اکاؤنٹ مینجمنٹ"],
      ["Bilingual SEO (Urdu + English)", "دو لسانی SEO (اردو + انگریزی)"],
      ["Daily reporting dashboard", "روزانہ رپورٹنگ ڈیش بورڈ"],
      ["Priority support, always-on", "ترجیحی سپورٹ، ہر وقت"],
    ],
  },
];

function GoldDot() {
  return (
    <span
      aria-hidden
      style={{
        display: "inline-block",
        width: 4,
        height: 4,
        borderRadius: "50%",
        backgroundColor: "var(--ss-gold)",
        marginRight: 12,
        flexShrink: 0,
        marginTop: 9,
      }}
    />
  );
}

function PlanCard({ plan, t }: { plan: Plan; t: (e: string, u: string) => string }) {
  const featured = plan.featured;
  return (
    <div
      className={`ss-plan-card${featured ? " is-featured" : ""}`}
      style={{
        position: "relative",
        backgroundColor: "#fff",
        border: featured ? "1.5px solid var(--ss-navy)" : "1px solid var(--ss-rule)",
        borderRadius: 16,
        padding: featured ? "44px 32px" : "32px 28px",
        marginTop: featured ? -28 : 0,
        marginBottom: featured ? -28 : 0,
        boxShadow: featured ? "0 24px 72px rgba(28,41,81,0.14)" : "none",
        display: "flex",
        flexDirection: "column",
        height: "auto",
      }}
    >
      <div
        style={{
          fontFamily: "var(--font-sans)",
          fontWeight: 700,
          fontSize: 10,
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          color: "var(--ss-ash)",
        }}
      >
        {t(plan.tier[0], plan.tier[1])}
      </div>

      <div
        style={{
          marginTop: 18,
          fontFamily: "var(--font-sans)",
          fontWeight: 500,
          fontSize: 13,
          color: "var(--ss-ash)",
        }}
      >
        PKR
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginTop: 2 }}>
        <span
          style={{
            fontFamily: "var(--font-display)",
            fontWeight: 800,
            fontSize: 52,
            lineHeight: 1,
            letterSpacing: "-0.02em",
            color: featured ? "var(--ss-ink)" : "var(--ss-navy)",
          }}
        >
          {plan.price}
        </span>
        <span
          style={{
            fontFamily: "var(--font-sans)",
            fontWeight: 400,
            fontSize: 18,
            color: "var(--ss-ash)",
          }}
        >
          /{t("mo", "ماہ")}
        </span>
      </div>

      <div
        style={{
          marginTop: 24,
          marginBottom: 20,
          height: 1,
          backgroundColor: "var(--ss-rule)",
        }}
      />

      <ul style={{ listStyle: "none", margin: 0, padding: 0, flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
        {plan.features.map(([en, ur]) => (
          <li
            key={en}
            style={{
              display: "flex",
              alignItems: "flex-start",
              fontFamily: "var(--font-sans)",
              fontSize: 14,
              lineHeight: 1.55,
              color: "var(--ss-slate)",
            }}
          >
            <GoldDot />
            <span>{t(en, ur)}</span>
          </li>
        ))}
      </ul>

      <a
        href="#audit"
        className="ss-plan-cta"
        style={{
          marginTop: 28,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "12px 18px",
          borderRadius: 6,
          fontFamily: "var(--font-display)",
          fontWeight: 700,
          fontSize: 13,
          textDecoration: "none",
          letterSpacing: "0.02em",
          backgroundColor: featured ? "var(--ss-navy)" : "transparent",
          color: featured ? "#fff" : "var(--ss-navy)",
          border: featured ? "1.5px solid var(--ss-navy)" : "1.5px solid var(--ss-navy)",
          transition: "background-color 200ms ease, color 200ms ease",
        }}
      >
        {t(plan.cta[0], plan.cta[1])}
      </a>
    </div>
  );
}

export function Pricing() {
  const { t } = useLanguage();
  return (
    <section
      id="pricing"
      style={{ backgroundColor: "var(--ss-paper)", padding: "112px 48px" }}
    >
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <FadeSlide>
          <div style={{ textAlign: "center" }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 12,
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 11,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color: "var(--ss-ash)",
                marginBottom: 18,
              }}
            >
              <span style={{ width: 20, height: 1, backgroundColor: "var(--ss-gold)" }} />
              {t("PRICING", "قیمتیں")}
              <span style={{ width: 20, height: 1, backgroundColor: "var(--ss-gold)" }} />
            </div>
            <h2
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: "var(--type-h2-size)",
                color: "var(--ss-navy)",
                letterSpacing: "-0.025em",
                lineHeight: 1.05,
                margin: 0,
              }}
            >
              {t("Transparent Pricing. No Surprises.", "شفاف قیمتیں۔ کوئی حیرانی نہیں۔")}
            </h2>
            <p
              style={{
                marginTop: 16,
                fontFamily: "var(--font-sans)",
                fontSize: 16,
                color: "var(--ss-ash)",
                lineHeight: 1.6,
              }}
            >
              {t(
                "All plans in PKR. Month-to-month. Cancel with 30 days notice.",
                "تمام پلانز PKR میں۔ ماہانہ۔ 30 دن کے نوٹس پر منسوخ۔",
              )}
            </p>
          </div>
        </FadeSlide>

        <div
          className="ss-pricing-grid"
          style={{
            marginTop: 72,
            display: "grid",
            gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
            gap: 20,
            alignItems: "start",
          }}
        >
          {PLANS.map((p, i) => (
            <FadeSlide key={p.tier[0]} delay={i * 100}>
              <PlanCard plan={p} t={t} />
            </FadeSlide>
          ))}
        </div>

        <FadeSlide delay={360}>
          <p
            style={{
              marginTop: 56,
              textAlign: "center",
              fontFamily: "var(--font-sans)",
              fontSize: 13,
              color: "var(--ss-ash)",
            }}
          >
            {t(
              "Not sure which plan fits? The free call will tell us both.",
              "یقین نہیں کونسا پلان موزوں ہے؟ مفت کال سے ہمیں دونوں کو معلوم ہو جائے گا۔",
            )}{" "}
            <a
              href="#audit"
              style={{
                color: "var(--ss-navy)",
                textDecoration: "underline",
                textUnderlineOffset: 3,
                fontWeight: 600,
              }}
            >
              {t("Book a free call", "مفت کال بک کریں")}
            </a>
          </p>
        </FadeSlide>
      </div>

      <style>{`
        .ss-plan-cta:hover {
          background-color: var(--ss-navy) !important;
          color: #fff !important;
        }
        .ss-plan-card.is-featured .ss-plan-cta:hover {
          background-color: var(--ss-ink) !important;
          border-color: var(--ss-ink) !important;
        }
        @media (max-width: 960px) {
          .ss-pricing-grid { grid-template-columns: 1fr !important; gap: 32px !important; }
          .ss-plan-card { margin-top: 0 !important; margin-bottom: 0 !important; }
        }
      `}</style>
    </section>
  );
}
