import { useState } from "react";
import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

interface QA {
  q: [string, string];
  a: [string, string];
}

const ITEMS: QA[] = [
  {
    q: ["How quickly will I see results?", "نتائج کب نظر آئیں گے؟"],
    a: [
      "Most clients see meaningful engagement growth within 2–3 weeks. Paid ad campaigns can show results within 3–5 days of going live. Organic follower growth and lead generation typically strengthens significantly in month 2.",
      "زیادہ تر کلائنٹس کو 2 سے 3 ہفتوں میں اینگیجمنٹ میں واضح اضافہ نظر آتا ہے۔ پیڈ اشتہاری مہمات لائیو ہونے کے 3 سے 5 دن میں نتائج دکھا سکتی ہیں۔ آرگینک فالوورز اور لیڈ جنریشن عام طور پر دوسرے ماہ میں نمایاں ہوتی ہے۔",
    ],
  },
  {
    q: ["Do you work in Urdu?", "کیا آپ اردو میں کام کرتے ہیں؟"],
    a: [
      "Yes — all content, reports and communication can be entirely in Urdu. Many of our Pakistan-based clients prefer Urdu-first content, and we have native Urdu copywriters on the team.",
      "جی ہاں — تمام مواد، رپورٹس اور رابطہ مکمل طور پر اردو میں ہو سکتا ہے۔ ہمارے کئی پاکستانی کلائنٹس اردو فرسٹ مواد کو ترجیح دیتے ہیں، اور ہماری ٹیم میں مادری اردو کاپی رائٹرز شامل ہیں۔",
    ],
  },
  {
    q: ["Do you require my account passwords?", "کیا آپ کو میرے اکاؤنٹ پاس ورڈز چاہئیں؟"],
    a: [
      "Never. We manage pages through official platform-level admin access — Meta Business Manager, Google Business Profile manager. You remain the primary owner at all times.",
      "بالکل نہیں۔ ہم پلیٹ فارم کی سرکاری ایڈمن رسائی — میٹا بزنس مینیجر اور گوگل بزنس پروفائل مینیجر — کے ذریعے انتظام کرتے ہیں۔ آپ ہر وقت بنیادی مالک رہتے ہیں۔",
    ],
  },
  {
    q: ["Is there a minimum contract period?", "کیا کم از کم معاہدے کی مدت ہے؟"],
    a: [
      "No. Every plan runs month-to-month. We ask for 30 days notice to wrap up properly. No exit fees, no penalties.",
      "نہیں۔ ہر پلان ماہانہ بنیاد پر چلتا ہے۔ ہم مناسب طریقے سے بند کرنے کے لیے 30 دن کا نوٹس مانگتے ہیں۔ کوئی ایگزٹ فیس نہیں، کوئی جرمانہ نہیں۔",
    ],
  },
  {
    q: [
      "Do you manage celebrity and public figure accounts?",
      "کیا آپ سیلیبریٹی اور عوامی شخصیات کے اکاؤنٹس سنبھالتے ہیں؟",
    ],
    a: [
      "Yes, and this is a specific strength. We understand the sensitivities — PR-aware content, comment moderation, crisis response, verified account handling — and have active celebrity clients who trust us with accounts they cannot afford to get wrong.",
      "جی ہاں، یہ ہماری مخصوص مہارت ہے۔ ہم حساسیات کو سمجھتے ہیں — PR سے آگاہ مواد، کمنٹ ماڈریشن، بحران کا جواب، تصدیق شدہ اکاؤنٹ ہینڈلنگ — اور ہمارے فعال سیلیبریٹی کلائنٹس ہم پر ایسے اکاؤنٹس کا اعتماد کرتے ہیں جنہیں غلط نہیں ہونے دیا جا سکتا۔",
    ],
  },
  {
    q: [
      "What should I budget for paid ads on top of the management fee?",
      "مینجمنٹ فیس کے علاوہ پیڈ اشتہارات کے لیے کتنا بجٹ رکھوں؟",
    ],
    a: [
      "We recommend a minimum of PKR 15,000–20,000 per month in direct ad spend. This goes to Meta or Google directly — we do not take any percentage of ad spend.",
      "ہم ماہانہ کم از کم PKR 15,000 سے 20,000 براہ راست اشتہاری اخراجات کی تجویز کرتے ہیں۔ یہ رقم براہ راست میٹا یا گوگل کو جاتی ہے — ہم اشتہاری اخراجات کا کوئی فیصد نہیں لیتے۔",
    ],
  },
];

function Accordion({ items, t }: { items: QA[]; t: (e: string, u: string) => string }) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div>
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div
            key={item.q[0]}
            style={{ borderBottom: "1px solid var(--ss-rule)" }}
          >
            <button
              type="button"
              onClick={() => setOpen(isOpen ? null : i)}
              aria-expanded={isOpen}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 24,
                padding: "22px 0",
                background: "transparent",
                border: 0,
                cursor: "pointer",
                textAlign: "left",
              }}
            >
              <span
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: 16,
                  color: isOpen ? "var(--ss-gold)" : "var(--ss-navy)",
                  letterSpacing: "-0.005em",
                  transition: "color 200ms ease",
                  lineHeight: 1.35,
                }}
              >
                {t(item.q[0], item.q[1])}
              </span>
              <span
                aria-hidden
                style={{
                  flexShrink: 0,
                  width: 18,
                  height: 18,
                  position: "relative",
                  transition: "transform 250ms ease",
                  transform: isOpen ? "rotate(45deg)" : "rotate(0deg)",
                  color: isOpen ? "var(--ss-gold)" : "var(--ss-navy)",
                }}
              >
                <span
                  style={{
                    position: "absolute",
                    inset: 0,
                    margin: "auto",
                    width: 18,
                    height: 2,
                    backgroundColor: "currentColor",
                    top: 8,
                  }}
                />
                <span
                  style={{
                    position: "absolute",
                    inset: 0,
                    margin: "auto",
                    width: 2,
                    height: 18,
                    backgroundColor: "currentColor",
                    left: 8,
                  }}
                />
              </span>
            </button>
            <div
              style={{
                display: "grid",
                gridTemplateRows: isOpen ? "1fr" : "0fr",
                transition: "grid-template-rows 320ms ease",
              }}
            >
              <div style={{ overflow: "hidden" }}>
                <p
                  style={{
                    margin: 0,
                    paddingTop: 4,
                    paddingBottom: 22,
                    paddingRight: 32,
                    fontFamily: "var(--font-sans)",
                    fontSize: 15,
                    lineHeight: 1.8,
                    color: "var(--ss-ash)",
                  }}
                >
                  {t(item.a[0], item.a[1])}
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function FAQ() {
  const { t } = useLanguage();
  return (
    <section
      id="faq"
      style={{ backgroundColor: "var(--ss-paper)", padding: "112px 48px" }}
    >
      <div
        className="ss-faq-grid"
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "40% 60%",
          gap: 72,
          alignItems: "start",
        }}
      >
        <FadeSlide>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
              <span
                aria-hidden
                style={{ display: "inline-block", width: 2, height: 24, backgroundColor: "var(--ss-gold)" }}
              />
              <span
                style={{
                  fontFamily: "var(--font-sans)",
                  fontWeight: 700,
                  fontSize: 11,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  color: "var(--ss-ash)",
                }}
              >
                {t("FAQ", "عمومی سوالات")}
              </span>
            </div>
            <h2
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: "var(--type-h2-size)",
                color: "var(--ss-navy)",
                letterSpacing: "-0.025em",
                lineHeight: 1.05,
                margin: 0,
              }}
            >
              {t("Straight Answers.", "سیدھے جوابات۔")}
            </h2>
            <p
              style={{
                marginTop: 20,
                fontFamily: "var(--font-sans)",
                fontSize: 15,
                lineHeight: 1.75,
                color: "var(--ss-slate)",
                maxWidth: 360,
              }}
            >
              {t(
                "If you have a question we haven't covered here, send it to us directly. We respond personally within a working day.",
                "اگر آپ کا کوئی سوال یہاں شامل نہیں، تو ہمیں براہ راست بھیجیں۔ ہم ایک ورکنگ ڈے میں ذاتی جواب دیتے ہیں۔",
              )}
            </p>
            <a
              href="#audit"
              style={{
                display: "inline-block",
                marginTop: 16,
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: 14,
                color: "var(--ss-navy)",
                textDecoration: "underline",
                textUnderlineOffset: 4,
                textDecorationColor: "var(--ss-gold)",
              }}
            >
              {t("Contact us →", "ہم سے رابطہ کریں →")}
            </a>
          </div>
        </FadeSlide>

        <FadeSlide delay={150}>
          <Accordion items={ITEMS} t={t} />
        </FadeSlide>
      </div>

      <style>{`
        @media (max-width: 880px) {
          .ss-faq-grid { grid-template-columns: 1fr !important; gap: 48px !important; }
        }
      `}</style>
    </section>
  );
}
