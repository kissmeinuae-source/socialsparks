import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

export function About() {
  const { t } = useLanguage();
  return (
    <section
      id="about"
      className="relative overflow-hidden"
      style={{ background: "var(--ss-navy)", padding: "112px 48px" }}
    >
      <div className="mx-auto grid max-w-[1280px] gap-16 lg:grid-cols-[55fr_45fr]">
        {/* LEFT */}
        <div>
          <FadeSlide>
            <div className="flex items-center gap-3">
              <span className="inline-block h-px w-6 bg-gold" />
              <span className="t-label text-gold">
                {t("ABOUT SOCIAL SPARK", "ہمارے بارے میں")}
              </span>
            </div>
          </FadeSlide>
          <FadeSlide delay={80}>
            <h2 className="mt-6 text-white" style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}>
              {t(
                "Built in Pakistan. Built for Pakistan.",
                "پاکستان میں بنا، پاکستان کے لیے بنا۔",
              )}
            </h2>
          </FadeSlide>

          <div className="mt-8 flex flex-col gap-5" style={{ color: "var(--ss-ash)", fontSize: "16px", lineHeight: 1.85 }}>
            <FadeSlide delay={150}>
              <p>
                {t(
                  "We started Social Spark because we kept watching brilliant Pakistani businesses go unnoticed online — not for lack of quality, but for lack of visibility.",
                  "ہم نے سوشل اسپارک اس لیے شروع کیا کیونکہ ہم بہترین پاکستانی کاروبار آن لائن نظرانداز ہوتے دیکھتے رہے — معیار کی کمی نہیں، نمایاں ہونے کی کمی تھی۔",
                )}
              </p>
            </FadeSlide>
            <FadeSlide delay={220}>
              <p>
                {t(
                  "We built a service that speaks the language of the market — literally, in Urdu and English — and understands the cultural context of Pakistani consumers, not a Western template applied to a local market.",
                  "ہم نے ایسی سروس بنائی جو مارکیٹ کی زبان بولتی ہے — لفظی طور پر، اردو اور انگریزی میں — اور پاکستانی صارفین کے ثقافتی پس منظر کو سمجھتی ہے۔",
                )}
              </p>
            </FadeSlide>
            <FadeSlide delay={290}>
              <p>
                {t(
                  "From family restaurants in Lahore to ARY anchors to dermatology clinics in Islamabad, we've built digital presences that move the needle.",
                  "لاہور کے فیملی ریستورانوں سے لے کر اے آر وائی کے اینکرز اور اسلام آباد کے کلینکس تک، ہم نے نتائج دینے والی ڈیجیٹل موجودگی بنائی ہے۔",
                )}
              </p>
            </FadeSlide>
          </div>

          <FadeSlide delay={360}>
            <div className="mt-10 flex flex-wrap gap-8">
              <a href="#testi" className="text-gold transition-opacity hover:opacity-80" style={{ fontFamily: "var(--font-sans)", fontWeight: 500, fontSize: "14px" }}>
                {t("See client results →", "نتائج دیکھیں ←")}
              </a>
              <a href="#book" className="text-gold transition-opacity hover:opacity-80" style={{ fontFamily: "var(--font-sans)", fontWeight: 500, fontSize: "14px" }}>
                {t("Book a free call →", "مفت کال بک کریں ←")}
              </a>
            </div>
          </FadeSlide>
        </div>

        {/* RIGHT — fact sheet */}
        <FadeSlide delay={200}>
          <div className="lg:pl-8">
            {[
              { label: t("FOUNDED", "قائم"), value: "2022", size: "32px" },
              { label: t("BASED IN", "مقام"), value: "Lahore, Pakistan 🇵🇰", size: "24px" },
              { label: t("SPECIALITY", "تخصص"), value: t("SMBs & Public Figures", "کاروبار اور مشہور شخصیات"), size: "20px" },
              { label: t("LANGUAGES", "زبانیں"), value: null, size: "20px" },
            ].map((row, i) => (
              <div
                key={i}
                className="flex items-end justify-between gap-6 py-6"
                style={{ borderBottom: "1px solid var(--ss-line)" }}
              >
                <div className="t-label" style={{ color: "var(--ss-ash)" }}>
                  {row.label}
                </div>
                <div
                  className="text-white text-right"
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: row.size,
                    letterSpacing: "-0.01em",
                  }}
                >
                  {row.value ?? (
                    <>
                      English ·{" "}
                      <span style={{ fontFamily: "var(--font-urdu)" }}>اردو</span>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </FadeSlide>
      </div>
    </section>
  );
}
