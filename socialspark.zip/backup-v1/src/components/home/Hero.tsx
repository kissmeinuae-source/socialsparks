import { useLanguage } from "../../lib/language";

/**
 * Hero — Editorial Bento (v2).
 * 12-col bento grid on desktop, single column on mobile.
 * Left 8: headline tile (white). Right 4: capabilities tile (navy),
 * metric tile (white), and yellow CTA pill tile.
 *
 * Animation: each tile uses the .ss-tile-in keyframe with a staggered
 * delay. The yellow highlight marker on "Ignore." draws after 500ms.
 * All animation is suspended under prefers-reduced-motion via styles.css.
 */
export function Hero() {
  const { t, lang } = useLanguage();
  const isUrdu = lang === "ur";

  return (
    <section
      id="hero"
      aria-labelledby="hero-headline"
      style={{
        background: "var(--ss-cream)",
        padding: "clamp(24px, 4vw, 56px) clamp(16px, 4vw, 48px) clamp(48px, 6vw, 72px)",
      }}
    >
      <div
        style={{
          maxWidth: 1360,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "repeat(12, 1fr)",
          gap: "clamp(16px, 1.5vw, 24px)",
          alignItems: "stretch",
        }}
      >
        {/* ─────────────────── LEFT — Headline tile (cols 1-8) ─────────────────── */}
        <article
          className="tile tile-elevated ss-tile-in"
          style={{
            gridColumn: "span 12",
            padding: "clamp(28px, 4vw, 64px)",
            minHeight: 540,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            animationDelay: "60ms",
          }}
        >
          {/* tag row */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 16,
              flexWrap: "wrap",
            }}
          >
            <span className="t-eyebrow" style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
              <span aria-hidden style={{ width: 28, height: 1, background: "var(--ss-ink)", opacity: 0.4 }} />
              {t("A Lahore Digital Studio", "لاہور ڈیجیٹل اسٹوڈیو")}
            </span>
            <span className="t-eyebrow">{t("Est. 2022 — ∞", "2022 — ∞")}</span>
          </div>

          {/* headline */}
          <h1
            id="hero-headline"
            className="display-italic"
            style={{
              fontSize: "clamp(56px, 10vw, 140px)",
              lineHeight: 0.85,
              letterSpacing: "-0.045em",
              margin: "clamp(40px, 8vw, 96px) 0 0",
              fontWeight: 400,
              color: "var(--ss-ink)",
            }}
          >
            {isUrdu ? (
              <span className="urdu" style={{ fontSize: "clamp(40px, 7vw, 96px)", lineHeight: 1.4 }}>
                نظر انداز کرنا{" "}
                <span style={{ fontStyle: "normal" }} className="ss-mark">
                  ناممکن
                </span>
              </span>
            ) : (
              <>
                Impossible<br />
                <span style={{ fontStyle: "normal" }}>
                  to{" "}
                  <span className="ss-mark">Ignore.</span>
                </span>
              </>
            )}
          </h1>

          {/* sub + actions */}
          <div
            style={{
              marginTop: "clamp(32px, 5vw, 56px)",
              display: "flex",
              flexWrap: "wrap",
              alignItems: "center",
              gap: "clamp(20px, 3vw, 32px)",
              justifyContent: "space-between",
            }}
          >
            <p
              style={{
                maxWidth: 460,
                fontSize: 17,
                lineHeight: 1.55,
                color: "var(--ss-slate)",
                margin: 0,
              }}
            >
              {t(
                "We build digital legacies for Pakistan's most influential personalities and ambitious SMBs — through premium social identity and performance media.",
                "ہم پاکستان کی بااثر شخصیات اور باعزم اداروں کے لیے ڈیجیٹل وراثت تخلیق کرتے ہیں — معیاری سوشل شناخت اور پرفارمنس میڈیا کے ذریعے۔",
              )}
            </p>

            <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
              <a href="#book" className="btn-primary">
                {t("Start a Project", "پروجیکٹ شروع کریں")}
                <span aria-hidden style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: 18 }}>
                  →
                </span>
              </a>
              <a
                href="#results"
                style={{
                  color: "var(--ss-ink)",
                  fontFamily: "var(--font-sans)",
                  fontWeight: 500,
                  fontSize: 14,
                  textDecoration: "none",
                  borderBottom: "1px solid var(--ss-ink)",
                  paddingBottom: 2,
                }}
              >
                {t("See our work", "ہمارا کام دیکھیں")}
              </a>
            </div>
          </div>
        </article>

        {/* ─────────────────── RIGHT COLUMN STACK (cols 9-12 on desktop) ─────────────────── */}
        <div
          style={{
            gridColumn: "span 12",
            display: "grid",
            gridTemplateColumns: "repeat(12, 1fr)",
            gap: "clamp(16px, 1.5vw, 24px)",
          }}
        >
          {/* Capabilities — navy tile */}
          <article
            className="tile tile-navy ss-tile-in"
            style={{
              gridColumn: "span 12",
              padding: "clamp(28px, 3vw, 40px)",
              minHeight: 320,
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              animationDelay: "160ms",
            }}
          >
            <div>
              <span className="t-eyebrow" style={{ color: "oklch(0.96 0.012 85 / 0.6)" }}>
                {t("Capabilities", "ہماری مہارتیں")}
              </span>
              <ul
                style={{
                  listStyle: "none",
                  padding: 0,
                  margin: "20px 0 0",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                {[
                  { en: "Social Management", ur: "سوشل مینجمنٹ" },
                  { en: "Performance Ads", ur: "پرفارمنس ایڈز" },
                  { en: "Brand Identity", ur: "برانڈ شناخت" },
                  { en: "Website Design", ur: "ویب سائٹ ڈیزائن" },
                ].map((item, i) => (
                  <li
                    key={item.en}
                    style={{
                      display: "flex",
                      alignItems: "baseline",
                      justifyContent: "space-between",
                      gap: 16,
                      padding: "12px 0",
                      borderBottom: i < 3 ? "1px solid oklch(1 0 0 / 0.10)" : "none",
                      fontFamily: "var(--font-display)",
                      fontSize: 22,
                      fontStyle: "italic",
                      color: "var(--ss-cream)",
                      lineHeight: 1.1,
                    }}
                  >
                    <span>{t(item.en, item.ur)}</span>
                    <span style={{ color: "var(--ss-gold)", fontStyle: "normal", fontFamily: "var(--font-sans)", fontWeight: 600, fontSize: 12, letterSpacing: "0.1em" }}>
                      0{i + 1}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* trust avatars */}
            <div style={{ marginTop: 28 }}>
              <div style={{ display: "flex", alignItems: "center" }}>
                {[
                  "linear-gradient(135deg,#C9A87C,#8B6F4E)",
                  "linear-gradient(135deg,#9BB4D8,#4A6FA8)",
                  "linear-gradient(135deg,#D4A574,#A8754E)",
                ].map((bg, i) => (
                  <span
                    key={i}
                    aria-hidden
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: "50%",
                      background: bg,
                      border: "2px solid var(--ss-ink)",
                      marginLeft: i === 0 ? 0 : -10,
                    }}
                  />
                ))}
                <span
                  aria-hidden
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    background: "var(--ss-gold)",
                    border: "2px solid var(--ss-ink)",
                    marginLeft: -10,
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "var(--ss-ink)",
                    fontFamily: "var(--font-sans)",
                    fontWeight: 700,
                    fontSize: 10,
                    letterSpacing: "0.04em",
                  }}
                >
                  +50
                </span>
              </div>
              <p
                style={{
                  margin: "12px 0 0",
                  fontSize: 12,
                  color: "oklch(0.96 0.012 85 / 0.65)",
                  lineHeight: 1.5,
                }}
              >
                {t(
                  "Trusted by celebrities, anchors & growth-stage SMBs.",
                  "مشہور شخصیات، اینکرز اور ترقی پذیر اداروں کا بھروسہ۔",
                )}
              </p>
            </div>
          </article>

          {/* Metric — white tile */}
          <article
            className="tile ss-tile-in"
            style={{
              gridColumn: "span 7",
              padding: "clamp(24px, 3vw, 32px)",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              minHeight: 180,
              animationDelay: "240ms",
            }}
          >
            <span className="t-eyebrow">{t("Monthly Impact", "ماہانہ اثر")}</span>
            <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginTop: 12 }}>
              <span
                className="display-italic"
                style={{
                  fontSize: "clamp(48px, 7vw, 72px)",
                  lineHeight: 1,
                  color: "var(--ss-ink)",
                  letterSpacing: "-0.03em",
                }}
              >
                14.2M
              </span>
              <span style={{ color: "var(--ss-gold)", fontWeight: 700, fontSize: 24 }}>+</span>
            </div>
            <p
              style={{
                margin: "10px 0 0",
                fontSize: 13,
                color: "var(--ss-slate)",
                fontStyle: "italic",
                fontFamily: "var(--font-display)",
                lineHeight: 1.4,
              }}
            >
              {t(
                "Organic reach generated for clients across South Asia, last 30 days.",
                "گزشتہ 30 دنوں میں جنوبی ایشیا بھر کے کلائنٹس کے لیے آرگینک رسائی۔",
              )}
            </p>
          </article>

          {/* Yellow CTA tile — small bento accent */}
          <a
            href="#results"
            className="tile tile-yellow ss-tile-in"
            style={{
              gridColumn: "span 5",
              padding: "clamp(22px, 2.5vw, 28px)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 16,
              minHeight: 180,
              textDecoration: "none",
              color: "var(--ss-ink)",
              animationDelay: "320ms",
              transition: "transform 220ms ease",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget.querySelector("[data-arrow]") as HTMLElement).style.transform = "translateX(6px)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget.querySelector("[data-arrow]") as HTMLElement).style.transform = "translateX(0)";
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <span
                className="t-label"
                style={{ color: "var(--ss-ink)", opacity: 0.7, fontSize: 10 }}
              >
                {t("Case Studies", "کیس اسٹڈیز")}
              </span>
              <span
                className="display-italic"
                style={{
                  fontSize: "clamp(22px, 2.4vw, 28px)",
                  lineHeight: 1,
                  color: "var(--ss-ink)",
                  letterSpacing: "-0.02em",
                }}
              >
                {t("See our work", "ہمارا کام")}
              </span>
            </div>
            <span
              data-arrow
              aria-hidden
              style={{
                fontFamily: "var(--font-display)",
                fontStyle: "italic",
                fontSize: 40,
                lineHeight: 1,
                transition: "transform 220ms ease",
              }}
            >
              →
            </span>
          </a>
        </div>
      </div>

      {/* Responsive: above 960px, switch headline tile to 8/12 and right stack to 4/12 */}
      <style>{`
        @media (min-width: 960px) {
          #hero > div > article:first-child { grid-column: span 8 !important; }
          #hero > div > div:last-child { grid-column: span 4 !important; }
          #hero > div > div:last-child > article,
          #hero > div > div:last-child > a { grid-column: span 12 !important; }
          #hero > div > div:last-child > article:nth-child(2) { grid-column: span 12 !important; }
        }
      `}</style>
    </section>
  );
}
