import { FadeSlide } from "@/components/anim/FadeSlide";
import { CountUp } from "@/components/anim/CountUp";
import { useLanguage } from "@/lib/language";

interface Stat {
  to: number;
  decimals?: number;
  suffix: string;
  label: [string, string];
}

const STATS: Stat[] = [
  { to: 50, suffix: "+", label: ["Brands grown across Pakistan", "پاکستان بھر میں ترقی یافتہ برانڈز"] },
  { to: 3.2, decimals: 1, suffix: "×", label: ["Average return on ad spend", "اشتہاری اخراجات پر اوسط واپسی"] },
  { to: 48, suffix: "hr", label: ["From call to campaign live", "کال سے مہم کے آغاز تک"] },
  { to: 4.9, decimals: 1, suffix: "★", label: ["Client satisfaction rating", "کلائنٹ اطمینان کی درجہ بندی"] },
];

export function Statistics() {
  const { t } = useLanguage();
  return (
    <section
      id="results"
      style={{
        backgroundColor: "var(--ss-navy)",
        padding: "96px 48px",
      }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div className="ss-stats-row">
          {STATS.map((s, i) => (
            <FadeSlide key={s.label[0]} delay={i * 100}>
              <div
                className="ss-stat-block"
                style={{
                  padding: i === 0 ? "0 64px 0 0" : "0 64px",
                  textAlign: "center",
                  borderLeft: i === 0 ? "none" : "1px solid var(--ss-line)",
                }}
              >
                <div
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 800,
                    fontSize: 72,
                    color: "var(--ss-gold)",
                    lineHeight: 1,
                    letterSpacing: "-0.02em",
                  }}
                >
                  <CountUp
                    to={s.to}
                    decimals={s.decimals ?? 0}
                    suffix={s.suffix}
                    duration={1400}
                  />
                </div>
                <div
                  style={{
                    marginTop: 12,
                    fontFamily: "var(--font-sans)",
                    fontWeight: 500,
                    fontSize: 14,
                    color: "var(--ss-ash)",
                    lineHeight: 1.4,
                  }}
                >
                  {t(s.label[0], s.label[1])}
                </div>
              </div>
            </FadeSlide>
          ))}
        </div>

        <div
          style={{
            marginTop: 72,
            height: 1,
            backgroundColor: "var(--ss-line)",
            width: "100%",
          }}
        />
        <p
          style={{
            marginTop: 18,
            marginBottom: 0,
            textAlign: "center",
            fontFamily: "var(--font-sans)",
            fontSize: 13,
            fontStyle: "italic",
            color: "var(--ss-ash)",
          }}
        >
          {t(
            "Results tracked across all active clients, updated quarterly.",
            "تمام فعال کلائنٹس کے نتائج، سہ ماہی بنیاد پر اپڈیٹ کیے جاتے ہیں۔",
          )}
        </p>
      </div>

      <style>{`
        .ss-stats-row {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          align-items: center;
        }
        @media (max-width: 880px) {
          .ss-stats-row { grid-template-columns: repeat(2, minmax(0, 1fr)); }
          .ss-stat-block {
            padding: 32px 16px !important;
            border-left: none !important;
            border-top: 1px solid var(--ss-line);
          }
          .ss-stat-block:nth-child(-n+2) { border-top: none; }
          .ss-stat-block:nth-child(odd)  { border-right: 1px solid var(--ss-line); }
        }
      `}</style>
    </section>
  );
}
