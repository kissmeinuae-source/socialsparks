import { FadeSlide } from "@/components/anim/FadeSlide";
import { useLanguage } from "@/lib/language";

interface Step {
  num: string;
  title: [string, string];
  desc: [string, string];
}

const STEPS: Step[] = [
  {
    num: "01",
    title: ["Free Strategy Call", "مفت حکمت عملی کال"],
    desc: [
      "We study your business, your audience, and your competitors. No templates — bespoke thinking from day one.",
      "ہم آپ کے کاروبار، سامعین اور حریفوں کا مطالعہ کرتے ہیں۔ کوئی ٹیمپلیٹ نہیں — پہلے دن سے مخصوص سوچ۔",
    ],
  },
  {
    num: "02",
    title: ["Custom Plan Built", "اپنی مرضی کا منصوبہ"],
    desc: [
      "A documented strategy covering platforms, content pillars, ad structure, and KPIs. Delivered within 48 hours.",
      "پلیٹ فارمز، کنٹینٹ، اشتہاری ڈھانچہ اور KPIs پر مشتمل دستاویزی حکمت عملی۔ 48 گھنٹوں میں۔",
    ],
  },
  {
    num: "03",
    title: ["Full Execution", "مکمل عمل درآمد"],
    desc: [
      "Our team runs everything. Posting, ad management, community replies, A/B testing. You are kept informed, not buried in it.",
      "ہماری ٹیم سب کچھ سنبھالتی ہے۔ پوسٹنگ، اشتہار، کمیونٹی، A/B ٹیسٹنگ۔ آپ کو باخبر رکھا جاتا ہے، بوجھ نہیں ڈالا جاتا۔",
    ],
  },
  {
    num: "04",
    title: ["Measurable Results", "قابلِ پیمائش نتائج"],
    desc: [
      "Monthly reports in plain language. Numbers that matter to a business owner, not a marketing manager.",
      "ماہانہ رپورٹس سادہ زبان میں۔ ایسے اعداد جو کاروبار کے مالک کے لیے اہم ہوں، مارکیٹنگ مینیجر کے لیے نہیں۔",
    ],
  },
];

export function Process() {
  const { t } = useLanguage();
  return (
    <section
      id="how"
      style={{
        backgroundColor: "var(--ss-ink)",
        padding: "112px 48px",
      }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>
        <FadeSlide>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
            <span
              aria-hidden
              style={{ display: "inline-block", width: 2, height: 24, backgroundColor: "var(--ss-gold)" }}
            />
            <span
              style={{
                fontFamily: "var(--font-sans)",
                fontWeight: 700,
                fontSize: 11,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "var(--ss-ash)",
              }}
            >
              {t("THE PROCESS", "ہمارا طریقہ کار")}
            </span>
          </div>
        </FadeSlide>

        <FadeSlide delay={120}>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 700,
              fontSize: "var(--type-h2-size)",
              color: "#fff",
              letterSpacing: "-0.025em",
              lineHeight: 1.05,
              margin: 0,
              maxWidth: 820,
            }}
          >
            {t(
              "From Conversation to Campaign in 4 Steps.",
              "گفتگو سے مہم تک، صرف 4 مراحل میں۔",
            )}
          </h2>
        </FadeSlide>

        <div
          className="ss-process-grid"
          style={{
            marginTop: 64,
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
            gap: 20,
          }}
        >
          {STEPS.map((s, i) => (
            <FadeSlide key={s.num} delay={220 + i * 100}>
              <div
                className="ss-process-card"
                style={{
                  position: "relative",
                  overflow: "hidden",
                  padding: 48,
                  border: "1px solid var(--ss-line)",
                  borderRadius: 4,
                  transition: "border-color 220ms ease, background-color 220ms ease",
                  height: "100%",
                }}
              >
                <span
                  aria-hidden
                  style={{
                    position: "absolute",
                    top: -18,
                    right: 12,
                    fontFamily: "var(--font-display)",
                    fontWeight: 800,
                    fontSize: 120,
                    lineHeight: 1,
                    color: "var(--ss-gold)",
                    opacity: 0.06,
                    pointerEvents: "none",
                    letterSpacing: "-0.04em",
                  }}
                >
                  {s.num}
                </span>
                <div
                  style={{
                    position: "relative",
                    fontFamily: "var(--font-sans)",
                    fontWeight: 700,
                    fontSize: 10,
                    letterSpacing: "0.16em",
                    textTransform: "uppercase",
                    color: "var(--ss-gold)",
                  }}
                >
                  {t(`STEP ${s.num}`, `مرحلہ ${s.num}`)}
                </div>
                <h3
                  style={{
                    position: "relative",
                    margin: "14px 0 14px",
                    fontFamily: "var(--font-display)",
                    fontWeight: 700,
                    fontSize: 20,
                    color: "#fff",
                    letterSpacing: "-0.005em",
                  }}
                >
                  {t(s.title[0], s.title[1])}
                </h3>
                <p
                  style={{
                    position: "relative",
                    margin: 0,
                    fontFamily: "var(--font-sans)",
                    fontSize: 15,
                    lineHeight: 1.75,
                    color: "var(--ss-ash)",
                  }}
                >
                  {t(s.desc[0], s.desc[1])}
                </p>
              </div>
            </FadeSlide>
          ))}
        </div>
      </div>

      <style>{`
        .ss-process-card:hover {
          border-color: var(--ss-gold) !important;
          background-color: rgba(255,255,255,0.02) !important;
        }
        @media (max-width: 760px) {
          .ss-process-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}
