import { useEffect, useState } from "react";

/**
 * 2px gold bar pinned to top of viewport. Animates 0 → 100% width in 700ms
 * on mount, then fades out. Honors prefers-reduced-motion via CSS.
 */
export function TopProgressBar() {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShow(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  if (!show) return null;
  return <div className="ss-page-progress" aria-hidden />;
}
