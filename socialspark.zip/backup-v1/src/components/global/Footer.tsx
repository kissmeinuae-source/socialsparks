import { Logo } from "@/components/global/Logo";
import { useLanguage } from "@/lib/language";

export function Footer() {
  const { t } = useLanguage();

  const services = ["Social Media", "Paid Ads", "Website Design", "Content", "SEO", "Video"];
  const company = [
    { label: "About", href: "#about" },
    { label: "Pricing", href: "#pricing" },
    { label: "Results", href: "#results" },
    { label: "Blog", href: "#" },
    { label: "Contact", href: "#contact" },
    { label: "Book a Call", href: "#book" },
  ];
  const legal = ["Privacy Policy", "Cookie Policy", "Terms", "Refund Policy"];

  const colHeader: React.CSSProperties = {
    fontFamily: "var(--font-sans)",
    fontWeight: 700,
    fontSize: 10,
    color: "var(--ss-gold)",
    textTransform: "uppercase",
    letterSpacing: "0.12em",
    marginBottom: 20,
  };

  const linkStyle: React.CSSProperties = {
    color: "rgba(255,255,255,0.4)",
    fontSize: 14,
    textDecoration: "none",
    display: "block",
    padding: "5px 0",
    transition: "color 200ms",
  };

  return (
    <footer
      style={{
        background: "var(--ss-ink)",
        borderTop: "1px solid var(--ss-line)",
        padding: "80px 48px 36px",
      }}
    >
      <div className="mx-auto max-w-[1280px]">
        <div className="grid gap-12 lg:grid-cols-[2fr_1fr_1fr_1fr]">
          {/* Col 1 */}
          <div>
            <Logo />
            <p
              className="mt-6"
              style={{
                color: "var(--ss-ash)",
                fontSize: 14,
                lineHeight: 1.7,
                maxWidth: 220,
              }}
            >
              {t(
                "Digital growth for Pakistan's businesses and personalities. Plain language. Real results.",
                "پاکستان کے کاروبار اور شخصیات کے لیے ڈیجیٹل ترقی۔ سادہ زبان۔ اصل نتائج۔",
              )}
            </p>
            <div className="mt-6 flex gap-4">
              {["Instagram", "Facebook", "LinkedIn"].map((s) => (
                <a
                  key={s}
                  href="#"
                  className="hover:underline underline-offset-4"
                  style={{
                    color: "var(--ss-ash)",
                    fontSize: 12,
                    fontWeight: 500,
                  }}
                >
                  {s}
                </a>
              ))}
            </div>
          </div>

          {/* Col 2 */}
          <div>
            <div style={colHeader}>{t("SERVICES", "خدمات")}</div>
            {services.map((s) => (
              <a
                key={s}
                href="#services"
                style={linkStyle}
                onMouseEnter={(e) => (e.currentTarget.style.color = "white")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.4)")}
              >
                {s}
              </a>
            ))}
          </div>

          {/* Col 3 */}
          <div>
            <div style={colHeader}>{t("COMPANY", "کمپنی")}</div>
            {company.map((c) => (
              <a
                key={c.label}
                href={c.href}
                style={linkStyle}
                onMouseEnter={(e) => (e.currentTarget.style.color = "white")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.4)")}
              >
                {c.label}
              </a>
            ))}
          </div>

          {/* Col 4 */}
          <div>
            <div style={colHeader}>{t("LEGAL", "قانونی")}</div>
            {legal.map((l) => (
              <a
                key={l}
                href="#"
                style={linkStyle}
                onMouseEnter={(e) => (e.currentTarget.style.color = "white")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.4)")}
              >
                {l}
              </a>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="flex flex-wrap items-center justify-between gap-4"
          style={{
            borderTop: "1px solid var(--ss-line)",
            paddingTop: 28,
            marginTop: 56,
          }}
        >
          <span style={{ color: "var(--ss-ash)", fontSize: 13 }}>
            © 2025 Social Spark · {t("Made in Pakistan", "پاکستان میں بنایا گیا")}{" "}
            <span className="ss-flag-wave" aria-hidden>🇵🇰</span>
          </span>
          <div className="flex gap-5">
            {["Privacy", "Cookies", "Terms"].map((l) => (
              <a
                key={l}
                href="#"
                style={{ color: "var(--ss-ash)", fontSize: 13, textDecoration: "none" }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "white")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "var(--ss-ash)")}
              >
                {l}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
