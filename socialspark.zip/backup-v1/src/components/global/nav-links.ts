export interface NavItem {
  id: string;
  label: string;
  labelUr: string;
}

export const NAV_LINKS: NavItem[] = [
  { id: "services", label: "Services", labelUr: "خدمات" },
  { id: "pricing", label: "Pricing", labelUr: "قیمتیں" },
  { id: "about", label: "About", labelUr: "ہمارے بارے میں" },
  { id: "results", label: "Results", labelUr: "نتائج" },
  { id: "contact", label: "Contact", labelUr: "رابطہ" },
];
