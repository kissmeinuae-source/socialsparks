import { useLanguage } from "../../lib/language";

/**
 * Slim top utility bar above NavBar. Cream canvas, navy text,
 * tiny EN / UR pill toggle on the right. 36px tall.
 */
export function TopLanguageBar() {
  const { lang, setLang } = useLanguage();

  return (
    <div
      role="region"
      aria-label="Site locale and tagline"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 101,
        height: 36,
        background: "var(--ss-cream)",
        borderBottom: "1px solid var(--ss-line)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 clamp(16px, 5vw, 40px)",
        fontFamily: "var(--font-sans)",
        fontSize: 11,
        letterSpacing: "0.18em",
        textTransform: "uppercase",
        color: "var(--ss-slate)",
      }}
    >
      <span style={{ fontWeight: 600 }}>
        {lang === "ur" ? (
          <span className="urdu" style={{ fontSize: 14, letterSpacing: "normal" }}>
            لاہور سے دنیا تک
          </span>
        ) : (
          <>Lahore <span style={{ opacity: 0.4, margin: "0 6px" }}>•</span> Digital Studio Est. 2022</>
        )}
      </span>

      <div
        role="group"
        aria-label="Language"
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 2,
          padding: 2,
          border: "1px solid var(--ss-line)",
          borderRadius: 9999,
          background: "#fff",
        }}
      >
        {(["en", "ur"] as const).map((code) => {
          const active = lang === code;
          return (
            <button
              key={code}
              type="button"
              onClick={() => setLang(code)}
              aria-pressed={active}
              aria-label={code === "en" ? "Switch to English" : "اردو پر سوئچ کریں"}
              style={{
                border: 0,
                cursor: "pointer",
                padding: "4px 12px",
                borderRadius: 9999,
                fontFamily: "var(--font-sans)",
                fontWeight: 600,
                fontSize: 10,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                background: active ? "var(--ss-ink)" : "transparent",
                color: active ? "#fff" : "var(--ss-slate)",
                transition: "background 180ms ease, color 180ms ease",
                lineHeight: 1,
              }}
            >
              {code === "en" ? "EN" : "UR"}
            </button>
          );
        })}
      </div>
    </div>
  );
}
