import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, MessageCircle, Send, Zap } from "lucide-react";
import { useLanguage } from "@/lib/language";

const WA_NUMBER = "923000000000";

export function TalkToUsWidget() {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [chatMode, setChatMode] = useState(false);
  const [hasOpenedOnce, setHasOpenedOnce] = useState(false);
  const [messages, setMessages] = useState<{ from: "me" | "them"; text: string }[]>([
    { from: "them", text: "Hey! How can we help you today?" },
  ]);
  const [draft, setDraft] = useState("");
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      if (window.localStorage.getItem("ss-talk-opened") === "1") {
        setHasOpenedOnce(true);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    function onClick(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("keydown", onKey);
    setTimeout(() => document.addEventListener("mousedown", onClick), 50);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, [open]);

  useEffect(() => {
    if (!open) setChatMode(false);
  }, [open]);

  function sendMessage() {
    const trimmed = draft.trim().slice(0, 500);
    if (!trimmed) return;
    setMessages((m) => [...m, { from: "me", text: trimmed }]);
    setDraft("");
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        { from: "them", text: "Got it — someone will reply within a few minutes." },
      ]);
    }, 700);
  }

  return (
    <>
      {/* Trigger pill */}
      <button
        type="button"
        onClick={() => {
          setOpen(true);
          setHasOpenedOnce(true);
          try { window.localStorage.setItem("ss-talk-opened", "1"); } catch { /* ignore */ }
        }}
        aria-label={t("Talk to us", "ہم سے بات کریں")}
        className="group fixed transition-colors"
        style={{
          bottom: 32,
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 990,
          background: "var(--ss-navy)",
          border: "1.5px solid var(--ss-gold)",
          borderRadius: 100,
          padding: "12px 28px",
          display: "inline-flex",
          alignItems: "center",
          gap: 10,
          cursor: "pointer",
          boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
        }}
        onMouseEnter={(e) =>
          (e.currentTarget.style.background = "oklch(from var(--ss-gold) l c h / 0.10)")
        }
        onMouseLeave={(e) => (e.currentTarget.style.background = "var(--ss-navy)")}
      >
        <Zap size={16} fill="var(--ss-gold)" stroke="var(--ss-gold)" />
        <span
          style={{
            color: "var(--ss-gold)",
            fontFamily: "var(--font-display)",
            fontWeight: 700,
            fontSize: 14,
            letterSpacing: "0.02em",
          }}
        >
          {t("Talk to Us", "ہم سے بات کریں")}
        </span>
        <span className={hasOpenedOnce ? "ss-pulse-dot is-quiet" : "ss-pulse-dot"} aria-hidden />
      </button>

      <style>{`
        .ss-pulse-dot {
          display: inline-block;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: var(--ss-gold);
          box-shadow: 0 0 0 0 oklch(from var(--ss-gold) l c h / 0.6);
          animation: ss-pulse 1.6s infinite;
        }
        .ss-pulse-dot.is-quiet { animation: none; box-shadow: none; }
        @keyframes ss-pulse {
          0% { box-shadow: 0 0 0 0 oklch(from var(--ss-gold) l c h / 0.7); }
          70% { box-shadow: 0 0 0 12px oklch(from var(--ss-gold) l c h / 0); }
          100% { box-shadow: 0 0 0 0 oklch(from var(--ss-gold) l c h / 0); }
        }
      `}</style>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              style={{
                position: "fixed",
                inset: 0,
                background: "rgba(0,0,0,0.45)",
                zIndex: 995,
              }}
            />
            <motion.div
              ref={panelRef}
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ duration: 0.38, ease: [0.16, 1, 0.3, 1] }}
              role="dialog"
              aria-modal="true"
              style={{
                position: "fixed",
                bottom: 0,
                left: "50%",
                transform: "translateX(-50%)",
                width: "min(640px, 100%)",
                background: "var(--ss-ink)",
                borderTop: "2px solid var(--ss-gold)",
                borderRadius: "20px 20px 0 0",
                padding: "28px 32px 36px",
                zIndex: 996,
                boxShadow: "0 -20px 60px rgba(0,0,0,0.5)",
              }}
            >
              <div className="flex items-center justify-between">
                <h3
                  className="text-white"
                  style={{ fontFamily: "var(--font-display)", fontSize: 20 }}
                >
                  {chatMode
                    ? t("Chat with us", "ہمارے ساتھ چیٹ کریں")
                    : t("How would you like to talk?", "آپ کس طرح بات کرنا چاہیں گے؟")}
                </h3>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  aria-label="Close"
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "var(--ss-ash)",
                    cursor: "pointer",
                  }}
                >
                  <X size={20} />
                </button>
              </div>

              {!chatMode ? (
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  {/* WhatsApp */}
                  <div
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid var(--ss-line)",
                      borderRadius: 12,
                      padding: 20,
                    }}
                  >
                    <MessageCircle size={20} style={{ color: "var(--ss-gold)" }} />
                    <div
                      className="mt-3 text-white"
                      style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 16 }}
                    >
                      {t("Continue on WhatsApp", "واٹس ایپ پر جاری رکھیں")}
                    </div>
                    <div style={{ color: "var(--ss-ash)", fontSize: 13, marginTop: 6 }}>
                      {t("Typically replies within 1 hour", "عام طور پر 1 گھنٹے میں جواب")}
                    </div>
                    <a
                      href={`https://wa.me/${WA_NUMBER}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-block",
                        marginTop: 16,
                        padding: "8px 16px",
                        border: "1px solid var(--ss-gold)",
                        borderRadius: 6,
                        color: "var(--ss-gold)",
                        fontFamily: "var(--font-display)",
                        fontWeight: 700,
                        fontSize: 13,
                        textDecoration: "none",
                      }}
                    >
                      {t("Open WhatsApp →", "واٹس ایپ کھولیں ←")}
                    </a>
                  </div>

                  {/* Chat */}
                  <div
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid var(--ss-line)",
                      borderRadius: 12,
                      padding: 20,
                    }}
                  >
                    <Send size={20} style={{ color: "var(--ss-gold)" }} />
                    <div
                      className="mt-3 text-white"
                      style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 16 }}
                    >
                      {t("Chat Here", "یہاں چیٹ کریں")}
                    </div>
                    <div style={{ color: "var(--ss-ash)", fontSize: 13, marginTop: 6 }}>
                      {t("We'll reply right away", "ہم ابھی جواب دیں گے")}
                    </div>
                    <button
                      type="button"
                      onClick={() => setChatMode(true)}
                      style={{
                        display: "inline-block",
                        marginTop: 16,
                        padding: "8px 16px",
                        border: "1px solid var(--ss-navy)",
                        background: "var(--ss-navy)",
                        borderRadius: 6,
                        color: "white",
                        fontFamily: "var(--font-display)",
                        fontWeight: 700,
                        fontSize: 13,
                        cursor: "pointer",
                      }}
                    >
                      {t("Start Chat →", "چیٹ شروع کریں ←")}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-5 flex flex-col gap-3">
                  <div
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid var(--ss-line)",
                      borderRadius: 10,
                      padding: 16,
                      maxHeight: 280,
                      minHeight: 200,
                      overflowY: "auto",
                      display: "flex",
                      flexDirection: "column",
                      gap: 10,
                    }}
                  >
                    {messages.map((m, i) => (
                      <div
                        key={i}
                        style={{
                          alignSelf: m.from === "me" ? "flex-end" : "flex-start",
                          background: m.from === "me" ? "var(--ss-gold)" : "rgba(255,255,255,0.06)",
                          color: m.from === "me" ? "var(--ss-ink)" : "white",
                          padding: "8px 12px",
                          borderRadius: 8,
                          fontSize: 13,
                          maxWidth: "80%",
                        }}
                      >
                        {m.text}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                      maxLength={500}
                      placeholder={t("Type a message...", "پیغام لکھیں...")}
                      style={{
                        flex: 1,
                        background: "transparent",
                        border: "1px solid var(--ss-line)",
                        borderRadius: 6,
                        padding: "10px 14px",
                        color: "white",
                        fontSize: 14,
                        outline: "none",
                      }}
                    />
                    <button
                      type="button"
                      onClick={sendMessage}
                      style={{
                        background: "var(--ss-gold)",
                        color: "var(--ss-ink)",
                        border: "none",
                        borderRadius: 6,
                        padding: "0 16px",
                        fontFamily: "var(--font-display)",
                        fontWeight: 700,
                        fontSize: 13,
                        cursor: "pointer",
                      }}
                    >
                      <Send size={16} />
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
