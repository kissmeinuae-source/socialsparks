import { useCallback, useState } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Logo } from "./Logo";
import { NAV_LINKS } from "./nav-links";
import { useScrollY } from "../../hooks/use-scroll-y";
import { useActiveSection } from "../../hooks/use-active-section";
import { useLanguage } from "../../lib/language";
import { MobileMenu } from "./MobileMenu";

/**
 * Cream / white nav. Navy logo + nav links + a single yellow pill CTA.
 * Scroll past 60px → adds elevation shadow + tightens the border.
 */
export function NavBar() {
  const scrollY = useScrollY();
  const scrolled = scrollY > 60;
  const active = useActiveSection(NAV_LINKS.map((l) => l.id));
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { t } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);

  const goToSection = useCallback(
    (id: string) => {
      if (pathname === "/") {
        const el = document.getElementById(id);
        if (el) {
          el.scrollIntoView({ behavior: "smooth", block: "start" });
          return;
        }
      }
      navigate({ to: "/", hash: id });
    },
    [pathname, navigate],
  );

  return (
    <>
      <header
        style={{
          position: "fixed",
          top: 36,
          left: 0,
          right: 0,
          zIndex: 100,
          height: 68,
          background: scrolled
            ? "oklch(0.96 0.012 85 / 0.85)"
            : "var(--ss-cream)",
          backdropFilter: scrolled ? "blur(20px) saturate(180%)" : "none",
          WebkitBackdropFilter: scrolled ? "blur(20px) saturate(180%)" : "none",
          borderBottom: "1px solid var(--ss-line)",
          boxShadow: scrolled ? "var(--shadow-tile-sm)" : "none",
          transition: "background 280ms ease, box-shadow 280ms ease",
          padding: "0 clamp(20px, 5vw, 48px)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Logo size={20} tone="navy" />

        {/* Nav links */}
        <nav
          role="navigation"
          aria-label="Primary"
          className="ss-nav-links"
          style={{ display: "flex", alignItems: "center", gap: 36 }}
        >
          {NAV_LINKS.map((link) => {
            const isActive = active === link.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => goToSection(link.id)}
                style={{
                  position: "relative",
                  background: "transparent",
                  border: 0,
                  padding: "8px 0",
                  cursor: "pointer",
                  fontFamily: "var(--font-sans)",
                  fontWeight: 500,
                  fontSize: 14,
                  color: isActive ? "var(--ss-ink)" : "var(--ss-slate)",
                  transition: "color 180ms ease",
                  lineHeight: 1,
                }}
                onMouseEnter={(e) => {
                  if (!isActive) e.currentTarget.style.color = "var(--ss-ink)";
                }}
                onMouseLeave={(e) => {
                  if (!isActive) e.currentTarget.style.color = "var(--ss-slate)";
                }}
              >
                {t(link.label, link.labelUr)}
                <span
                  aria-hidden
                  style={{
                    position: "absolute",
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 2,
                    background: "var(--ss-gold)",
                    transform: isActive ? "scaleX(1)" : "scaleX(0)",
                    transformOrigin: "left",
                    transition: "transform 220ms cubic-bezier(0.22,1,0.36,1)",
                    borderRadius: 2,
                  }}
                />
              </button>
            );
          })}
        </nav>

        {/* Yellow pill CTA — the only yellow in the nav */}
        <button
          type="button"
          onClick={() => goToSection("book")}
          className="ss-nav-cta btn-yellow"
          style={{ padding: "12px 22px", fontSize: 13 }}
        >
          {t("Start a Project", "پروجیکٹ شروع کریں")}
          <span aria-hidden style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: 16 }}>→</span>
        </button>

        {/* Hamburger */}
        <button
          type="button"
          className="ss-hamburger"
          onClick={() => setMenuOpen((o) => !o)}
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          style={{
            background: "transparent",
            border: 0,
            cursor: "pointer",
            padding: 8,
            display: "none",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            gap: 5,
            width: 44,
            height: 44,
          }}
        >
          <motion.span
            animate={menuOpen ? { rotate: 45, y: 7 } : { rotate: 0, y: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            style={{ display: "block", width: 22, height: 2, background: "var(--ss-ink)", borderRadius: 1, transformOrigin: "center" }}
          />
          <motion.span
            animate={menuOpen ? { opacity: 0, scaleX: 0 } : { opacity: 1, scaleX: 1 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            style={{ display: "block", width: 22, height: 2, background: "var(--ss-ink)", borderRadius: 1 }}
          />
          <motion.span
            animate={menuOpen ? { rotate: -45, y: -7 } : { rotate: 0, y: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            style={{ display: "block", width: 22, height: 2, background: "var(--ss-ink)", borderRadius: 1, transformOrigin: "center" }}
          />
        </button>

        <style>{`
          @media (max-width: 959px) {
            .ss-nav-links { display: none !important; }
            .ss-nav-cta { display: none !important; }
            .ss-hamburger { display: flex !important; }
          }
        `}</style>
      </header>

      <MobileMenu
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        onNavigate={goToSection}
      />
    </>
  );
}
