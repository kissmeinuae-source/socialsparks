import { useEffect, useRef, useState } from "react";
import gsap from "gsap";

const STORAGE_KEY = "ss-entered";

function prefersReducedMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function PageEnterAnimation() {
  const [mounted, setMounted] = useState(false);
  const [done, setDone] = useState(false);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const lineRef = useRef<HTMLDivElement | null>(null);
  const boltRef = useRef<SVGSVGElement | null>(null);
  const wordRef = useRef<HTMLDivElement | null>(null);

  // Decide on client only (sessionStorage)
  useEffect(() => {
    try {
      const seen = window.sessionStorage.getItem(STORAGE_KEY);
      if (seen === "1" || prefersReducedMotion()) {
        try {
          window.sessionStorage.setItem(STORAGE_KEY, "1");
        } catch {
          /* ignore */
        }
        setDone(true);
        return;
      }
    } catch {
      /* ignore */
    }
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    const overlay = overlayRef.current;
    const line = lineRef.current;
    const bolt = boltRef.current;
    const word = wordRef.current;
    if (!overlay || !line || !bolt || !word) return;

    const chars = word.querySelectorAll<HTMLSpanElement>("[data-char]");
    gsap.set(line, { width: 0 });
    gsap.set(bolt, { opacity: 0, scale: 0.6, transformOrigin: "50% 50%" });
    gsap.set(chars, { opacity: 0, y: 8 });

    const tl = gsap.timeline({
      onComplete: () => {
        try {
          window.sessionStorage.setItem(STORAGE_KEY, "1");
        } catch {
          /* ignore */
        }
        setDone(true);
      },
    });

    // Phase 1: line draws
    tl.to(line, { width: "100vw", duration: 0.35, ease: "power2.inOut" }, 0);
    // Phase 2: lightning bolt
    tl.to(
      bolt,
      { opacity: 1, scale: 1, duration: 0.3, ease: "back.out(1.4)" },
      0.35,
    );
    // Phase 3: wordmark stagger
    tl.to(
      chars,
      { opacity: 1, y: 0, duration: 0.3, ease: "power2.out", stagger: 0.03 },
      0.5,
    );
    // Phase 4: fade out everything
    tl.to(overlay, { opacity: 0, duration: 0.2, ease: "power1.in" }, 0.9);

    return () => {
      tl.kill();
    };
  }, [mounted]);

  if (done || !mounted) return null;

  const word = "SOCIAL_SPARK";

  return (
    <div
      ref={overlayRef}
      aria-hidden
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "var(--ss-ink)",
        zIndex: 9998,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      {/* Bolt above the line */}
      <svg
        ref={boltRef}
        width="40"
        height="40"
        viewBox="0 0 24 24"
        style={{ marginBottom: 28 }}
      >
        <path
          d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
          fill="var(--ss-gold)"
        />
      </svg>

      {/* Gold line — fixed at 50vh visually because container is centered */}
      <div
        ref={lineRef}
        style={{
          position: "absolute",
          top: "50vh",
          left: 0,
          height: 1,
          width: 0,
          backgroundColor: "var(--ss-gold)",
        }}
      />

      {/* Wordmark */}
      <div
        ref={wordRef}
        style={{
          marginTop: 28,
          fontFamily: "var(--font-display)",
          fontWeight: 800,
          fontSize: 18,
          letterSpacing: "0.18em",
          color: "#fff",
          textTransform: "uppercase",
          display: "flex",
        }}
      >
        {word.split("").map((c, i) => (
          <span key={i} data-char style={{ display: "inline-block" }}>
            {c}
          </span>
        ))}
      </div>
    </div>
  );
}
