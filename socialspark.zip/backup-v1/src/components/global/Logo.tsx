import { Link } from "@tanstack/react-router";

interface Props {
  /** Wordmark font size in px. Icon scales to ~110% of this. */
  size?: number;
  /** Tone: dark canvas (navy text) or light canvas (cream text). */
  tone?: "navy" | "cream";
}

/**
 * Social Spark wordmark: "S [⚡ in yellow circle] CIAL SPARK"
 * The lightning bolt replaces the "O" in SOCIAL. Single-line, navy or cream.
 */
export function Logo({ size = 20, tone = "navy" }: Props) {
  const color = tone === "navy" ? "var(--ss-ink)" : "var(--ss-cream)";
  const circle = Math.round(size * 1.05);
  const bolt = Math.round(size * 0.62);

  return (
    <Link
      to="/"
      aria-label="Social Spark — Home"
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 2,
        textDecoration: "none",
        color,
        fontFamily: "var(--font-sans)",
        fontWeight: 700,
        fontSize: size,
        letterSpacing: "-0.02em",
        lineHeight: 1,
      }}
    >
      <span>S</span>
      <span
        aria-hidden
        style={{
          width: circle,
          height: circle,
          borderRadius: "50%",
          background: "var(--ss-gold)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          margin: "0 1px",
          flexShrink: 0,
        }}
      >
        <svg width={bolt} height={bolt} viewBox="0 0 24 24" fill="none">
          <polygon
            points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"
            fill="var(--ss-ink)"
          />
        </svg>
      </span>
      <span>CIAL&nbsp;SPARK</span>
    </Link>
  );
}
