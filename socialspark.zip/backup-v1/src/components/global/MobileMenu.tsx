import { useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Logo } from "./Logo";
import { NAV_LINKS } from "./nav-links";
import { useLanguage } from "../../lib/language";

interface Props {
  open: boolean;
  onClose: () => void;
  onNavigate: (id: string) => void;
}

export function MobileMenu({ open, onClose, onNavigate }: Props) {
  const { lang, setLang, t } = useLanguage();
  const originalOverflow = useRef<string | null>(null);

  // Body scroll lock
  useEffect(() => {
    if (!open) return;
    originalOverflow.current = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = originalOverflow.current ?? "";
    };
  }, [open]);

  // Escape key
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const handleLinkClick = (id: string) => {
    onClose();
    // Wait for exit anim to start, then navigate
    setTimeout(() => onNavigate(id), 50);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="mobile-menu"
          initial={{ y: "-100%" }}
          animate={{ y: "0%" }}
          exit={{ y: "-100%" }}
          transition={{
            duration: open ? 0.42 : 0.3,
            ease: open ? [0.16, 1, 0.3, 1] : [0.7, 0, 0.84, 0],
          }}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 150,
            backgroundColor: "var(--ss-ink)",
            display: "flex",
            flexDirection: "column",
            padding: "100px 48px 48px",
          }}
          role="dialog"
          aria-modal="true"
          aria-label="Main menu"
        >
          <div style={{ marginBottom: 32 }}>
            <Logo />
          </div>

          <nav style={{ display: "flex", flexDirection: "column" }}>
            {NAV_LINKS.map((link, i) => (
              <motion.button
                key={link.id}
                type="button"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.4,
                  delay: 0.2 + i * 0.07,
                  ease: [0.16, 1, 0.3, 1],
                }}
                onClick={() => handleLinkClick(link.id)}
                style={{
                  textAlign: "start",
                  background: "transparent",
                  border: 0,
                  borderBottom: "1px solid var(--ss-line)",
                  padding: "20px 0",
                  color: "#fff",
                  fontFamily: "var(--font-display)",
                  fontWeight: 700,
                  fontSize: "clamp(28px, 8vw, 40px)",
                  lineHeight: 1,
                  cursor: "pointer",
                }}
              >
                {t(link.label, link.labelUr)}
              </motion.button>
            ))}
          </nav>

          <div style={{ marginTop: "auto", display: "flex", flexDirection: "column", gap: 20 }}>
            <button
              type="button"
              onClick={() => handleLinkClick("contact")}
              className="rounded-btn"
              style={{
                width: "100%",
                border: "1.5px solid var(--ss-gold)",
                color: "var(--ss-gold)",
                backgroundColor: "transparent",
                padding: "16px",
                fontFamily: "var(--font-display)",
                fontWeight: 700,
                fontSize: 16,
                cursor: "pointer",
                transition: "background-color 200ms ease, color 200ms ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = "var(--ss-gold)";
                e.currentTarget.style.color = "var(--ss-ink)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = "transparent";
                e.currentTarget.style.color = "var(--ss-gold)";
              }}
            >
              {t("Book a Call", "کال بک کریں")}
            </button>

            <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
              {(["en", "ur"] as const).map((code) => {
                const active = lang === code;
                return (
                  <button
                    key={code}
                    type="button"
                    onClick={() => setLang(code)}
                    aria-label={code === "en" ? "Switch to English" : "Switch to Urdu"}
                    aria-pressed={active}
                    className="rounded-pill"
                    style={{
                      fontFamily: "var(--font-sans)",
                      fontWeight: 700,
                      fontSize: 11,
                      letterSpacing: "0.06em",
                      padding: "6px 14px",
                      cursor: "pointer",
                      backgroundColor: active ? "var(--ss-gold)" : "transparent",
                      color: active ? "var(--ss-ink)" : "var(--ss-ash)",
                      border: active
                        ? "1px solid var(--ss-gold)"
                        : "1px solid var(--ss-line)",
                      lineHeight: 1,
                    }}
                  >
                    {code.toUpperCase()}
                  </button>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
